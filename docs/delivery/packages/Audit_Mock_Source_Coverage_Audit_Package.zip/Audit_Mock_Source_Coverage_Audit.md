# Audit Mock source coverage audit

9 November 2026 · GitHub main 69f0548de5f897127be671bba81cc61cfd524dfe

## Executive verdict

**The mock does not cover every source cycle, feature, form, or automation.** Every core feature now has a working slice on at least one surface, based on the source-and-code assessment. The browser mock covers **93 of 127** at partial depth and the shared pilot covers **97 of 127**. The pilot exercised all **34 earlier feature gaps** through authenticated actions. It still lacks an owning workflow for **30 other core features**. No complete source cycle, feature, form, or automation minimum earned full acceptance in this audit.

The main operational break is between surfaces. The browser mock has a population intake, sampling, calendar and native workpapers. The pilot has persistent records, separate sign-ins and a much stronger authorization and archive path. Its data intake and sampling handoff is missing. A team cannot yet perform all of that work in the same engagement.

| Population | Browser mock | Shared pilot |
|---|---:|---:|
| Core features, 127 | 93 partial, 25 form/fixture, 9 missing | 97 partial, 16 form/fixture, 14 missing |
| Earlier 34 feature gaps | 25 form/fixture, 9 missing | 34 partial |
| Use cases, 75 | 52 partial, 18 form/fixture, 1 missing, 4 conditional | 55 partial, 6 form/fixture, 10 missing, 4 conditional |
| E2E steps, 476 | 143 partial, 49 form/fixture, 104 unverified, 180 conditional/outside | 178 partial, 6 missing, 117 unverified, 175 conditional/outside |
| E2E cycles with at least one partial step, 51 | 34 | 37 |
| Entire source E2E cycles verified, 51 | 0 | 0 |
| Substantive workbook forms, 70 | 70 partial | 27 partial, 43 reference/fixture |
| Automation minimums, 58 | 16 partial, 42 catalogue only | 12 partial, 8 adjacent manual records, 38 missing |
| Automation extensions, 58 | 6 partial overlaps, 52 with no distinct extension | 7 partial overlaps, 51 with no distinct extension |

The **136** feature rows include the eight conditional follow-up items M11-F01–M11-F08 under D24 and the excluded Audit-owned consolidation in M03-F07 under D03. The E2E matrix can credit bounded support for a firm-level step while retaining the wider cycle's scope limitation. These counts measure row dispositions rather than production readiness. [Features](features.csv) · [E2E steps](e2e-steps.csv) · [Automation minimums](automation-minimums.csv) · [Extensions](automation-extensions.csv)

## 1. Audited version and method

The remote main reference was read with git ls-remote. The clean local branch extended-audit-pilot at be850c19a1d3ef2f450470ef67a3f04dec4d8208 matched the remote file tree eb214eae2d6ec19a8753d131737348af87a0e9db. The commit IDs differ because the pull request was squash merged. [Audited GitHub commit](https://github.com/gantulga906-cloud/Audit_Mock/commit/69f0548de5f897127be671bba81cc61cfd524dfe)

The existing preview on 3011 returned HTTP 200 for both routes. Its HTML hashes matched the on-disk static export. Its anonymous API exposed the setup state but no commit fingerprint, so its exact runtime revision remains unverified. Tests used a fresh build of the audited tree on a separate port and disposable synthetic databases. The original preview database was not used.

Coverage and verification are separate. **Working partial** credits an owning action or useful behavior for a subset. A catalogue card, generic narrative field or seeded fact does not establish the owning workflow. **Unverified** means no direct result was obtained for the exact requirement. The 75 use-case dispositions and 476 step dispositions include source-and-code assessments. The criteria appendix records 3 browser and 21 pilot criterion-level partial observations. Another 295 and 277, respectively, remain unverified, with 17 conditional on each surface. An adjacent passing test does not change those results. [Use cases](use-cases.csv) · [Acceptance criteria](criteria.csv)

## 2. Original source inventory

The inventory accounts for **158 non-directory ZIP member entries**, including both nested container files. There are **17** outer entries, **126** entries in the grounded specification, and **15** entries in the stage package. Including the outer container and five repaired companions yields **164 inventory rows**. Two members match earlier members byte for byte. All 23 hashes in the previous source manifest matched. The inventory accounts separately for alternate editions, translations and supporting research.

Each member was opened, parsed or verified against identical inspected bytes. The review parsed CSVs, JSON, DOCX text and tables, workbook cells and PDF text layers. PDF visuals were sampled. For example, the 214-page process map was reviewed visually at pages 1, 108 and 214. DOCX illustrations were inventoried without transcribing image-only text. The **11 PDF-embedded attachments** have their own inventory. The six ontology attachments and **228 file members within their embedded ZIPs** were inventoried separately, with JSON parsed and binary/image assets checked by hash. These supporting research members were not treated as independent product requirements or reviewed semantically file by file. The sample review does not establish every visual diagram label or branch condition. [Files](source-files.csv) · [Sheets](source-sheets.csv) · [Embedded attachments](pdf-embedded-inventory.csv) · [Embedded ontology members](embedded-ontology-files.csv)

The English and Mongolian lifecycle workbooks each contain the same **476 work IDs**. The work text in both languages, English handoff labels and applicability values matched the original E2E disposition CSV after whitespace normalization. The original CSV-to-app cross-check also reconciled the 136 features, 75 use cases, 315 criteria, 58 automation minimums, 58 extensions, 22 fieldwork variants and 29 open decisions. Compared titles, requirements, criteria text and automation descriptions matched for fields present in both formats. [Bilingual reconciliation](lifecycle-workbook-reconciliation.csv)

The **51 lifecycle cycles** comprise 30 A-series audit cycles, 16 B-series firm cycles and five C-series separate-service cycles. Of the 476 steps, 274 support scoped audit cases, 9 require the D24 follow-up mandate, 109 describe bounded support for a broader unapproved firm process, 36 are outside or unconfirmed firm processes, and 48 concern separate-service candidates. The five original BPMNs contained **827 sequence flows and 185 gateway nodes**, with zero broken endpoint references. All gateway IDs, conditions and defaults are inventoried. One-to-one application enforcement remains unverified where no direct test was run. [BPMN gateways](bpmn-gateways.csv) · [Sequence flows](bpmn-sequence-flows.csv)

### Editions and authority

- The original grounded CSV registers control the scope and acceptance criteria. The wishlists explain intent and retain options and extensions. The audit distinguishes a source candidate from an approved release commitment.
- The repaired workbooks control the current field comparison. The similarly named five workbooks inside the stage ZIP are alternate editions. The inventory retains both editions and identifies the administrative terminology sheet.
- The ERD, ontology and stage diagrams describe required relationships and possible invariants. The app implements a narrower SQLite record model. For example, the source distinguishes a custody offer, receiver and acknowledgment. The pilot's seal and scratch recovery do not establish a distinct receiving custodian.
- Tenure, conflicting services, retention and professional decisions have source references. The audit tested representation of those requirements in the app. Current legal applicability and approved firm policy were not independently established. D05, D06, D15, D18, D19, D20, D21 and D25 remain material. [Open source decisions](open-source-decisions.csv)

## 3. Critical handoffs

### Acceptance to planning

On the browser mock, the E2 preparer saw the outstanding acceptance, agreed letter and independence references for **1.4.1/1.4.2, 1.4.3 and 1.4.5** while independent **1.1.1** draft inputs remained editable. The repaired Stage 1 worksheet links those decisions at 1.1.1А!L16:L18, and 1.4.3 А!B3 identifies the engagement letter. The pilot separately exercised assigned declarations, denial of self-clearance and a residual threat that blocked activation. The missing handoff is a signed, versioned instrument and a native persistent 1.1.1 that consumes those exact approved versions. [Browser workpaper](https://github.com/gantulga906-cloud/Audit_Mock/blob/69f0548de5f897127be671bba81cc61cfd524dfe/src/components/workpaper-editor.tsx) · [Pilot workflow](https://github.com/gantulga906-cloud/Audit_Mock/blob/69f0548de5f897127be671bba81cc61cfd524dfe/scripts/pilot-workflow.mjs#L118)

### Planning to sampling and evidence

The browser domain probe repeated the same three selected units using the same approved design and population. A changed dataset version invalidated the selection and blocked the next run. The source anchors are 3.3.1А!A24/K24 for reviewed 1.3 performance materiality and A28/K28 for 2.6 controls reliance. The pilot separately uses current reviewed 1.3 and 2.6 for programme adoption. An inapplicable programme stayed out in the test. The pilot has no native sample design or selection action. It also lacks the browser mock's structured population reconciliation, sample-to-finding work and verified-posting chain. [Sampling source gate](https://github.com/gantulga906-cloud/Audit_Mock/blob/69f0548de5f897127be671bba81cc61cfd524dfe/src/lib/workspace.ts#L140) · [Dependencies](dependencies.csv)

The original pilot case rejected and replaced a file, retained both versions, returned a workpaper and approved the revision after separate response and clearance. The extended case exercised all 34 register kinds in one synthetic engagement and verified database state after restart. Journal and confirmation records capture sources, criteria and exceptions. Reproducible journal selection, live auditor-controlled confirmation dispatch and the full set of 22 fieldwork variants were not established. [Pilot tests](https://github.com/gantulga906-cloud/Audit_Mock/blob/69f0548de5f897127be671bba81cc61cfd524dfe/tests/pilot.test.mjs) · [Variants](fieldwork-variants.csv)

### Completion, issue and archive

**The selected opinion does not determine the report artifact.** An additional authenticated probe approved a qualified opinion and sealed an archive. The approved decision remained qualified, while the report paper in the authorized package was **4.1.A1**, the source's unmodified opinion template. The reviewed additional sections were separate records. Changing a statement line correctly staled the dependent analysis and authorization. The issue action stores a manual reference. It did not generate or deliver a signed opinion-specific report. The pilot also lacks a formal EQR role, despite a bounded quality fixture on the browser mock. [Pilot report selection](https://github.com/gantulga906-cloud/Audit_Mock/blob/69f0548de5f897127be671bba81cc61cfd524dfe/scripts/pilot-workflow.mjs#L17) · [Authorization](https://github.com/gantulga906-cloud/Audit_Mock/blob/69f0548de5f897127be671bba81cc61cfd524dfe/scripts/pilot-workflow.mjs#L227)

**Archive payload checks are stronger than archive summary checks.** The pilot denied original-file downloads after lock and denied scoped export to the wrong role. Report-only inspection excluded evidence bytes. A preparer who was part of the engagement still received two archived filenames and hashes in the normal API before any retrieval grant existed. That is an observable metadata-scope gap. Scratch recovery, predecessor preservation and a new hold blocking previously approved synthetic disposition worked. Independent receiving custody, actual receipt, reissue through re-lock and real disposition remain incomplete. [Archive grant and summary](https://github.com/gantulga906-cloud/Audit_Mock/blob/69f0548de5f897127be671bba81cc61cfd524dfe/scripts/pilot-archive.mjs#L143) · [Direct file gate](https://github.com/gantulga906-cloud/Audit_Mock/blob/69f0548de5f897127be671bba81cc61cfd524dfe/scripts/pilot-server.mjs#L173)

## 4. Features, roles and workbook fidelity

The [earlier 34 matrix](earlier-34-feature-gaps.csv) lists the newly working pilot slices and their limits. Examples include an approved roster and staffing assessment, threats and declarations, an inapplicable programme decision, a journal exception linked to governance communication, a human opinion decision, a scoped inspection export and a late hold that prevented disposition. The wider role model still has three fixed pilot identities. Real specialist, independent EQR and custodian identities remain open.

The browser mock has the broader **tasks, calendar, progress and native Form Builder**. The preparer calendar opened in the isolated browser. Schedule and assignment behavior also appears in the scoped browser model. The pilot has register review queues and due fields without an equivalent persistent calendar, Gantt, resource view or cross-engagement scheduling. [Browser calendar and timeline](https://github.com/gantulga906-cloud/Audit_Mock/blob/69f0548de5f897127be671bba81cc61cfd524dfe/src/components/delivery-planning.tsx) · [Pilot screen](https://github.com/gantulga906-cloud/Audit_Mock/blob/69f0548de5f897127be671bba81cc61cfd524dfe/src/components/pilot-workspace.tsx)

The repaired companions contain **71 sheets**, including one administrative log, with **18,577 populated cells, 272 formula cells and 1,820 validation objects**. Those formula cells include spreadsheet support and numbering. The static contract maps native labels, options, repeated rows, instructions and fixed clauses to source anchors. It supports generic persistence and review with selected forms tested. The pilot can open 23 programme-family papers after adoption and four other papers. Most pilot workpaper answers are narrative, with structured fields in separate registers. The remaining 43 source IDs serve as references or fixtures. Full save/reopen, workbook formula parity, and every validation, clause and table-row behavior were not independently exercised. [70-form comparison](forms.csv) · [Field-level trace](form-field-trace.csv) · [Sheet validation ranges](source-sheets.csv)

## 5. Automation results

The browser mock has **seven catalogue runners** for AUTO-003, 028, 046, 047, 048, 056 and 058. Nine more minimums have bounded checks, gates or related workflows outside the runner. They are AUTO-001, 002, 005, 006, 027, 053, 054, 055 and 057. The probes reproduced the expected straight-line depreciation and rejected invalid months, tied supplied mapping rows, exposed a trial-balance residual and repeated an unchanged sample. [Runner list](https://github.com/gantulga906-cloud/Audit_Mock/blob/69f0548de5f897127be671bba81cc61cfd524dfe/src/lib/workspace.ts#L117) · [Probe results](automation-probes.csv)

Two source deviations were reproduced:

- **AUTO-001.** The coverage function returned three entries for one issued, one draft and one cancelled request. Expected coverage for the fixture was the one issued request. The function filters by engagement while leaving dispatch eligibility unchecked. [Evidence coverage](https://github.com/gantulga906-cloud/Audit_Mock/blob/69f0548de5f897127be671bba81cc61cfd524dfe/src/lib/audit-checks.ts#L58)
- **AUTO-002.** Duplicates and out-of-period rows were quarantined. Invalid monetary text still became numeric zero on the quarantined row. The original minimum explicitly requires retaining invalidity rather than replacing an invalid amount with zero. [CSV import](https://github.com/gantulga906-cloud/Audit_Mock/blob/69f0548de5f897127be671bba81cc61cfd524dfe/src/lib/workspace.ts#L91)

The pilot's 12 partial minimums are **AUTO-001, 010, 046, 049–051 and 053–058**. They include calculations, human-reviewed records, dependency gates and archive actions. A manually recorded journal selection does not execute the risk filters in AUTO-009. The pilot's legal, going-concern and subsequent-event workflows are reviewed records with selected gates. Actual delivery, portal synchronization, external registry checks and digital signature services were not demonstrated. All 58 extensions retain future-candidate scope. [Minimum-by-minimum audit](automation-minimums.csv) · [Extension-by-extension audit](automation-extensions.csv)

## 6. Prioritized gaps and proof of closure

| Priority and source | Affected role and break | Acceptance test |
|---|---|---|
| P0 · M10-F09/F10/F11/F14, P10-UC06–UC08, AUTO-056/057 | Reviewer and partner. The selected opinion and approved sections are not assembled into the exact report artifact. | Approve a qualified opinion and additional section. Generate the matching report, show its hash at authorization and block issue after a wording, opinion or statement change. |
| P0 · M12-F07/F10, CC02, P12-UC04-AC01/02 | Custodian and preparer. The pre-grant API discloses filenames and hashes even though file and export endpoints deny payloads. | Before a grant the role sees only permitted metadata. A report-only grant cannot reveal the file index through lists, search, direct URLs or export. Test expiry and revocation. |
| P0 · M07-F10, P09-UC07-AC01, AUTO-051 | Reviewer and partner. No checked subsequent-event coverage-through date tied to the report date. | Approve through day X and move the report date to X+1. Readiness blocks pending coverage of the extra interval and retains the earlier review. |
| P1 · M07-F04/F07, M08-F09, P05-UC01–UC03 and P07-UC02/03 | Preparer and senior. Persistent data intake, reconciliation and sampling are missing between approved planning and fieldwork. | Import and reconcile one dataset. Review current 1.3, 2.6 and sample design under a separate account. Change the source and prove staleness, then carry reviewed sample exceptions into findings. |
| P1 · M09-F08/F09/F10, P11-UC05/06, D05/D06 | Partner and independent quality reviewer. Formal applicability, eligibility and exact-package EQR are missing in the pilot. | With approved firm policy, require a separate eligible account, deny self-review and invalidate EQR when the relevant signed package changes. |
| P1 · M10-F01–F05, P10-UC01–UC03, AUTO-048 | Senior and partner. Pilot exception registers lack a first-class finding, verified posting and aggregate evaluation chain. | Propose and accept a correction without posting it. Keep it in the uncorrected total until exact posting evidence is verified. Preserve qualitative impact and renewed downstream review. |
| P1 · M02-F02/F03/F09, M08-F01/F02, P04-UC01–UC03 | Methodology owner and reviewer. Typed Form Builder and approved source templates live on separate surfaces. | Publish and apply a scoped template change in the pilot, preserve typed prior answers and sign-off history, and deny editing an ungranted template. |
| P1 · AUTO-001/002, P08-UC01/UC04, P05-UC01 | Preparer and senior. Request eligibility and invalid amount representation are incorrect in the tested examples. | Compare issued, cancelled and replaced requests. Import invalid text, genuine zero and a valid negative amount and verify all remain distinguishable through reconciliation. |
| P1 · M12-F02/F04/F06/F08/F09, P12-UC01–UC05, D19/D20 | Partner and custodian. Sealing and recovery lack independent custody, complete format readability and approved retention rules. | A separate receiver verifies the actual manifest and file readability, acknowledges custody and preserves holds and policy dates through amendment and re-lock. |
| P2 · CC03/CC08, P03-UC03, P14-UC03, P16-UC01/02 | Senior and portfolio manager. Persistent task, calendar, Gantt and cross-engagement workload are incomplete. | Move one authorized due date and observe the same persistent record in the calendar, workpaper and portfolio views across two engagements. |
| P2 · M07-F08, M10-F12/F13/F14, P08-UC03, P10-UC05–UC08, D25 | Auditor, recipient and partner. Dispatch, signature and receipt are represented by manual records. | Send through an approved test integration and observe independent delivery and reply events. Exercise failure and prove a queued action cannot register as received or signed. |

## 7. Verification record

| Check | Observed result |
|---|---|
| Fresh npm run typecheck | Exit 0 from a Git-exported copy |
| Fresh npm test | 39 passed, 0 failed, including the browser-model fixed-asset journey and both authenticated pilot scenarios |
| Fresh npm run build | Exit 0, static production export for both routes |
| Isolated browser session | Observed 1.1.1 dependency warning, preparer draft availability and calendar. Reviewer submitted a pilot firm record. Partner approved the exact version and saw it after refresh. |
| Targeted automation domain probes | 17 checks, 15 matched and two reproduced source deviations |
| Additional authenticated probes | Reproduced a qualified opinion retained alongside fixed 4.1.A1, and archived filenames/hashes visible before a retrieval grant |
| Source verification | ZIP, five companions, original register identities, bilingual lifecycle rows, BPMN endpoints and output denominators reconciled |

No complete per-role browser replay was performed for all 51 cycles, 22 fieldwork variants or 315 criteria. Workbook recalculation and PDF image-only text remain unverified. This audit used synthetic evidence for role, version, retry and archive paths. The application code, GitHub repository, original files and existing pilot records were left intact.

## Appendix A. Exact gap IDs

**Browser features without an owning action (9).** M01-F01, M01-F02, M01-F04, M10-F06, M12-F04, M12-F07, M12-F09, M12-F10, M12-F11

**Browser features with form or fixture only (25).** M01-F03, M01-F06, M02-F05, M03-F04, M04-F02, M04-F04, M04-F05, M04-F06, M06-F02, M06-F04, M06-F05, M06-F06, M06-F09, M07-F01, M07-F06, M07-F08, M07-F09, M07-F10, M08-F07, M10-F08, M10-F09, M10-F11, M10-F12, M10-F13, M12-F08

**Pilot features without an owning action (14).** M01-F07, M02-F01, M02-F03, M02-F06, M02-F07, M05-F09, M05-F10, M07-F03, M07-F04, M07-F07, M09-F08, M09-F09, M10-F04, M10-F05

**Pilot features with form or fixture only (16).** M02-F02, M02-F09, M03-F01, M03-F03, M03-F05, M03-F06, M03-F08, M04-F10, M05-F04, M05-F05, M06-F03, M06-F13, M07-F02, M07-F05, M08-F09, M10-F10

**Browser automation minimums with catalogue only (42).** AUTO-004, AUTO-007, AUTO-008, AUTO-009, AUTO-010, AUTO-011, AUTO-012, AUTO-013, AUTO-014, AUTO-015, AUTO-016, AUTO-017, AUTO-018, AUTO-019, AUTO-020, AUTO-021, AUTO-022, AUTO-023, AUTO-024, AUTO-025, AUTO-026, AUTO-029, AUTO-030, AUTO-031, AUTO-032, AUTO-033, AUTO-034, AUTO-035, AUTO-036, AUTO-037, AUTO-038, AUTO-039, AUTO-040, AUTO-041, AUTO-042, AUTO-043, AUTO-044, AUTO-045, AUTO-049, AUTO-050, AUTO-051, AUTO-052

**Pilot automation minimums without a matching implementation (38).** AUTO-002, AUTO-003, AUTO-004, AUTO-005, AUTO-006, AUTO-011, AUTO-012, AUTO-013, AUTO-014, AUTO-015, AUTO-016, AUTO-017, AUTO-018, AUTO-019, AUTO-020, AUTO-021, AUTO-022, AUTO-023, AUTO-024, AUTO-025, AUTO-026, AUTO-027, AUTO-028, AUTO-029, AUTO-030, AUTO-031, AUTO-032, AUTO-033, AUTO-034, AUTO-035, AUTO-036, AUTO-037, AUTO-038, AUTO-039, AUTO-040, AUTO-043, AUTO-047, AUTO-048

**Pilot automation minimums with adjacent records only (8).** AUTO-007, AUTO-008, AUTO-009, AUTO-041, AUTO-042, AUTO-044, AUTO-045, AUTO-052

**Browser extensions with partial overlap (6).** AUTO-046-FUTURE, AUTO-047-FUTURE, AUTO-053-FUTURE, AUTO-054-FUTURE, AUTO-055-FUTURE, AUTO-056-FUTURE

**Pilot extensions with partial overlap (7).** AUTO-046-FUTURE, AUTO-053-FUTURE, AUTO-054-FUTURE, AUTO-055-FUTURE, AUTO-056-FUTURE, AUTO-057-FUTURE, AUTO-058-FUTURE

**Pilot E2E steps with no owning route in the scoped cases (6).** A11-P2-W1, A11-P2-W2, A11-P2-W3, A20-P2-W1, A20-P2-W2, A20-P2-W3

## Appendix B. All 51 lifecycle cycles

The counts are partial step mappings, not successful end-to-end runs. The cycle matrix gives the exact first source step beyond verified partial coverage and the original entry and end step IDs. The step matrix includes expected next handoffs, linked roles and screen groups. [Cycle matrix](e2e-cycles.csv) · [Step matrix](e2e-steps.csv)

| Cycle | Partial steps, browser / pilot | Browser break | Pilot break |
|---|---:|---|---|
| A01 · Client acceptance or continuance | 5 / 6 of 11 | Client record and provisional intake can reach conditional or accepted decision, but no structured integrity/resource decision feeds the browser workflow. | Reviewed concerns and staffing can reach partner activation. Continuance, prior auditor, legal tenure and conflicting services have no complete route. |
| A02 · Ethics and independence clearance | 3 / 5 of 9 | The decision consumes an independence reference. Individual declarations and safeguarded escalation have no owning workflow. | Declaration, safeguard and residual assessment run. No firm/network interests registry, policy prohibition or ongoing re-clearance route. |
| A03 · Audit prerequisites and engagement terms | 3 / 3 of 9 | Company framework and recorded terms reference work. Exact agreement, authority and amendment approval are absent. | Terms are a manual reference. Scope limitation, responsibility, signatory evidence and reapproval are not bound to an instrument. |
| A04 · Engagement mobilization | 6 / 5 of 9 | Demo assignments and dates work. Actual competent staff, specialist permissions and conflicts are incomplete. | Roster and competence feed staffing assessment. Sign-ins remain fixed, with no specialist/EQR role or portfolio availability. |
| A05 · Initial scope and kickoff | 5 / 3 of 9 | Calendar, requests and shared scope support selected steps. Kickoff agreement and owned planning baseline are incomplete. | Intake and requests exist. No meeting decisions, integrated planning calendar or approved kickoff baseline handoff. |
| A06 · Understand the entity, reporting, IT, and controls | 2 / 5 of 9 | Company profile and questionnaires are accessible. No structured entity-to-risk/IT controls workflow. | Entity facts and risk links exist. IT/interface, service organization, walkthrough and implementation testing remain open. |
| A07 · Identify and assess audit risks | 5 / 7 of 9 | Risk and procedure links run on selected records. Fraud assessment, statement-level scope and comprehensive re-review are incomplete. | Fraud/preliminary inputs connect to risk and response; no full legal/exposure or fieldwork-to-risk trigger. |
| A08 · Set and revise materiality | 6 / 5 of 9 | Reviewed thresholds feed a sample and misstatement evaluation. Specific levels and approved benchmarks are bounded. | Materiality and controls versions feed programme selection. No persistent sampling or misstatement aggregation handoff. |
| A09 · Evaluate opening balances | 0 / 6 of 9 | Source forms guide opening balances without the owning evidence/reliance decision. | Prior work, test, limitation and intended effect can be reviewed. No automated roll-forward, reconciled source or report treatment. |
| A10 · Develop and approve the audit strategy and risk responses | 6 / 6 of 9 | Typed strategy and tailored procedures work in selected examples. Full linked coverage/approval and resource plan remain incomplete. | Reviewed risk and applicability control adoption. No full strategy package, resourcing plan, or per-procedure scope. |
| A11 · Prepare audit-ready data and populations | 8 / 3 of 9 | CSV population checks support one schema. Full controlled import, separate provenance and GL/TB/FS mapping remain incomplete. | Versioned files and request tracking work. No structured import-to-reconciliation-to-population handoff. |
| A12 · Evaluate and test controls | 6 / 1 of 12 | 2.6 and sample-related controls reliance work. No full objective/owner/frequency and operating test record set. | Reviewed reliance basis is used for adoption. No operating-test units, structured deviation/reevaluation or deficiency routing. |
| A13 · Perform substantive audit work by cycle and assertion | 12 / 9 of 13 | Fixed-asset path, sampling and review work. Other native areas, journal selection and complete assertion conclusions are unproven. | Selected programmes, journal criteria and analyses are reviewed. No persistent sample selection, projection or independent finding ledger. |
| A14 · Manage external confirmations | 1 / 8 of 10 | Generic evidence requests do not implement controlled third-party confirmation dispatch/response. | Recipient, result, source and alternatives are recorded. Controlled dispatch, authenticity verification and actual follow-up remain external. |
| A15 · Resolve specialized accounting and disclosure matters | 0 / 5 of 9 | Workpapers cover estimates and related parties as source forms. No proven complete specialist/estimate/disclosure chain. | Structured procedure subtypes and conclusions exist. Evidence-backed measurement models, uncertainty and misstatement routing remain incomplete. |
| A16 · Coordinate group, component, specialist, or internal-auditor contributions | 2 / 5 of 9 | Scope and assignments exist without external contributor workspaces. | Reviewed competence, prior-work limitations and additional work exist. No independent specialist/component accounts or instruction/response channel. |
| A17 · Investigate suspected fraud or non-compliance | 3 / 5 of 9 | Local notes and evidence support an issue without owning investigation and confidential escalation. | Fraud risk, journal exception and evidence records work. No allegation triage, confidential investigation or regulator workflow. |
| A18 · Resolve missing or contradictory evidence | 6 / 7 of 9 | Rejection, replacement and scoped acceptance work. Contradiction-to-risk/alternative-evidence handling is limited. | Requests, accepted proof and sufficiency links work. Broader contradictory-evidence case ownership and reviewed alternatives remain partial. |
| A19 · Resolve audit findings with the client | 6 / 5 of 9 | Selected findings and correction workflow work, with limited classification and deduplication. | Procedure exceptions and governance messages link. No first-class persistent finding, correction ledger or reopening queue. |
| A20 · Evaluate misstatements and corrections | 7 / 2 of 9 | Verified posting changes the total and qualitative findings remain. Full projected/judgmental and currency review remains incomplete. | Final conclusion can record impacts. No independent adjustment/posting and misstatement aggregation pipeline. |
| A21 · Complete period-end and reporting-date matters | 0 / 8 of 9 | Related source forms exist. No verified reporting-date search, obligations or completion gates by subtype. | Reviewed subtype records feed completion. No explicit through-date enforcement, tested going-concern forecast or counsel/statement dependency. |
| A22 · Evaluate final financial statements and disclosures | 3 / 4 of 9 | Selected account-to-statement bridge and package versioning work. Disclosure and comparative assessment incomplete. | Exact final line amounts drive analytics. No GL/TB bridge, evidence-backed disclosure coverage or verified corrections link. |
| A23 · Obtain management’s written representations | 0 / 6 of 9 | Representation source forms are visible. No evaluated signed-version acceptance gate. | Receipt, date and exact accepted version can gate issue. Signer authority, report-date relation and mandatory representations need verification. |
| A24 · Communicate with management and those charged with governance | 2 / 6 of 9 | Contacts and communication forms exist. No actual reviewed dispatch/recipient record. | Governance message, finding link, response and delivery evidence are reviewed records. No live send or independently observed receipt. |
| A25 · Clear engagement review and quality gates | 7 / 6 of 9 | Returned notes, renewed approval and selected fixture EQR run. Firm-level EQR eligibility/consultation is incomplete. | Current review and dependent approvals work. Formal independent EQR and consultation are absent. |
| A26 · Form the opinion and issue the auditor’s report | 6 / 7 of 9 | Exact package authorization and issue record run. Opinion choice, report generation, signatures and real delivery remain incomplete. | Opinion and sections are approved records, but issue retains a reference to the fixed report paper. No generated opinion-specific signed report or live delivery. |
| A27 · Finalize and hand over the audit file | 6 / 7 of 9 | Lock, manifest and custody offer/accept records work. Complete content, retrieval grants and retention absent. | Immutable file/hash package, access, holds and recovery work. No separate custody receiver and verified receipt or assembly deadline enforcement. |
| A28 · Respond to a later-discovered fact | 5 / 6 of 9 | Changed content reopens approval, without an owning later-fact response or communications control. | Substantive archive amendment reopens review. Full revised issue/re-lock, regulatory notification and chronology are unverified. |
| A29 · Follow up agreed recommendations or action plans | 0 / 0 of 9 | D24 requires a separate agreed follow-up mandate. No owning lifecycle under the core scope. | D24 requires a separate mandate. Generic tasks and review records do not deliver verified follow-up. |
| A30 · Read and respond to other information in the annual report | 0 / 0 of 12 | Annual-report Other Information path is absent beyond generic statements and report forms. | Additional section register has no annual-report expected/received, comparison, correction or post-report handoff. |
| B01 · Opportunity to proposal | 1 / 1 of 9 | Client enquiry is adjacent support. No proposal, procurement, pricing or win/loss workflow. | Single engagement intake is adjacent support. Broader proposal scope is not authorized. |
| B02 · License and regulatory standing | 0 / 2 of 9 | Demo firm metadata does not track regulatory standing, deadlines or filings. | Firm identity and credentials are reference records. No authoritative renewal or regulator workflow. |
| B03 · Firm quality objectives and risk management | 0 / 0 of 9 | D26 outside/unconfirmed firm quality system scope. | D26 outside/unconfirmed. Engagement review does not establish firm ISQM evaluation. |
| B04 · Firm-wide ethics, conflicts, and breach handling | 1 / 4 of 10 | Engagement-level independence reference supports the engagement decision only. | Recorded team declarations/threats help one engagement. No firm/network risk match, tenure or breach system. |
| B05 · Standards and methodology change control | 4 / 3 of 9 | Form Builder supports bounded drafting, review and releases. No regulator monitoring and firm adoption programme. | Reviewed rules and pinned template references. No general methodology release governance. |
| B06 · People and competence development | 1 / 3 of 9 | Demo workload and roles are adjacent support. No staff development or verified training/credential maintenance. | Roster/credential records work. Forecasting, training, CPD and performance remain outside the pilot. |
| B07 · Portfolio capacity and scheduling | 6 / 2 of 9 | Scoped demo workload, calendar and reassign work. No live availability or firm portfolio operations. | One assessed staffing record per role. No multi-engagement calendar or capacity planning. |
| B08 · Technical consultation service | 0 / 0 of 9 | No consultation intake/assignment workflow. Existing workpaper notes are adjacent support. | No independent adviser assignment or consultation workflow. |
| B09 · EQR policy and reviewer assignment | 3 / 0 of 9 | Static R4 fixture supports selected gate. No firm policy screening, eligibility and reassignment route. | No pilot EQR role or policy workflow. |
| B10 · Quality monitoring and remediation | 0 / 0 of 9 | D26 outside/unconfirmed firm monitoring and remediation scope. | D26 outside/unconfirmed firm monitoring and remediation scope. |
| B11 · Complaint or allegation handling | 0 / 0 of 9 | D26 outside/unconfirmed confidential complaints scope. | D26 outside/unconfirmed confidential complaints scope. |
| B12 · External inspection response | 0 / 2 of 9 | No controlled inspection response workflow. | Scoped report/evidence inspection export. Inspector authority, receipt and remediation remain external. |
| B13 · Audit technology and provider governance | 0 / 0 of 9 | D26 outside/unconfirmed technology provider governance scope. | D26 outside/unconfirmed technology provider governance scope. |
| B14 · Information access and security response | 1 / 2 of 9 | Demo role/access settings and export scoping only. No security incident lifecycle. | Authenticated role/export controls work on one engagement. No incident response, credential administration or organization tenancy. |
| B15 · Engagement economics and collection | 2 / 0 of 9 | Time/effort planning is adjacent support. Commercial economics and collection are outside confirmed scope. | Staffing hours have no billing, invoicing or collection workflow. |
| B16 · Archive custody and disposition | 3 / 8 of 9 | Lock and handover status without production retention/disposition. | Scratch recovery, scoped access, holds and synthetic archive-copy disposal work. Legal standing, independent custody, real disposal and receipt are unverified. |
| C01 · Financial-statement review | 0 / 0 of 10 | D26 separate financial-statement review service outside current audit scope. | D26 separate review service outside current audit scope. |
| C02 · Other assurance engagement | 0 / 0 of 9 | D26 separate assurance service outside current audit scope. | D26 separate assurance service outside current audit scope. |
| C03 · Agreed-upon procedures | 0 / 0 of 9 | D26 agreed-upon procedures are outside current audit scope. | D26 agreed-upon procedures are outside current audit scope. |
| C04 · Outsourced or co-sourced internal audit | 0 / 0 of 10 | D26 outsourced internal audit is outside current audit scope. | D26 outsourced internal audit is outside current audit scope. |
| C05 · Permitted advisory or financial-related service | 0 / 0 of 10 | D26 advisory/financial services are outside current audit scope. | D26 advisory/financial services are outside current audit scope. |

## Appendix C. Evidence matrix index

- [File inventory](source-files.csv) · 164 rows
- [Worksheet inventory](source-sheets.csv) · 250 rows
- [PDF attachment index](pdf-embedded-inventory.csv) · 11 rows
- [Ontology attachment and nested ZIP inventory](embedded-ontology-files.csv) · 234 rows
- [English and Mongolian workbook reconciliation](lifecycle-workbook-reconciliation.csv) · 476 rows
- [Product processes](product-processes.csv) · 16 rows
- [Original screen groups](screen-groups.csv) · 25 rows
- [Use cases](use-cases.csv) · 75 rows
- [Criteria](criteria.csv) · 315 rows
- [Lifecycle cycles](e2e-cycles.csv) · 51 rows
- [Lifecycle steps](e2e-steps.csv) · 476 rows
- [BPMN gateways](bpmn-gateways.csv) · 185 rows
- [BPMN sequence flows](bpmn-sequence-flows.csv) · 827 rows
- [All features](features.csv) · 136 rows
- [Earlier 34 feature gaps](earlier-34-feature-gaps.csv) · 34 rows
- [Substantive forms](forms.csv) · 70 rows
- [Form field trace](form-field-trace.csv) · 1,236 rows
- [Cross-form dependencies](dependencies.csv) · 20 rows
- [Fieldwork variants](fieldwork-variants.csv) · 22 rows
- [Automation minimums](automation-minimums.csv) · 58 rows
- [Automation extensions](automation-extensions.csv) · 58 rows
- [Automation probe outcomes](automation-probes.csv) · 17 rows
- [Independent pilot and code findings](additional-findings.csv) · 3 rows
- [Unresolved source decisions](open-source-decisions.csv) · 29 rows
