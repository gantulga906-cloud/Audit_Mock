# Audit_Mock: enterprise UX research and redesign direction

11 November 2026 · Research and proposed work only · Application source unchanged

## Recommendation

Use an **engagement-centred workspace with role-specific work queues, full-page workpapers and optional evidence/review context**. Use guided steps for bounded unfamiliar activities, such as an import or engagement setup. Keep normal audit work directly accessible and resumable.

This recommendation combines the existing functional scope with enterprise interaction patterns. It is a design hypothesis to validate with auditors. It does not commission a rebuild, change the professional methodology or remove unfinished features. The accompanying **Redesign_Work_List.md** makes the proposal implementable after approval; all items remain proposed.

The most important change is to give users a stable place for each kind of work and a clear route between related records. Colour and density are part of that work, but do not resolve the two competing UI surfaces or their differing persistence.

## 1. Evidence, versions and limits

### What was inspected

- The supplied remaining-work Markdown and all six members of its ZIP, including its 128 tasks, 51-cycle matrix and 2,247-row source-closure register.
- The complete 26 October materials archive inventory, recursively including its two nested archives: **158 non-directory members**. Text was extracted from 27 PDFs, seven DOCX documents, seven archived workbooks, 34 Markdown documents, 32 JSON files, 43 CSV files, five BPMNs and one DBML. Those counts include the two ZIP containers. Embedded Office media and embedded PDF attachments are not counted as additional archive members.
- All populated cells, formulas and validation-object counts in the five separately supplied repaired workbooks. They contain **71 worksheets: 70 forms and one Stage 5 change log**. The stage distribution is 11/16/31/11/1 forms. There are **272 formula cells and 1,820 validation objects**. Those counts do not establish that every formula is a business calculation or that every validation object is a distinct requirement.
- Current local routes, navigation, workpaper editors, shared pilot components, form configuration types, office-preview parser, command revision/idempotency handling, source registers, research files and development notes.
- All 65 available turn pages of **“Assess traditional coding tradeoffs”**, using user messages and final responses for historical context. The chat tool returns previews and can truncate long items; this was not a verbatim review of every earlier attached prompt. Command/reasoning logs were not treated as requirements. Relevant history is summarised below.
- Public enterprise-design guidance and ten audit-product families, with source limitations in **Research_References.md**.

Extraction and indexing are broader than substantive reading. The reviewed baseline, shared contracts, roles, screen requirements, relevant source registers and representative form families informed this report. Long source PDFs, all image material, every formula's business meaning and all 1,012 BPMN entries were **not independently reaccepted** in this UX study. Preserve their detailed source reconciliation under R00/R07/R23.

### Version facts

| Surface | Verified identity | How it is used |
|---|---|---|
| Local checkout | `wave-0-audit-controls`, `25486b7448e6e5fc4d830868de943962209db3f3`; tracked tree clean | Principal code-inspection baseline, matching the supplied plan |
| GitHub main | `69f0548de5f897127be671bba81cc61cfd524dfe` | Earlier merged baseline; do not assume it includes later pilot work |
| GitHub draft PR #6 | Open, draft; head `937e692c7e43e5338575aeddfd5b53c1c083fa50` | GitHub recursive tree was compared with local committed blob hashes: **zero file differences**. Commit identities differ, but the committed files match |
| Saved verification | Records 58 passing tests, four connected cycles, 48/476 steps and 59/315 criteria; independent acceptance open | Historical technical evidence, not tests rerun during this research |
| Local exported preview | `out/index.html` timestamp 9 November; no matching build identity established for a fresh browser session | No fresh usability or visual-conformance claims are made |

GitHub facts were read through the connected service on 11 November. See [PR #6](https://github.com/gantulga906-cloud/Audit_Mock/pull/6). A direct comparison of the different commit IDs returned 404; the subsequent complete file-tree comparison established file equality instead.

### Browser limitation

The in-app browser could not reach the local preview. Windows Computer Use then stopped because it could not reliably establish the browser URL. No authenticated browser walkthrough was completed. Structural findings below are **code observations**. Predicted usability effects are **inferences**. Real task success, visual density, keyboard paths, accessibility, recovery and cross-role usability remain to be tested.

The research preview server was stopped. Repository source was not edited. A disposable copy of the latest later-fact fixture was prepared for inspection; no professional workflow transition was performed in the research session. Research files are outside the repository.

## 2. Lessons from the development chat

The history materially changes what the next design should preserve:

1. **Controlled configuration is a product requirement.** The user explicitly described permission to change one form without permitting changes to other forms or shared behaviour. A static redesign of the 70 forms would lose that requirement.
2. **Substantive work should open as a full page.** The user objected to half-width form drawers and the mandatory extra “open all inputs” step. Later v4 work implemented a full-page editor in the browser mock. Recreating a drawer as the default would repeat a rejected direction.
3. **Evidence is a first-class workspace concern.** The history requests photos, PDF, Word and Excel support, provenance and usable links from workpapers.
4. **Fields must reflect their meaning.** Calendar dates, legal-entity selectors, repeated contacts, choice answers and linked identity facts should replace undifferentiated text boxes where appropriate.
5. **Calendar, personal tasks and a senior Gantt remain required.** These are different views of owned work; schedule changes cannot count as preparation or review.
6. **The target is complete connected behaviour.** Earlier work was repeatedly corrected when catalogues, demo slices or aggregate percentages obscured unfinished source obligations. The new list must preserve individual source IDs and meaningful acceptance journeys.
7. **Build in connected batches, verify individual obligations.** One change can serve several cycles, but no cycle is closed merely because its screen exists.
8. **Older gap statements can be obsolete.** Later implementations added scoped materiality, accepted-extract provenance, independent quality/custody and controlled reissue. Retain these as regression assets rather than planning them as entirely absent.

The 11 November remaining-work plan governs current sequencing; older conversational implementation claims are historical evidence, not a substitute for current code or acceptance.

## 3. What the five research areas mean here

These are overlapping bodies of practice, not five competing design systems.

| Area | Plain meaning and category | Consequence for Audit_Mock | Tradeoff or misuse to avoid |
|---|---|---|---|
| Complex application UX | A research/design field addressing specialist, interconnected and nonlinear work | Support incomplete drafts, interruptions, revisiting decisions, parallel work and visible downstream impact | Hiding essential audit relationships to make a screen look simple |
| Enterprise interaction design | Design of actions, feedback and coordination in organisational software | Make authority, exact target, action consequence, ownership and recovery understandable | Treating a partner persona or a hidden button as server authority |
| Information architecture | Organisation and naming of information and routes | Separate firm, client, engagement, workpaper and supporting-record levels; provide multiple entries to one record | One menu item for every table, feature or source screen group |
| Data-dense interfaces | Patterns for comparing and editing substantial structured information | Use well-designed registers, schedules, filters, stable row identity and expandable detail | Shrinking all text or turning narrative judgment into a spreadsheet |
| Case-management workspaces | A family of patterns around a persistent case whose evidence and work evolve | Keep an engagement's work, evidence, decisions, history and responsibilities connected | Treating every task as discretionary or replacing mandatory gates with free-form progress |

The complex-app lens is grounded in [NN/g's five-layer framework](https://www.nngroup.com/articles/complex-application-design-framework/). The engagement-as-case interpretation is our adaptation of [OMG's case-management overview](https://www.omg.org/intro/CMS.pdf). Neither prescribes our audit methodology or requires a new workflow engine.

For this project, the useful decision order is **work and responsibilities → records and relationships → states and handoffs → navigation → page patterns → components and visual system → task validation**. Study how the audit work is performed, including domain constraints; this follows the research approach described by [NN/g's complex-app strategies](https://www.nngroup.com/articles/strategies-complex-application-design/).

## 4. Current implementation assessment

All locators below refer to the local committed tree. Line numbers identify entry points, not proof that every related branch works.

| ID | Code observation and locator | Usability implication or evidence limit | Proposed treatment |
|---|---|---|---|
| OBS01 | `/` renders AuditWorkspaceV2 (`src/app/page.tsx:1`); `/pilot` uses PilotWorkspace | Two product entry points require users to understand implementation history | Select shared pilot services as the behavioural foundation; migrate useful browser interactions deliberately |
| OBS02 | Browser workspace reads/writes `audit-workspace-v5` in localStorage (`audit-workspace-v2.tsx:48–54`) | A browser interaction is not automatically shared team work | Label persistence honestly; never join browser and server state by display name |
| OBS03 | Role MENUS combine home/journey/tasks/calendar/engagements with forms/data/sampling/automation (`audit-workspace-v2.tsx:25`) | Personal, engagement and specialist destinations compete in one hierarchy | Separate scopes; use contextual entries for specialist work |
| OBS04 | Engagement tabs add a second set of destinations (`audit-workspace-v2.tsx:100`) | Potentially competing navigation models; user impact needs observation | One deliberate scope hierarchy and predictable breadcrumbs |
| OBS05 | Shared pilot composes registers, staffing, terms, data, delivery, requests, papers, oversight and release on one page (`pilot-workspace.tsx:474–563`) | Code structure suggests lengthy scanning and weak task focus; no fresh timing or scroll measurement | Split by owning task/record without duplicating those records |
| OBS06 | The shared page maps visible papers into Workpaper components (`pilot-workspace.tsx:509`) and focuses/scrolls to an ID | Opening work is still embedded in a larger workspace composition | Dedicated workpaper route with return context |
| OBS07 | Browser editor already includes work/review/links/history tabs, a section index, dirty state and sticky actions (`workpaper-editor.tsx:49–64`) | Prior useful work exists; it should not be rebuilt as a new invention | Reuse interaction intent, then connect to shared server contracts |
| OBS08 | Shared pilot already uses NativeFields, typed form kinds and pinned template versions (`pilot-forms.tsx:19`; `lib/pilot-forms.ts:3–29`) | All forms are loadable, but loadability is not per-form fidelity | Seven family patterns plus individual source checks |
| OBS09 | Form 1.1.1 source contract includes composite identity wording and choice metadata; browser editor suppresses selected composites in favour of linked identity (`workpaper-editor.tsx:21,53`) | Do not claim every field is still a textbox; coverage differs by surface | Reconcile each field's owner, type and source anchor |
| OBS10 | Requests contain dispatch states, accepted parts, replacements and use history (`pilot-workspace.tsx:158–241`) | Substantive domain behaviour already exists | Design a register/detail interaction around it, retaining partial and returned cases |
| OBS11 | PopulationDesk exposes raw-source, quarantine, mapping and reconciliation sections (`pilot-population.tsx:23–108`) | There is a connected data foundation; broader profiles remain functional work | Make this a purposeful data-preparation workspace |
| OBS12 | SampleDesk, JournalDesk and AreaDesk attach to owning papers (`pilot-workspace.tsx:513–522`) | Good domain association can be retained even when layout changes | Contextual run detail and a central index of the same runs |
| OBS13 | Save and submit are separate in the shared paper (`pilot-workspace.tsx:342–366`) | Universal Next would obscure meaningful distinctions | Preserve explicit transitions; add navigation separately |
| OBS14 | Shared commands send a revision and idempotency key (`pilot-workspace.tsx:442–445`); server rejects a stale revision (`pilot-server.mjs:317`) | Existing safeguards need an understandable recovery UI | Show what changed, preserve the user's input and offer an explicit retry after reconciliation |
| OBS15 | Release binds authorization, signing, delivery and sealing to package state (`pilot-workspace.tsx:529–560`) | These are separate responsibilities and events, not one Finish button | Dedicated exact-package decision and distribution surfaces |
| OBS16 | A scoped form-library model includes grants, drafts, publication versions and engagement adoption (`lib/pilot-forms.ts:19–29`; `pilot-workspace.tsx:473,496`) | Configuration is already part of the product | Give it a purposeful authoring workspace and adoption preview |
| OBS17 | Global CSS uses teal/green accents and several shared classes | User dislikes the visual direction; contrast and perceived density were not freshly measured | Replace through semantic tokens and realistic comparisons; retain light/dark scope |
| OBS18 | office-preview.ts includes a bounded Office parser and workbook reading | Some preview/import support exists; it is not a complete Office application | Specify supported previews and explicit readable-download fallbacks |

### Representative workflow assessment

| Journey | Foundation observed or saved evidence | Redesign focus | Still needs functional/source work |
|---|---|---|---|
| Prepare → evidence → submit | Typed papers, evidence links and separate save/submit commands | Focused paper, relevant evidence beside it, visible blockers | All form fidelity and required dependencies |
| Review → return → correct → clear | Notes, response history and exact-version review; saved A25 scenario | Review queue to exact revision and anchor; clear role handoff | Broader row-level anchors and source-specific rules |
| Request → receive → assess → rely | Multipart request and version/use history | Request inspector, missing items, context-specific assessment | External effects, confirmation alternatives and missing/contradictory evidence |
| Import → validate → approve → use | PopulationDesk and saved A11 provenance scenario | Original-to-approved chain, row-level problems and downstream impact | Additional profiles, methods and failure cases |
| Conclude → authorize → issue → custody | Substantial shared services and saved A28 route | Exact-package preview, blockers, recipient outcomes and independent custody | A26/A27 closure and additional later-fact variants |

These are inspection-based journey assessments. They are not newly executed browser journeys.

## 5. Recommended interaction model and alternatives

| Model | Strength | Main weakness for this project | Decision |
|---|---|---|---|
| Personal task queue as the whole product | Clear daily priorities | Harder to reconstruct the engagement and investigate across papers | Use as a role's starting view |
| Workpaper/engagement-centred | Strong record context and direct access | Can become a document catalogue with weak handoffs | Use as the core workspace with visible next owners |
| Lifecycle wizard as the whole product | Orientation and initial guidance | Audit work loops, branches and proceeds in parallel | Use only for bounded suitable tasks |
| Recommended hybrid | Combines personal entry, stable records and contextual guidance | Requires carefully defined routes and action semantics | Prototype and validate before broad implementation |

Caseware documents both phase navigation and direct document access ([AUD01](https://documentation.caseware.com/2025/Audit/27_00/en/Content/User_Client_File_Setup/c_Work_Flow_Panel_Work_Flow_Panel.htm)). This supports offering orientation alongside direct work access; it does not establish that form numbers are execution order.

### Navigation proposal to test

**Firm scope:** My Work; Clients & Engagements; Calendar. Under actual additional authority: Methodology Library, People & Capacity, Access & Administration. Include independent quality/custody queues when assigned.

**Engagement scope:** Overview/readiness; Work & Planning; Evidence & Requests; Data & Analysis; Findings & Completion; Reviews; Reporting & Final File. These are candidate group names. They must pass terminology and findability checks with Mongolian labels. Individual destinations such as risks, confirmations, samples, consultation and archive remain directly addressable within their owning group.

**Workpaper scope:** substantive sections; linked evidence and data; related risks/procedures/runs; review notes; exact revisions. Full-page working view, optional context panel, expandable to wide schedules.

The 25 source screen groups describe capabilities and entry points. They do not require 25 permanent menu items. Preserve S01–S25 traceability while testing fewer coherent groups.

### What “one window” should mean

One coherent working context, with clear related records and return paths. It should permit a queue or index, a focused paper and optional evidence/review context, rather than displaying every engagement function at once. [SAP's layout guidance](https://www.sap.com/design-system/fiori-design-web/v1-136/page-types/floorplan-overview) offers relevant full-page/list-detail precedents.

Keep normal browser back/forward, stable links and opening an authorised record in another tab. On narrower screens, collapse context or open it as a dedicated destination with return state. Do not confine substantive work to a permanent half-width drawer. “One window” is not a source-backed requirement to prohibit multiple tabs.

## 6. Principles to adopt, adapt or reject

| Principle | Decision and audit-specific meaning | Concrete validation |
|---|---|---|
| Task and object orientation | Adopt: queues open the owning engagement/work record | The same paper ID opens from queue, index and calendar |
| Stable context | Adopt: client, entity, period, reference and version stay apparent | Switch engagements and return without wrong-period writes |
| Role-specific entry | Adapt: assignments and actual capacity determine available work | An authorised senior may prepare; quality does not imply administration |
| Progressive disclosure | Adapt: secondary history/help may collapse; required work and blockers remain discoverable | Incomplete evidence cannot disappear behind an unlabelled section |
| Full-page workpapers | Adopt: retain the user's earlier direction | Five representative families usable without a mandatory expand step |
| Context beside work | Adapt: evidence/notes on demand, expandable | Inspect source and return without losing unsaved answers or row selection |
| Compactness | Adapt by content type, not one small scale for all screens | Long labels and numerical schedules remain legible and operable |
| Next action | Adapt: next navigation differs from save/submit/approve | Advancing a section cannot create a sign-off |
| Autosave | Conditional: only after draft/version semantics and recovery are specified | A saved draft is never presented as submitted or approved |
| Visible change impact | Adopt: show affected consumers and why they reopened | Revising 1.3 identifies affected sampling without reopening unrelated work |
| Configurable forms | Adopt with scoped grants, release/adoption and prior-answer preservation | An author of one template cannot change another or bypass shared gates |
| Universal wizard/four signatures | Reject | Workflow follows actual applicability and required authority |
| Completion by task count or green colour | Reject | Distinguish prepared, reviewed, waiting, blocked and independently accepted |

## 7. Forms, density, colour and actions

### Seven families, 70 fidelity records

The current source catalogue classifies **32 questionnaires, 23 programmes, seven documents, four registers, two strategies, one calculation and one sampling form**. Reuse suitable family components, while retaining a source-linked fidelity record for every form.

The repaired sheets include purpose, answer-location guidance, categorical options, responsibility, ERD and standards annotations. These are design inputs and source locators; they are not all columns to display to the preparer. Extremely wide used ranges partly reflect reference metadata and formatting. Reproducing their physical width in the browser would confuse the work surface with its specification.

The 272 formulas require classification. For example, Stage 3 sheet 3.1.2А contains incrementing row-number formulas in B11 onward. Those should not become 272 assumed business-automation requirements. Conversely, a count of formulas cannot establish completeness of materiality or sampling, whose professional behaviour is specified elsewhere.

Use explicit field types, stable repeated row IDs, units and dates. Preserve zero, false, missing, unknown and N/A with its rationale. Prefilling should expose the source and version; previous-period conclusions and approvals cannot silently become current decisions.

### Density rules to prototype

Use compact headers and grouped short fields, readable narrative areas, editable schedules for repeating rows, sticky orientation in long tables, filters and context detail. [Carbon's form guidance](https://www.carbondesignsystem.com/building-blocks/core/patterns/forms) supports grouping related fields while preserving a clear reading order. Its [table guidance](https://www.carbondesignsystem.com/building-blocks/core/components/data-table/guidelines) documents multiple density levels; select ours through real-content tests rather than copying a number.

Prototype at 1366×768 and 1440×900, plus 200% zoom and narrow reflow checks. These are proposed test conditions, not established user hardware. Wide schedules may require controlled horizontal scrolling; surrounding controls and narrative should remain usable. Keyboard access, focus visibility and sufficient pointer targets remain requirements under the proposed [WCAG 2.2 AA](https://www.w3.org/TR/wcag/) baseline.

### Visual direction

Compare two restrained directions on the same paper: neutral/slate surfaces with a blue accent, and a slightly warmer neutral surface with an ink/indigo accent. These are proposals, not research-proven palettes. Use semantic tokens for text, surfaces, borders, focus, selection and states. Reserve positive-state green for an appropriate meaning with a text/icon label. Preserve the plan's light/dark scope; prepare both from shared tokens before expanding every screen.

Evaluate hierarchy, reading comfort, state clarity, long Mongolian labels and table comparison. [Refactoring UI](https://refactoringui.com/) is useful for visual tactics. It does not determine the underlying audit workflow.

### Action vocabulary

| Intent | Proposed label | Must not imply |
|---|---|---|
| Navigate inside work | Next section / Previous section | Save or submit |
| Persist editable draft | Save draft, or visible saved-draft status if autosave is approved | Review acceptance |
| Send prepared revision | Submit for review | Reviewer approval |
| Request correction | Return with note | Deletion of prior submission |
| Resolve discussion | Respond; reviewer separately clears | Preparer self-clearance |
| Advance through queue | Open next assigned paper | Completion of current paper |
| Approve report package | Authorize this package | Signing, dispatch or receipt |

Use guided steps for tasks with real prerequisites. Do not turn recurring preparation into a wizard merely to add a Next button. [SAP's wizard guidance](https://learning.sap.com/courses/ui-development-with-sap-fiori/working-with-sap-fiori-design-guidelines_ab11c169-54de-4f51-87b9-f61c8a5198be) explicitly discusses that tradeoff. Draft behaviour requires its own contract, as illustrated by [SAP draft handling](https://www.sap.com/design-system/fiori-design-web/v1-148/foundations/best-practices/global-patterns/object-handling/draft-handling).

## 8. Comparison from research to current app

| Pattern/evidence | Current evidence | Proposed change | Risk/dependency | Acceptance |
|---|---|---|---|---|
| Scoped shell, REF09 | OBS03/04 | Firm → engagement → work navigation | Hiding specialist destinations | Every source screen group has a tested home and direct link |
| Full page/context, REF05/REF03 | OBS05–07 | Dedicated paper with optional evidence/review panel | Narrow laptop width; unsaved drafts | Expand/collapse preserves input, focus and return location |
| Operational index, AUD03 | OBS06/08 | Filterable paper/procedure register | Incomparable status meanings | Separate owner, preparer state, review, blocker and next action |
| Request inspector, AUD06 | OBS10 | Table → request details/comments/history | Receipt confused with acceptance | Partial receipt retains required outstanding items |
| Source/result investigation, AUD07/08 | OBS11/12 | Run detail with versions, results and exception dispositions | Method scope still unfinished | Unsupported inputs blocked; rerun retains prior results |
| Blank conclusions, AUD05 | Form-family contracts | Explicit unanswered judgment and applicability | False completion through defaults | No new form begins with a positive professional conclusion |
| Related planning, AUD02 | Planning/sample shared components | Risks → assertions → responses → tests | Multi-risk support still open in R12 | Multiple relationships have a representable layout and source IDs |
| Separate review capacity, source roles | OBS14/15 and role model | Contextual role action sets and independent desks | Role seniority mistaken for authority | Denied direct links and legitimate lower-capacity work both tested |
| Case workspace, REF11 | OBS05/15 | Persistent context with branching work and accountable blockers | Optional steps mistaken for waived gates | Missing evidence produces owned further work, not automatic completion |
| Accessible density, REF07/08/12 | CSS/form code; no fresh visual audit | Content-appropriate controls and schedules | Compactness hides labels or focus | Keyboard/zoom/long-text checks before adoption |

## 9. Compatibility with unfinished development

**Compatibility is a design obligation, not a promise that redesign causes no rework.** Layout and navigation will change browser tests and may expose missing service operations. Preserve domain invariants and make necessary contract changes explicit.

### Contracts to preserve

- Stable client, engagement, workpaper, field/row, evidence and source IDs; entity/period scope and real access checks.
- Exact template, input, submission, review, report and archive versions, with prior decisions preserved.
- Draft/save/submit/return/respond/clear/approve as distinct actions with their applicable prerequisites.
- Accepted originals, source hashes, mappings, population lineage, sample design/selection and run history.
- Explicit professional decisions and supporting authority. A software result is not an auditor's conclusion.
- Revision checks, transactional boundaries, idempotent retries and actual attempted/failed/partial/received external outcomes.
- Scoped template authoring, separate publication/adoption and compatible answer migration.
- Source scope: 127 core feature contracts, eight conditional follow-up features, one excluded consolidation feature, 58 minimum automations and 58 scope-pending future rows.

### Coverage and known conflicts

**Source_Compatibility_Matrix.csv** retains all **2,247 existing closure rows**, their scope/status/hash, proposed functional owner and related design tasks. Its proposed design mappings are based on the existing owning packages and explicit row kind; they are not a new acceptance audit. **Lifecycle_Compatibility.csv** retains all 51 cycle entries. **Remaining_Plan_Crosswalk.csv** retains all 128 tasks across R00–R24. **Redesign_Compatibility.csv** separately assesses each of the 30 proposed redesign items against E2E, feature, data and automation work.

| Future work | What the redesign must provide | Functional work remains with |
|---|---|---|
| 70 faithful forms and 20 confirmed dependencies | Seven family patterns, source anchors, typed rows and visible linked-fact provenance | R07/R09 |
| Builder/import/release/adoption | Scoped authoring workspace, mapping/error preview, release comparison and explicit adoption | R08/R10 |
| New/continuing intake, independence and terms | Incomplete enquiries, decision queues and exact signed-term context | R09–R11 |
| Multi-risk/controls/opening balances | Many-to-many relationships and targeted reassessment | R12 |
| Additional imports, mapping and data integrity | Profile-neutral data workspace with raw/quarantined/accepted views | R13 |
| Evidence/confirmations and failure branches | Separate request, receipt, assessment, use and external dispatch state | R14 |
| Sampling and all 22 area variants | Selection/testing detail and family-specific fields; extension points for further methods | R15/R16 |
| All 58 automation minimums | Inputs → method/version → result → exceptions → human disposition → downstream use | R13–R21 as already assigned |
| Fraud, specialists, estimates and technical matters | Scoped cases, restricted discussions, contributions and escalation | R17 |
| Findings, corrections and completion | Agreed correction distinct from verified posting; unresolved amounts and reporting consequences | R18 |
| Consultation, review and independent quality | Assigned capacity, exact package, response/clearance separation and renewed review | R19 |
| Issue, custody, later facts | Exact-package authorisation; partial delivery; successor/original lineage and independent custody | R20/R21 |
| Operations and source acceptance | Recoverable failures, configuration, cutover evidence and separate release decisions | R22/R23 |
| Wider firm/service/future automation scope | Extension destinations and preserved IDs, without implying implementation or new mandate | R24 |

Conflicts to resolve before integration: local versus server identity/state; one universal Next versus real transitions; stale drafts after concurrent edits; row/field IDs after template changes; overly rigid form layouts; over-compressed evidence previews; role-specific menus that hide legitimate assigned work; and old browser tests coupled to page structure.

No database redesign, CMMN migration, new component framework or replacement automation engine is justified by this UX study. Add an adapter or endpoint only when a required interaction exposes a concrete missing capability, and record the affected source/test contract.

## 10. Proposed sequence

1. **Research-to-design handoff:** approve the principles, compatibility rules, candidate navigation and first-prototype scope. UX-00–05 and UX-25 define the foundation and validation plan.
2. **Design a representative journey:** tokens, density, five form-family examples, evidence context, review/return, queues, import/run results, and a quality/custody handoff. Review static/wireframe alternatives before implementation. No new forms or mockups were built in this research.
3. **Implement one integrated slice after approval:** use existing shared services. Prove preparation → exact submission → returned note → correction → clearance, then a changed source and a second engagement to expose scope mistakes.
4. **Expand in compatible families:** connect the remaining screens through the same identity, action and version rules. Reconcile each form and source row independently.
5. **Resume and continue functional batches:** R20/R21 issue-to-custody remains the prior proposed next connected functional batch; broader R07–R19 work remains open. Do not require every cosmetic screen to be complete before functional engineering continues.
6. **Retire an old route only after replacement evidence:** compare records, versions, grants, approvals, evidence and package hashes. Keep rollback and old-data recovery until cutover acceptance.

Can continue independently once interfaces are agreed: domain calculations with independent expected results, import parsers/profiles, rule-edition validation, source reconciliation, persistence/concurrency/access tests, external-adapter contracts and scenario fixtures. Coordinate record/response schema changes with the design owner. Browser layout work and route-specific tests should follow the agreed shell/paper slice.

UX-26's dependencies mean agreed contracts/patterns and the representative slice. They do not require completion of every form, import profile, area variant or automation before a prototype can be tested. Full-scope implementation and source acceptance remain under UX-27–29 and the original R owners.

## 11. First-prototype brief and validation

Use two synthetic engagements with realistic Mongolian labels. Include forms **1.1.1, 1.3, 3.1.2, 3.3.1 and a completion/review paper**, plus a narrative document and a long repeated schedule where needed to cover all interaction families. The initial prototype is bounded; it is not the complete release.

Scenarios:

1. Preparer finds assigned work, opens the full paper, edits structured answers and saves/reloads.
2. The preparer inspects supporting PDF/photo and Excel/Word content or a clear readable-download fallback, links the exact source and submits.
3. Senior opens the submitted revision from the review queue, inspects evidence and returns a field/row-anchored note.
4. Preparer responds, corrects and resubmits. Senior clears the actual response and reviews the current revision.
5. Materiality or accepted population changes; only dependent work is flagged with the reason, previous version and next owner.
6. Switch engagements, open a deep link, use back/forward, resume a draft and encounter a revoked grant or stale revision.
7. Partner inspects exact package readiness. Independent quality/custody users can locate their assigned material without acquiring general partner authority.
8. Author changes one authorised template; publication/adoption preview retains prior signed answers and cannot change another template.

Evaluate task completion without coaching, wrong-record/period actions, missed blockers, ability to explain source/version, lost input, review mistakes and interruption recovery. Record time and navigation only after defining a comparable baseline; no time-saving target is claimed here. Include keyboard-only use, focus, zoom and long labels. Use actual authorised practitioners for each responsibility where available; distinguish a person performing multiple roles from independent-review eligibility.

Design acceptance requires no lost data, no wrong-context mutation, no unintended approval, understandable blockers and successful main handoffs. These are proposed criteria for agreement, not results already achieved. Separate this usability acceptance from full functional/source release acceptance.

## 12. Questions that require domain validation

- Which records do preparers and seniors compare most frequently, and on what laptop/display arrangements?
- Which labels and groupings make sense in Mongolian to actual auditors? Candidate English names are not final menu labels.
- Which work requires R2/R3/R4, and when is formal EQR separately required? Preserve existing recorded policy and resolve D05/D06/D18 with the methodology owner.
- Which form changes are engagement tailoring versus controlled methodology release, and which content/gates cannot be removed by an author?
- Which received file formats need inline fidelity versus readable download, and what evidence volumes must the viewer handle?
- What draft persistence and conflict recovery are acceptable when two people edit or review concurrently?
- Which source ownership, identity, external delivery/signing and retention decisions remain unresolved under D01–D29?

These questions do not stop all design work. They identify where prototype assumptions must remain explicit and where implementation must await a concrete policy or service contract.

## 13. Deliverables and status

- **Redesign_Work_List.md / Redesign_Backlog.json:** 30 proposed work items with subtasks, dependency order, owners, relative effort, acceptance and compatibility.
- **Research_References.md:** annotated source library, including all previously discussed reference families and ten audit-product families.
- **Redesign_Compatibility.csv:** E2E/feature/data/automation impact for every proposed redesign item.
- **Remaining_Plan_Crosswalk.csv:** all 128 existing remaining-plan tasks with proposed design connections and preserved functional ownership.
- **Source_Compatibility_Matrix.csv / Lifecycle_Compatibility.csv / Screen_Coverage.csv:** preserved source-level and navigation traceability.
- **Form_Family_Review.csv / Automation_UX_Contracts.csv:** all 70 form families and all 58 minimum automation interaction contracts, with preserved source locators and explicit remaining validation.
- **Source_Review_Register.csv / evidence/:** source inventory, workbook structure, baseline/version evidence and a limited history extract. Research maps are proposals; original completion/status/hash values remain unchanged.

The application has not been redesigned. The next decision is whether to proceed with the proposed design/prototype batch and its validation scope.
