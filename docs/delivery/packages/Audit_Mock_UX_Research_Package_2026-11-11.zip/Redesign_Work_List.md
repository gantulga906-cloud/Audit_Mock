# Audit_Mock redesign work list

11 November 2026. All 30 items below are proposed. No application redesign has started.

Read Audit_Mock_UX_Research.md for findings and limitations. This list supplements R00–R24; it does not replace or reduce their functional scope.

## Recommended order

1. Agree baseline, work model, navigation, actions, compatibility and prototype brief.
2. Specify shared visual/interaction rules and representative working screens.
3. Implement and test one connected slice after design approval.
4. Expand by families while functional service work continues behind agreed contracts.
5. Finish independent source/operational acceptance before retiring old routes.

UX-28 can run after its contract prerequisites. It does not depend on completing every visual screen. UX-26 needs agreed patterns and its representative slice, not complete implementation of every upstream form, profile or automation. Full-scope completion remains under UX-27/28/29 and the original R owners. Relative effort is complexity, not a calendar promise. Owner roles require assignment.

## Work index

| ID | Work | Priority | Effort | Existing packages |
|---|---|---|---|---|
| UX-00 | Pin the redesign baseline and regression obligations | P0 | S | R00, R23 |
| UX-01 | Validate real work and role responsibilities | P0 | M | R01 |
| UX-02 | Define record, relationship and authority rules | P0 | M | R00, R02, R09, R10, R24 |
| UX-03 | Design and test the navigation architecture | P0 | M | R02, R24 |
| UX-04 | Specify states, draft behaviour and action vocabulary | P0 | M | R03, R04, R09, R19 |
| UX-05 | Specify the persistent shell, context and links | P0 | M | R02, R06 |
| UX-06 | Define visual tokens and compare two directions | P0 | M | R03 |
| UX-07 | Define compact form and dense table patterns | P0 | M | R03, R04, R07 |
| UX-08 | Create the 70-form fidelity and family specification | P0 | L | R04, R07, R16 |
| UX-09 | Design the full-page workpaper experience | P0 | L | R04 |
| UX-10 | Design typed answers, linked facts and roll-forward | P0 | L | R04, R07, R09 |
| UX-11 | Design evidence library, preview and anchors | P0 | L | R04, R05, R14 |
| UX-12 | Design request and confirmation case workspaces | P0 | M | R05, R14 |
| UX-13 | Design the data-preparation workspace | P0 | L | R05, R13 |
| UX-14 | Design versioned automation and exception investigation | P0 | L | R05, R13, R15, R16, R17, R18, R19, R20, R21 |
| UX-15 | Design risk, programme, sampling and technical work | P0 | L | R09, R12, R15, R16, R17 |
| UX-16 | Design review, response and targeted change impact | P0 | L | R04, R09, R17, R19 |
| UX-17 | Design personal work and decision queues | P0 | M | R06 |
| UX-18 | Design calendar, Gantt, workload and effort views | P0 | L | R06, R10 |
| UX-19 | Design clients, enquiries, acceptance and period setup | P1 | L | R09, R10, R11 |
| UX-20 | Design findings, completion and report decisions | P1 | L | R06, R17, R18, R20 |
| UX-21 | Design independent quality, custody and later facts | P1 | L | R06, R10, R19, R21 |
| UX-22 | Design controlled form authoring, import and adoption | P1 | L | R08, R10, R24 |
| UX-23 | Specify accessibility and complete interaction states | P0 | L | R03, R10, R22 |
| UX-24 | Specify adapters, migration and incremental cutover | P0 | L | R00, R06, R22, R23 |
| UX-25 | Approve the first-prototype brief and test protocol | P0 | M | R01, R04, R05, R06 |
| UX-26 | Implement and validate the approved connected prototype | P0 | L | R04, R05, R06 |
| UX-27 | Expand by screen and form families with source reconciliation | P1 | XL | R02, R03, R07, R08, R09, R16, R24 |
| UX-28 | Continue functional batches alongside the agreed UI contracts | P1 | XL | R07, R09, R11, R12, R13, R14, R15, R16, R17, R18, R19, R20, R21, R22 |
| UX-29 | Complete regression, independent acceptance and retirement | P1 | XL | R22, R23 |

## UX-00 — Pin the redesign baseline and regression obligations

**Stage:** Foundation and agreement. **Priority/effort:** P0 / S. **Proposed owner:** Tech lead + QA.
**Packages:** R00, R23. **Depends on:** Baseline only. **Users:** All responsibilities.

Two surfaces and historical evidence can be mistaken for the same working product.

**Concrete work**

- [ ] Record local/remote file equality, build identity, source hashes and available fixtures.
- [ ] Classify each principal action as shared, local, illustrative, partial or unverified.
- [ ] Register A08/A11/A25/A28 regression paths and source obligations before changes.

**Done when**

- A new contributor can reproduce the baseline and identify untested claims.
- Every migrated route names its service owner and required regression.

**Preserve:** IDs, versions, current source scope and evidence statuses.
**Adaptation/conflict:** Fresh browser baseline is still required; this research did not establish visual or browser conformance.

| Future development | Compatibility requirement |
|---|---|
| E2E | Retain 51 cycle IDs and their current evidence. |
| Features | Retain 136 source feature rows and dispositions. |
| Data | Preserve dataset/evidence/package identities. |
| Automation | Retain all 58 minimum and 58 future rows separately. |

**Research references:** REF02; see Research_References.md.

## UX-01 — Validate real work and role responsibilities

**Stage:** Foundation and agreement. **Priority/effort:** P0 / M. **Proposed owner:** Product designer + senior auditor.
**Packages:** R01. **Depends on:** UX-00. **Users:** Preparer, senior, partner, quality, custodian.

Desk research cannot establish which comparisons, interruptions and handoffs dominate daily work.

**Concrete work**

- [ ] Walk through preparation, review, evidence investigation, data acceptance and issue/custody with domain users.
- [ ] Capture the records users compare, interruptions, current terminology and screen constraints.
- [ ] Keep an assumption/decision log and identify policy questions separately.

**Done when**

- Each principal task has an actor, trigger, inputs, output, next owner and material return case.
- Findings distinguish observed work from proposed improvements.

**Preserve:** Actual assigned capacity and source-defined boundaries.
**Adaptation/conflict:** Do not invent extra approvals or infer authority from job title.

| Future development | Compatibility requirement |
|---|---|
| E2E | Use representative source journeys, not one invented happy path. |
| Features | Capture required work outside form entry. |
| Data | Include incoming-file and changed-source work. |
| Automation | Ask how users investigate and decide on results. |

**Research references:** REF01, REF02; see Research_References.md.

## UX-02 — Define record, relationship and authority rules

**Stage:** Foundation and agreement. **Priority/effort:** P0 / M. **Proposed owner:** Domain architect + methodology/access owners.
**Packages:** R00, R02, R09, R10, R24. **Depends on:** UX-00. **Users:** All, including template authors and support roles.

Presentation can accidentally collapse different records, responsibilities or version meanings.

**Concrete work**

- [ ] Map client → enquiry → engagement → period/work → evidence/run/decision relationships.
- [ ] Define real capacity/grants, exact versions and field/row identities behind each action.
- [ ] Identify concrete gaps in D01–D29 and assign decisions without treating old proposals as approved policy.

**Done when**

- Every proposed screen/action names its owning record and permission check.
- Configurable R1–R4 requirements and formal EQR remain distinct.

**Preserve:** Scope isolation, exact review targets, stable logical and physical version identities.
**Adaptation/conflict:** UI-only role checks or wholesale ERD replacement are not acceptable adaptations.

| Future development | Compatibility requirement |
|---|---|
| E2E | Handoffs retain actor and actual capacity. |
| Features | Forms, administration and custody keep different authorities. |
| Data | Relationships cannot silently merge client or source identities. |
| Automation | Run identity and judgment owner remain separate. |

**Research references:** REF11; see Research_References.md.

## UX-03 — Design and test the navigation architecture

**Stage:** Foundation and agreement. **Priority/effort:** P0 / M. **Proposed owner:** Designer + frontend lead.
**Packages:** R02, R24. **Depends on:** UX-01, UX-02. **Users:** All responsibilities.

Current menus mix personal, engagement and specialist destinations.

**Concrete work**

- [ ] Specify firm, engagement and workpaper navigation with candidate Mongolian labels.
- [ ] Map all S01–S25 groups and scope-pending destinations to owning sections and direct links.
- [ ] Test where users expect to find risk, sample, confirmation, review, builder and custody actions.

**Done when**

- Every source screen group has a home without requiring 25 sidebar links.
- Users can distinguish client-wide facts from current-period engagement work.

**Preserve:** Source capability coverage and permission-scoped discovery.
**Adaptation/conflict:** Reducing menu entries must not remove workflows; role defaults must allow legitimate assigned lower-capacity work.

| Future development | Compatibility requirement |
|---|---|
| E2E | All cycle entry/handoff points remain reachable. |
| Features | No source feature vanishes through grouping. |
| Data | Data and evidence remain distinct related destinations. |
| Automation | Runs accessible from owning work and an analysis index. |

**Research references:** REF03, REF09, AUD01, AUD04; see Research_References.md.

## UX-04 — Specify states, draft behaviour and action vocabulary

**Stage:** Foundation and agreement. **Priority/effort:** P0 / M. **Proposed owner:** Designer + domain/frontend leads.
**Packages:** R03, R04, R09, R19. **Depends on:** UX-02. **Users:** Preparers and decision-makers.

A generic Next or autosave indicator can obscure a professional transition.

**Concrete work**

- [ ] Create an action/state matrix for save, section navigation, submit, return, respond, clear, review and authorization.
- [ ] Define incomplete-draft rules, save feedback, unsaved navigation and revision-conflict recovery.
- [ ] Define bounded wizards and direct-access alternatives; document when Next is navigation only.

**Done when**

- Next section never signs, submits or approves.
- A failed/stale save preserves recoverable input and explains the next step.

**Preserve:** Existing transition guards, blank judgments, revision checks and actual event history.
**Adaptation/conflict:** Autosave requires a draft contract; do not mutate a submitted/reviewed snapshot on every keystroke.

| Future development | Compatibility requirement |
|---|---|
| E2E | Material return and blocked cases remain explicit. |
| Features | State vocabulary applies across all feature families. |
| Data | Blank/zero/unknown/N/A stay distinguishable. |
| Automation | Run completion does not imply reviewed audit conclusion. |

**Research references:** REF06, REF10, AUD05; see Research_References.md.

## UX-05 — Specify the persistent shell, context and links

**Stage:** Shared interaction and visual rules. **Priority/effort:** P0 / M. **Proposed owner:** Designer + frontend lead.
**Packages:** R02, R06. **Depends on:** UX-03, UX-04. **Users:** All responsibilities.

Users need one working context without being trapped on one long page.

**Concrete work**

- [ ] Define context header, breadcrumbs, permission-aware navigation and durable object URLs.
- [ ] Specify back/forward, new-tab, engagement switch, filtered-list return and interruption recovery.
- [ ] Design full-page and optional-context behaviour for laptop and narrow widths.

**Done when**

- A paper opens from queue, calendar and index using the same ID.
- Opening evidence or switching context does not silently lose a draft.

**Preserve:** Engagement/entity/period identity, access checks and return state.
**Adaptation/conflict:** Existing scroll-to-paper and hash/query conventions need an explicit redirect/migration plan.

| Future development | Compatibility requirement |
|---|---|
| E2E | Cross-role deep links still resolve to permitted work. |
| Features | One shell does not mean one giant component or one copy per view. |
| Data | Evidence/source anchors travel with links. |
| Automation | Result links identify the exact run. |

**Research references:** REF05, REF09; see Research_References.md.

## UX-06 — Define visual tokens and compare two directions

**Stage:** Shared interaction and visual rules. **Priority/effort:** P0 / M. **Proposed owner:** Product designer + frontend lead.
**Packages:** R03. **Depends on:** UX-03. **Users:** All, including long Mongolian labels.

The current visual direction is disliked and hardcoded styling risks inconsistency.

**Concrete work**

- [ ] Compare neutral/slate-blue and warm-neutral/ink directions using identical realistic content.
- [ ] Define semantic typography, surface, border, focus, selection and status tokens.
- [ ] Specify light and dark modes for core controls, tables, panels and dialogs.

**Done when**

- The chosen direction remains readable with long names, returned work and missing evidence.
- Statuses use text/icon meaning and both themes have measurable contrast checks.

**Preserve:** Status meanings, substantive content and existing light/dark scope.
**Adaptation/conflict:** Do not select colours by assuming they improve trust or speed without evaluation.

| Future development | Compatibility requirement |
|---|---|
| E2E | States remain legible in every branch. |
| Features | Shared tokens apply across authoring and operational screens. |
| Data | Numerical signs, units and errors remain clear. |
| Automation | Success colour does not imply accepted/reviewed results. |

**Research references:** REF04, REF12; see Research_References.md.

## UX-07 — Define compact form and dense table patterns

**Stage:** Shared interaction and visual rules. **Priority/effort:** P0 / M. **Proposed owner:** Designer + auditor + frontend lead.
**Packages:** R03, R04, R07. **Depends on:** UX-01, UX-06. **Users:** Preparers, reviewers, data users.

Reducing space indiscriminately could make schedules and judgments harder to use.

**Concrete work**

- [ ] Specify short-field groups, narrative widths, repeating schedules and optional density levels.
- [ ] Define filters, visible columns, numeric alignment, row expansion and safe bulk operations.
- [ ] Test long labels, sticky orientation, 200% zoom, keyboard use and controlled horizontal scrolling.

**Done when**

- Compact mode preserves readable labels, required content and usable controls.
- Long financial schedules retain row identity and source context during filtering.

**Preserve:** Field meaning, stable row IDs, units and accessible operation.
**Adaptation/conflict:** No compressed mini-grid for narrative judgment; bulk actions must follow actual authority.

| Future development | Compatibility requirement |
|---|---|
| E2E | High-volume tasks remain efficient without changing gates. |
| Features | Reusable patterns accommodate custom forms. |
| Data | No clipped amounts or hidden quarantine explanations. |
| Automation | Exception tables support individual dispositions. |

**Research references:** REF07, REF08, REF12; see Research_References.md.

## UX-08 — Create the 70-form fidelity and family specification

**Stage:** Shared interaction and visual rules. **Priority/effort:** P0 / L. **Proposed owner:** Form/domain lead + methodology owner.
**Packages:** R04, R07, R16. **Depends on:** UX-00, UX-02, UX-07. **Users:** Preparers, reviewers, authors.

A catalogue of 70 forms is not evidence of 70 faithful native interactions.

**Concrete work**

- [ ] Classify every form into the seven existing families and document meaningful fields/schedules.
- [ ] Classify the 272 formulas and 1,820 validation objects as numbering, layout, input constraints or operative behaviour.
- [ ] Retain source sheet/cell anchors, source conflicts and required per-form exceptions.

**Done when**

- Each form has an individual field/fidelity record and applicable acceptance scenario.
- Reference annotations are separated from actual auditor inputs.

**Preserve:** All 70 IDs, Mongolian wording, source anchors and conditional applicability.
**Adaptation/conflict:** Physical workbook width and formula count must not become UI or automation requirements by assumption.

| Future development | Compatibility requirement |
|---|---|
| E2E | Applicable procedure and form variants remain represented. |
| Features | Full form fidelity remains R07 work. |
| Data | Typed amounts, dates and repeats preserve meaning. |
| Automation | Operative formulas route to reviewed calculation contracts, not blind cell copying. |

**Research references:** REF07, AUD05; see Research_References.md.

## UX-09 — Design the full-page workpaper experience

**Stage:** Shared interaction and visual rules. **Priority/effort:** P0 / L. **Proposed owner:** Designer + frontend lead + preparer.
**Packages:** R04. **Depends on:** UX-04, UX-05, UX-07, UX-08. **Users:** Preparers and reviewers.

Shared pilot papers are embedded in a large page; the useful browser full-page editor needs consolidation.

**Concrete work**

- [ ] Define paper header, sections, owner/reviewer/version, visible gaps and stable section navigation.
- [ ] Reuse the intent of the existing full-page editor without importing browser-local state.
- [ ] Specify wide schedules, history access and an optional evidence/review panel.

**Done when**

- 1.1.1, 1.3, 3.1.2, 3.3.1 and a completion paper open directly without a mandatory expand-all step.
- Save/reload, submission and return-context rules work on shared records.

**Preserve:** Exact work identity, required sections and submitted/reviewed snapshots.
**Adaptation/conflict:** Do not recreate a half-width default form drawer or duplicate the editor model.

| Future development | Compatibility requirement |
|---|---|
| E2E | Same owning paper supports all cycle entries. |
| Features | Retain custom form/family extension points. |
| Data | Linked facts and source data are accessible. |
| Automation | Applicable run outputs appear in owning work. |

**Research references:** REF03, REF05; see Research_References.md.

## UX-10 — Design typed answers, linked facts and roll-forward

**Stage:** Shared interaction and visual rules. **Priority/effort:** P0 / L. **Proposed owner:** Form/data lead + methodology owner.
**Packages:** R04, R07, R09. **Depends on:** UX-02, UX-04, UX-08. **Users:** Preparers, reviewers, authors.

Repeated entry and ambiguous composite answers can undermine both usability and provenance.

**Concrete work**

- [ ] Specify meaningful controls for identity, legal form, dates, options, amounts and contacts.
- [ ] Map all 20 confirmed dependencies to target fields/actions and their approved source versions.
- [ ] Design current-period confirmation, source-change warnings and compatible row/answer carry-forward.

**Done when**

- Zero, false, missing, unknown and N/A retain different meanings.
- A revised source affects only relevant targets and preserves prior relied-upon facts.

**Preserve:** Stable field/row identities, provenance and action-specific prerequisites.
**Adaptation/conflict:** Do not prefill professional decisions or silently overwrite current-period answers.

| Future development | Compatibility requirement |
|---|---|
| E2E | Drafting can continue where actual prerequisites permit. |
| Features | All source form and reuse obligations remain. |
| Data | Source versions and entity/period stay visible. |
| Automation | Changed linked parameters mark dependent runs stale. |

**Research references:** REF07; see Research_References.md.

## UX-11 — Design evidence library, preview and anchors

**Stage:** Working screens and specialised journeys. **Priority/effort:** P0 / L. **Proposed owner:** Designer + evidence/frontend leads.
**Packages:** R04, R05, R14. **Depends on:** UX-02, UX-05, UX-07. **Users:** Preparers, reviewers, custodians.

Evidence must be usable in context while retaining its exact original and permitted uses.

**Concrete work**

- [ ] Specify metadata-rich library, contextual selection and full-size preview.
- [ ] Define PDF/photo, Word/Excel/data preview capabilities and readable-download fallbacks.
- [ ] Design page/cell/row anchors, exact versions, intended uses and changed/rejected evidence states.

**Done when**

- A reviewer can follow a paper reference to the exact source/version and return.
- One original supports multiple explicit uses without requiring duplicate uploads.

**Preserve:** Original bytes/hash, source, intended-use assessment, access and history.
**Adaptation/conflict:** Office preview is bounded; do not imply native Office editing or lossless preview where unavailable.

| Future development | Compatibility requirement |
|---|---|
| E2E | Missing and contradictory evidence paths remain supported. |
| Features | Evidence library and contextual links share records. |
| Data | Download, export and archived access remain scoped. |
| Automation | Results can drill back to source evidence. |

**Research references:** REF05, AUD07; see Research_References.md.

## UX-12 — Design request and confirmation case workspaces

**Stage:** Working screens and specialised journeys. **Priority/effort:** P0 / M. **Proposed owner:** Designer + audit/evidence leads.
**Packages:** R05, R14. **Depends on:** UX-03, UX-04, UX-11. **Users:** Audit team and bounded external participants.

Receipt, acceptance, authorisation and dispatch are different events currently spread through detail sections.

**Concrete work**

- [ ] Specify request register and inspector with outstanding items, owners, due dates and history.
- [ ] Cover partial fulfilment, rejection, replacement, cancellation, reminders and alternative evidence.
- [ ] Specify confirmation authorisation, recipient, dispatch/reply provenance, nonresponse and differences.

**Done when**

- Partial receipt cannot close the outstanding intended-use requirements.
- Local recorded events and actual provider delivery have honest labels.

**Preserve:** Request/part/use IDs, actual external outcomes and separate audit assessment.
**Adaptation/conflict:** Do not adopt vendor deletion, portal or notification behaviour as an approved integration.

| Future development | Compatibility requirement |
|---|---|
| E2E | A14/A18 alternatives remain reachable. |
| Features | Requests stay accessible from their owning procedure. |
| Data | Accepted originals retain provenance after replacement. |
| Automation | Evidence coverage reflects assessed uses, not upload count. |

**Research references:** AUD06, AUD09, AUD10; see Research_References.md.

## UX-13 — Design the data-preparation workspace

**Stage:** Working screens and specialised journeys. **Priority/effort:** P0 / L. **Proposed owner:** Data lead + designer + data reviewer.
**Packages:** R05, R13. **Depends on:** UX-04, UX-07, UX-11. **Users:** Data preparers and reviewers.

Future profiles and integrity checks need a coherent original-to-approved interaction.

**Concrete work**

- [ ] Specify import context/profile mapping, original preservation and version selection.
- [ ] Design row-level quarantine, exclusions, counts/value bridge and account-to-statement mapping.
- [ ] Cover review, replacement, partial failure, retries and downstream affected work.

**Done when**

- Users can reconstruct exactly which rows and mapping formed the approved population.
- An unsupported profile is explained without fabricating accepted totals.

**Preserve:** Entity/period/currency, raw bytes, typed values, independent controls and accepted lineage.
**Adaptation/conflict:** Do not hardcode the existing single-currency CSV fixture as the full product design.

| Future development | Compatibility requirement |
|---|---|
| E2E | Preserve A11 and additional profile branches. |
| Features | Data integrity features remain substantive R13 work. |
| Data | Unmapped/ambiguous rows and genuine zero stay distinct. |
| Automation | Only approved supported input versions become runnable. |

**Research references:** AUD05, AUD08; see Research_References.md.

## UX-14 — Design versioned automation and exception investigation

**Stage:** Working screens and specialised journeys. **Priority/effort:** P0 / L. **Proposed owner:** Automation/domain leads + designer.
**Packages:** R05, R13, R15, R16, R17, R18, R19, R20, R21. **Depends on:** UX-02, UX-04, UX-07, UX-13. **Users:** Preparers and actual result reviewers.

A universal Run button or green result would hide method limits and outstanding human decisions.

**Concrete work**

- [ ] Specify a reusable run contract/view: accepted inputs, method edition, parameters, results and source links.
- [ ] Design exceptions, unsupported/missing input, human dispositions and downstream conclusion links.
- [ ] Cover pending/failed/partial runs, safe retry, rerun and stale results with history.

**Done when**

- Each minimum automation maps to an owning process and meaningful result/decision view.
- Input revision cannot silently replace the previously reviewed run.

**Preserve:** All 58 minimum IDs, exact editions/inputs, independent expectations and human judgment.
**Adaptation/conflict:** Specialized area methods need extensions; 58 future rows remain scope-pending.

| Future development | Compatibility requirement |
|---|---|
| E2E | Run outcomes feed their actual procedure and completion handoff. |
| Features | Analysis index is another entry to the same run, not a separate feature copy. |
| Data | Original and accepted input versions remain inspectable. |
| Automation | No OCR, AI, statistical or external execution is claimed without implementation. |

**Research references:** AUD07, AUD08; see Research_References.md.

## UX-15 — Design risk, programme, sampling and technical work

**Stage:** Working screens and specialised journeys. **Priority/effort:** P0 / L. **Proposed owner:** Audit domain lead + designer.
**Packages:** R09, R12, R15, R16, R17. **Depends on:** UX-02, UX-07, UX-10, UX-13, UX-14. **Users:** Preparers, seniors, specialists and partners.

A rigid linear form sequence will not accommodate multi-risk tailoring and revised responses.

**Concrete work**

- [ ] Specify risk/assertion/control/procedure relationships and applicability with rationale.
- [ ] Design population/sample design, approval, selection, tested units, deviations and expansion.
- [ ] Provide restricted technical matters, specialist contributions and all 22 area-variant extension points.

**Done when**

- Multiple risks/procedures can be represented without a structural redesign.
- Changed reliance/thresholds identify targeted affected work and keep earlier decisions.

**Preserve:** Actual applicability, selection basis, source rows, contributions and professional decisions.
**Adaptation/conflict:** Do not infer statistical assurance from current deterministic selection or make all source procedures universally mandatory.

| Future development | Compatibility requirement |
|---|---|
| E2E | A04–A18 variants have planned routes and return cases. |
| Features | Source programmes and technical matters remain distinct. |
| Data | Sample and procedure detail pins accepted population. |
| Automation | Method-specific calculations remain with R12–R17. |

**Research references:** AUD02, REF11; see Research_References.md.

## UX-16 — Design review, response and targeted change impact

**Stage:** Working screens and specialised journeys. **Priority/effort:** P0 / L. **Proposed owner:** Review lead + designer/frontend lead.
**Packages:** R04, R09, R17, R19. **Depends on:** UX-04, UX-09, UX-10, UX-11. **Users:** Preparer, assigned reviewer, significant-judgment reviewer.

Users must understand which content was reviewed and what requires fresh attention.

**Concrete work**

- [ ] Specify queue to exact submitted revision with field/row/source anchors.
- [ ] Design return, response, separate clearance, reassignment and renewed review.
- [ ] Show why a source change affects specific work, its prior decisions and next responsible person.

**Done when**

- A response cannot clear its own note.
- Changed relied-upon content preserves earlier review and identifies required renewed work.

**Preserve:** Exact snapshots, actor/capacity, response versions and targeted impact.
**Adaptation/conflict:** Do not impose independent approval for every field or silently clear old notes on resubmission.

| Future development | Compatibility requirement |
|---|---|
| E2E | Retain A25 regression and broader required review branches. |
| Features | Notes link across forms, data and technical cases. |
| Data | Source changes explain downstream effects. |
| Automation | Reviewed result versions remain pinned. |

**Research references:** AUD03, REF11; see Research_References.md.

## UX-17 — Design personal work and decision queues

**Stage:** Working screens and specialised journeys. **Priority/effort:** P0 / M. **Proposed owner:** Designer + role representatives.
**Packages:** R06. **Depends on:** UX-03, UX-04, UX-05. **Users:** Preparer, senior, partner, quality and custody.

People need a reliable answer to what requires their attention now.

**Concrete work**

- [ ] Specify assigned, returned, review, decision, waiting and blocked queue views.
- [ ] Show owning engagement/work, due date, reason, next action and responsible person.
- [ ] Define filters, saved preferences and honest progress dimensions/denominators.

**Done when**

- A return or new stale dependency appears for the actual next owner.
- Queue actions open the owning record and cannot invent completion.

**Preserve:** Assignments, deadlines, access and actual business-state-derived metrics.
**Adaptation/conflict:** Role-specific defaults cannot strand legitimately assigned work outside the menu.

| Future development | Compatibility requirement |
|---|---|
| E2E | Every handoff has a discoverable recipient action. |
| Features | Tasks and work records remain related rather than duplicated. |
| Data | Waiting-for-data work exposes the responsible source/request. |
| Automation | Failed or exception runs have owned follow-up. |

**Research references:** AUD04; see Research_References.md.

## UX-18 — Design calendar, Gantt, workload and effort views

**Stage:** Working screens and specialised journeys. **Priority/effort:** P0 / L. **Proposed owner:** Senior auditor + designer/frontend lead.
**Packages:** R06, R10. **Depends on:** UX-02, UX-05, UX-07, UX-17. **Users:** All calendars; senior scheduling and capacity.

Scheduling should illuminate delivery without masquerading as substantive progress.

**Concrete work**

- [ ] Specify calendar and Gantt from the same owned tasks, including unscheduled work and dependencies.
- [ ] Show baseline/current dates, preparation/review effort, workload and reassignment.
- [ ] Plan actual-hours entry and planned/actual comparison against the unfinished R10 contract.

**Done when**

- Changing a date/assignee updates the same item across paper, queue, calendar and Gantt.
- Date movement does not change audit sign-offs or historical event dates.

**Preserve:** One task identity, attribution, baseline schedule and explicit effort records.
**Adaptation/conflict:** Do not invent capacity from absent available-hours data or require drag-only scheduling.

| Future development | Compatibility requirement |
|---|---|
| E2E | Mobilisation and delivery handoffs remain connected. |
| Features | Calendar, tasks and senior Gantt remain in scope. |
| Data | Views share accepted work data. |
| Automation | Scheduling a run does not prove it executed or was reviewed. |

**Research references:** AUD02; see Research_References.md.

## UX-19 — Design clients, enquiries, acceptance and period setup

**Stage:** Working screens and specialised journeys. **Priority/effort:** P1 / L. **Proposed owner:** Acceptance lead + designer.
**Packages:** R09, R10, R11. **Depends on:** UX-02, UX-03, UX-04, UX-10. **Users:** Relationship owner, preparer and acceptance decision-maker.

Unknown enquiry facts and pending decisions must not be forced into an invented active engagement.

**Concrete work**

- [ ] Specify client relationship view, incomplete enquiry, origin and next owner.
- [ ] Design independence concerns, acceptance outcomes, exact signed terms and amendments.
- [ ] Design subsequent-period confirmation and mobilisation without carrying old judgments as current approvals.

**Done when**

- Unknown dates/framework can remain unresolved at enquiry save.
- Activation and terms changes retain current professional prerequisites.

**Preserve:** Client/engagement separation, acceptance authority and exact-file terms approval.
**Adaptation/conflict:** Client consolidation exclusion remains; no CRM write integration is assumed.

| Future development | Compatibility requirement |
|---|---|
| E2E | A01–A03 and roll-forward alternatives remain explicit. |
| Features | Client maintenance and acceptance requirements retained. |
| Data | Known source facts carry with provenance. |
| Automation | Automated readiness aids do not make the acceptance decision. |

**Research references:** AUD04, REF06; see Research_References.md.

## UX-20 — Design findings, completion and report decisions

**Stage:** Working screens and specialised journeys. **Priority/effort:** P1 / L. **Proposed owner:** Reporting partner + completion lead + designer.
**Packages:** R06, R17, R18, R20. **Depends on:** UX-02, UX-04, UX-05, UX-14, UX-16, UX-17. **Users:** Preparers, seniors and partner.

Findings, management responses, postings and report release require different evidence and decisions.

**Concrete work**

- [ ] Specify finding/correction register with accepted versus posted/verified amounts and source drill-through.
- [ ] Design final evaluation, statements/disclosures, representations, communications and other information.
- [ ] Design exact-package preview, opinion/basis, authorization, signing and recipient-level delivery outcomes.

**Done when**

- An agreed correction does not appear as a verified posting.
- Changing statements/report inputs explains stale authorizations; partial distribution stays outstanding.

**Preserve:** Finding classifications, ledger verification, exact approved artifact and actual delivery.
**Adaptation/conflict:** Do not collapse report authorization, signature, issue and receipt into Finish.

| Future development | Compatibility requirement |
|---|---|
| E2E | A19–A26/A30 remain mapped; A26 still needs connected acceptance. |
| Features | Completion and opinion variants remain functional obligations. |
| Data | Exact statement/ledger versions support decisions. |
| Automation | AUTO-048/052/053/056/057 remain independently verified methods. |

**Research references:** REF11, AUD03; see Research_References.md.

## UX-21 — Design independent quality, custody and later facts

**Stage:** Working screens and specialised journeys. **Priority/effort:** P1 / L. **Proposed owner:** Quality/custody owners + designer.
**Packages:** R06, R10, R19, R21. **Depends on:** UX-02, UX-04, UX-05, UX-16, UX-17. **Users:** Assigned quality/EQR reviewer, custodian, partner.

Independent responsibilities need focused workspaces without inheriting broad administration or partner authority.

**Concrete work**

- [ ] Specify ordinary quality versus formal EQR assignment, package review and concern treatment.
- [ ] Design manifest checks, offered/accepted custody, retrieval, holds and disposition actions.
- [ ] Design original/successor package lineage and later-fact timing variants with explicit unresolved policy.

**Done when**

- Custody receipt and quality completion remain distinct attributable decisions.
- A hold or revoked grant has the same effect in direct links, files and queues.

**Preserve:** Eligibility, scoped grants, original archive bytes, retention anchors and amendment lineage.
**Adaptation/conflict:** No universal fourth sign-off; no deletion authority inferred from elapsed time or a quality label.

| Future development | Compatibility requirement |
|---|---|
| E2E | A25/A27/A28 variants retain owning actions and regression. |
| Features | Independent roles and restricted records remain in scope. |
| Data | Packages remain readable and inspectable under grants. |
| Automation | AUTO-054/055/058 output does not substitute for the assigned human decision. |

**Research references:** REF11; see Research_References.md.

## UX-22 — Design controlled form authoring, import and adoption

**Stage:** Working screens and specialised journeys. **Priority/effort:** P1 / L. **Proposed owner:** Methodology owner + form/frontend lead.
**Packages:** R08, R10, R24. **Depends on:** UX-02, UX-04, UX-07, UX-08, UX-10. **Users:** Template-specific author, publisher and engagement adopter.

The user explicitly needs controlled configuration rather than developer edits for every form change.

**Concrete work**

- [ ] Specify field/table/section editing, conditions and per-template authoring grants.
- [ ] Design structured Excel import mapping, inferred-type preview, duplicate IDs and unsupported-rule treatment.
- [ ] Design release comparison, review/publication, retirement and adoption with compatible-answer preview.

**Done when**

- An author permitted one template cannot edit another or shared professional gates.
- Adoption retains earlier signed versions and explains changed/incompatible answers.

**Preserve:** Template/field IDs, scoped grants, separate publication/adoption and historical answers.
**Adaptation/conflict:** A one-time static screen redesign must not hardcode away configuration; arbitrary Excel formula inference is not promised.

| Future development | Compatibility requirement |
|---|---|
| E2E | Configuration journeys test effects on active engagements. |
| Features | M02 functionality remains a first-class product area. |
| Data | Import provenance and row identity remain visible. |
| Automation | Changing form content cannot silently change validated automation methods. |

**Research references:** AUD02, AUD05; see Research_References.md.

## UX-23 — Specify accessibility and complete interaction states

**Stage:** Shared interaction and visual rules. **Priority/effort:** P0 / L. **Proposed owner:** Frontend lead + designer + QA.
**Packages:** R03, R10, R22. **Depends on:** UX-04, UX-05, UX-06, UX-07. **Users:** All responsibilities.

Happy-path layouts do not cover loading, errors, conflicts or accessible operation.

**Concrete work**

- [ ] Specify loading, empty, denied, expired, offline/server failure and partial-success states.
- [ ] Define keyboard/focus/error-summary behaviour, labelled controls and non-drag alternatives.
- [ ] Define conflict resolution, safe retry and pending-command feedback without losing user input.

**Done when**

- Proposed WCAG 2.2 AA checks cover representative controls and complete journeys.
- Safe retry retains operation identity and shows actual outcome.

**Preserve:** Server enforcement, revision guards and idempotency remain authoritative.
**Adaptation/conflict:** No blind retry for rejected/stale professional decisions; a full conformance claim requires testing.

| Future development | Compatibility requirement |
|---|---|
| E2E | Failure/return cases are part of acceptance. |
| Features | Same states work across ordinary/admin/independent screens. |
| Data | Validation identifies specific fields/rows without converting missing values to zero. |
| Automation | Failed/partial runs retain diagnosable state. |

**Research references:** REF12; see Research_References.md.

## UX-24 — Specify adapters, migration and incremental cutover

**Stage:** Foundation and agreement. **Priority/effort:** P0 / L. **Proposed owner:** Tech lead + data/backend/frontend leads.
**Packages:** R00, R06, R22, R23. **Depends on:** UX-00, UX-02, UX-04. **Users:** All responsibilities.

Combining local mock UI with shared services is the largest compatibility risk.

**Concrete work**

- [ ] Define a UI/service boundary and explicit missing operations; retain existing domain engines.
- [ ] Plan browser-local record mapping on a copy, with ambiguity treatment and ID/version/grant/hash reconciliation.
- [ ] Define additive rollout, replacement-route parity, rollback and retirement gates.

**Done when**

- No display-name-only merge or silent last-write-wins migration.
- An old route is retired only after its replacement supports required behaviours and recoverable old data.

**Preserve:** IDs, source bytes, signatures, history, permissions and retry semantics.
**Adaptation/conflict:** No framework/database rewrite is justified solely by appearance; service changes need a specific contract.

| Future development | Compatibility requirement |
|---|---|
| E2E | Existing connected scenarios remain regression gates. |
| Features | All current capabilities have replacement or explicit retained route. |
| Data | Migration preserves accepted source and package lineage. |
| Automation | Old and new UI share one run/result contract. |

**Research references:** REF02; see Research_References.md.

## UX-25 — Approve the first-prototype brief and test protocol

**Stage:** Foundation and agreement. **Priority/effort:** P0 / M. **Proposed owner:** Product owner + designer + audit representatives.
**Packages:** R01, R04, R05, R06. **Depends on:** UX-01, UX-02, UX-03, UX-04. **Users:** Preparer, senior, partner, quality and custodian.

A broad redesign needs a bounded proof of the proposed working model.

**Concrete work**

- [ ] Specify two synthetic engagements and representative forms 1.1.1/1.3/3.1.2/3.3.1 plus completion and long schedules.
- [ ] Specify return/resubmit, changed-source, data/run and independent-role handoffs.
- [ ] Define task-success observations, comparison baseline and no-loss/no-unintended-approval criteria.

**Done when**

- The brief distinguishes design acceptance from functional/source acceptance.
- All test assumptions and unresolved domain choices are visible before implementation.

**Preserve:** Actual source journeys and scope; prototype data remains synthetic.
**Adaptation/conflict:** This research supplies the brief only; building a prototype needs the next authorised design task.

| Future development | Compatibility requirement |
|---|---|
| E2E | Include meaningful failed/returned cases, not just a happy path. |
| Features | Builder and other future needs are represented without requiring all features built first. |
| Data | Use a realistic approved population and source replacement. |
| Automation | Include one explainable run plus unsupported/stale cases. |

**Research references:** REF02; see Research_References.md.

## UX-26 — Implement and validate the approved connected prototype

**Stage:** Approved prototype and parallel functional work. **Priority/effort:** P0 / L. **Proposed owner:** Frontend/backend leads + QA + auditors.
**Packages:** R04, R05, R06. **Depends on:** UX-05, UX-06, UX-07, UX-08, UX-09, UX-11, UX-12, UX-13, UX-14, UX-16, UX-17, UX-18, UX-20, UX-21, UX-23, UX-24, UX-25. **Users:** Representative users across responsibilities.

The interaction hypothesis must survive real role handoffs before expansion.

**Concrete work**

For UX-26, upstream dependencies mean agreed contracts and the representative prototype slice. They do not require complete implementation or full fidelity acceptance of all 70 forms, profiles, variants or automations; broader closure remains UX-27/28/29 and the original R owners.

- [ ] After design approval, implement the bounded shell/paper/evidence/review slice on shared services.
- [ ] Execute the protocol with users and record actual failures, recoveries and observations.
- [ ] Revise only affected patterns and record the chosen design decisions.

**Done when**

- Complete prepare → submit → return → revise → clear on persisted records.
- Changed sources and a second engagement demonstrate targeted impact and isolation without lost input.

**Preserve:** All regression contracts named in UX-00 and UX-24.
**Adaptation/conflict:** Do not call the whole application redesigned or source-accepted after one prototype.

| Future development | Compatibility requirement |
|---|---|
| E2E | Run selected reference paths through the actual browser. |
| Features | Prototype success is not completion of all feature contracts. |
| Data | Verify original/accepted lineage during use. |
| Automation | Check input/result versions and independent disposition. |

**Research references:** REF02; see Research_References.md.

## UX-27 — Expand by screen and form families with source reconciliation

**Stage:** Family expansion. **Priority/effort:** P1 / XL. **Proposed owner:** Frontend/form/domain leads + QA.
**Packages:** R02, R03, R07, R08, R09, R16, R24. **Depends on:** UX-19, UX-22, UX-26. **Users:** All authorised users.

A successful representative slice still leaves many forms and specialist screens.

**Concrete work**

- [ ] Extend agreed patterns across all 25 screen groups and applicable 70 forms.
- [ ] Complete per-form and per-variant exceptions without forking the shared object/action model.
- [ ] Maintain local/partial/shared status, original scope and independent source acceptance separately.

**Done when**

- No core requirement disappears during family reuse.
- Each applicable form/variant retains its own source-linked acceptance evidence.

**Preserve:** Original source IDs, configuration and individual fidelity obligations.
**Adaptation/conflict:** Optional follow-up/services require their existing mandate decisions; family reuse is not blanket acceptance.

| Future development | Compatibility requirement |
|---|---|
| E2E | Expand coverage across applicable cycles and branches. |
| Features | All 127 core features retain owning screens/actions. |
| Data | Profile and evidence variants remain extensible. |
| Automation | Keep required methods and future scope rows visible. |

**Research references:** REF07, REF08; see Research_References.md.

## UX-28 — Continue functional batches alongside the agreed UI contracts

**Stage:** Approved prototype and parallel functional work. **Priority/effort:** P1 / XL. **Proposed owner:** Domain/data/backend leads + QA.
**Packages:** R07, R09, R11, R12, R13, R14, R15, R16, R17, R18, R19, R20, R21, R22. **Depends on:** UX-00, UX-02, UX-04, UX-24. **Users:** Functional owners and actual reviewers.

Waiting for every cosmetic screen would unnecessarily block unfinished engineering.

**Concrete work**

- [ ] Continue calculations, parsers, data integrity, service rules and source reconciliation behind agreed interfaces.
- [ ] Preserve R20/R21 issue-to-custody as the prior proposed next connected batch, subject to real dependencies.
- [ ] Coordinate response/schema changes and connect normal UI acceptance as screens become available.

**Done when**

- Functional work can progress without waiting for UX-27 visual expansion.
- No package is marked complete from an API-only demonstration where normal UI is required.

**Preserve:** All existing functional/source obligations and authoritative records.
**Adaptation/conflict:** A structural contract change needs impact review; layout decisions alone cannot defer functionality.

| Future development | Compatibility requirement |
|---|---|
| E2E | Build in batches and verify each applicable source obligation. |
| Features | Unfinished features stay in their existing R owners. |
| Data | Broader import profiles and lineage remain functional delivery. |
| Automation | All 58 minimum methods require independent results and failed cases. |

**Research references:** REF02; see Research_References.md.

## UX-29 — Complete regression, independent acceptance and retirement

**Stage:** Release and retirement. **Priority/effort:** P1 / XL. **Proposed owner:** QA lead + methodology/product/operations owners.
**Packages:** R22, R23. **Depends on:** UX-27, UX-28. **Users:** Independent acceptors and release owners.

Visual acceptance alone cannot establish release readiness or safe replacement.

**Concrete work**

- [ ] Run domain, service and normal-browser journeys against the intended release build.
- [ ] Reconcile every applicable source obligation and obtain actual independent decisions.
- [ ] Rehearse migration/rollback and retire only proven superseded routes; publish remaining limitations.

**Done when**

- Applicable source gates and operational gates pass with attributable evidence.
- Design acceptance, functional implementation, technical evidence and independent acceptance remain separately reportable.

**Preserve:** Scope, source hashes, package integrity, access and historical acceptance provenance.
**Adaptation/conflict:** Do not relabel a fresh design review as independent audit acceptance.

| Future development | Compatibility requirement |
|---|---|
| E2E | Retain all 51 cycle IDs and approved scope dispositions. |
| Features | No requirement silently narrowed to meet a visual deadline. |
| Data | Verify current and historical data recovery. |
| Automation | Minimum automation acceptance and optional decisions remain distinct. |

**Research references:** REF12; see Research_References.md.
