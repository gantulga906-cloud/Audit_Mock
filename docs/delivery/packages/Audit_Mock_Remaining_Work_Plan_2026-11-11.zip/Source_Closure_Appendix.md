# Audit_Mock source closure appendix

Prepared 11 November 2026 against commit `25486b7448e6e5fc4d830868de943962209db3f3`. Read with [the remaining-work plan](Audit_Mock_Remaining_Work_Plan_2026-11-11.md).

The statuses below are copied from the saved verifier. They describe evidence, and require inspection of existing implementation before assigning a code gap. Proposed R-package ownership is planning metadata to confirm with the team. It preserves the original source definitions and scope rather than creating a new professional rule.

## Lifecycle closure matrix

The original plan scope below remains visible. The current verifier still has every cycle applicable until actual scope decisions are recorded. Four connected fixture passes cover their recorded scenarios. Independent source acceptance remains open for every cycle.

| Cycle | Source title | Steps / directly observed | Connected fixture | Original plan scope | Package | Remaining closure work |
| --- | --- | --- | --- | --- | --- | --- |
| A01 | Client acceptance or continuance | 11 / 0 | Open | Core audit | R11 | Join enquiry, acceptability, clearance, approval and activation for new and continuing clients, including return/decline outcomes. |
| A02 | Ethics and independence clearance | 9 / 0 | Open | Core audit | R11 | Complete team/expert declarations, threats, safeguards, independent clearance and continuing reassessment after relevant changes. |
| A03 | Audit prerequisites and engagement terms | 9 / 1 | Open | Core audit | R11 | Complete prerequisites and exact agreed terms through activation and amendment. The existing active-amendment evidence covers one source step. |
| A04 | Engagement mobilization | 9 / 0 | Open | Core audit | R10 | Join eligible staffing, resources, mobilisation and shared scheduling with refused/ineligible/reassignment cases. |
| A05 | Initial scope and kickoff | 9 / 0 | Open | Core audit | R12 | Connect approved scope, kickoff discussion, timetable and initial planning decisions with owned actions. |
| A06 | Understand the entity, reporting, IT, and controls | 9 / 0 | Open | Core audit | R12 | Complete structured entity/reporting/IT/control understanding and evidence-supported updates to the plan. |
| A07 | Identify and assess audit risks | 9 / 0 | Open | Core audit | R12 | Link identified and assessed risks to assertions, significance, multiple responses and targeted changes. |
| A08 | Set and revise materiality | 9 / 9 | Passed for recorded scenario | Core audit | R12 | Preserve the passing materiality journey and extend applicable form, benchmark, threshold, review and changed-source contexts. |
| A09 | Evaluate opening balances | 9 / 0 | Open | Audit when applicable | R13 | Connect prior-period/opening evidence, reconciliations, audit procedures, unsupported balances and their reporting consequences. |
| A10 | Develop and approve the audit strategy and risk responses | 9 / 3 | Open | Core audit | R12 | Complete multi-risk/multi-procedure strategy tailoring, approval, work adoption and revision consequences. |
| A11 | Prepare audit-ready data and populations | 9 / 9 | Passed for recorded scenario | Core audit | R13 | Preserve the passing accepted-extract journey and extend supported profiles, accounting contexts and partial-failure/revision cases. |
| A12 | Evaluate and test controls | 12 / 0 | Open | Core audit | R12 | Connect walkthrough/design/implementation, test design, deviations, reliance decision and revised substantive work. |
| A13 | Perform substantive audit work by cycle and assertion | 13 / 2 | Open | Core audit | R15 | Follow programme/population/sample through actual tested units, each applicable variant, exceptions, review and findings. |
| A14 | Manage external confirmations | 10 / 0 | Open | Audit when applicable | R14 | Complete confirmation dispatch/reply provenance, nonresponse, differences, alternatives and revised conclusions. |
| A15 | Resolve specialized accounting and disclosure matters | 9 / 0 | Open | Core audit | R17 | Complete significant accounting/disclosure matters from discovery through consultation/work and reviewed resolution. |
| A16 | Coordinate group, component, specialist, or internal-auditor contributions | 9 / 0 | Open | Audit when applicable | R17 | Complete scoped specialist/component contributions, suitability, instructions, involvement and unresolved limitations. |
| A17 | Investigate suspected fraud or non-compliance | 9 / 0 | Open | Audit when applicable | R17 | Complete suspected fraud/non-compliance concern, controlled evidence, escalation, extra work and authorised response. |
| A18 | Resolve missing or contradictory evidence | 9 / 0 | Open | Core audit | R14 | Connect missing/contradictory evidence to additional work, impact on conclusions, review and reporting readiness. |
| A19 | Resolve audit findings with the client | 9 / 0 | Open | Core audit | R18 | Follow a finding through discussion, management response, further work, acceptance/decline and owned disposition. |
| A20 | Evaluate misstatements and corrections | 9 / 0 | Open | Core audit | R18 | Complete misstatement classification/aggregation, proposed corrections, actual ledger verification and revised evaluation. |
| A21 | Complete period-end and reporting-date matters | 9 / 0 | Open | Core audit | R18 | Complete period-end, going-concern and subsequent-event work through the actual target report date and renewed coverage. |
| A22 | Evaluate final financial statements and disclosures | 9 / 0 | Open | Core audit | R18 | Complete exact final statement/note versions, applicable disclosures, final analytics, corrections and review. |
| A23 | Obtain management’s written representations | 9 / 0 | Open | Core audit | R18 | Complete representation request, authorised signature/period, suitability assessment and changed-statement/date consequences. |
| A24 | Communicate with management and those charged with governance | 9 / 0 | Open | Core audit | R18 | Complete management/governance addressees, significant matters, authorised content, outcomes, failures and follow-up. |
| A25 | Clear engagement review and quality gates | 9 / 9 | Passed for recorded scenario | Core audit | R19 | Preserve the passing review/EQR journey and extend form families, policy eligibility, consultation and stale/late approval cases. |
| A26 | Form the opinion and issue the auditor’s report | 9 / 3 | Open | Core audit | R20 | Demonstrate opinion formation through applicable report templates/sections, exact authorization, signing and recipient outcomes. |
| A27 | Finalize and hand over the audit file | 9 / 3 | Open | Core audit | R21 | Demonstrate final assembly diagnostics/deadlines, lock, independent verification and custody acceptance/return. |
| A28 | Respond to a later-discovered fact | 9 / 9 | Passed for recorded scenario | Audit when applicable | R21 | Preserve issued/sealed no-change/reissue/reliance routes and add dated-but-unsealed and approved restricted-amendment/dual-dating variants. |
| A29 | Follow up agreed recommendations or action plans | 9 / 0 | Open | Mandate D24 | R24 | Record D24 mandate. If approved, complete recommendation ownership, progress, evidence, retest, escalation and supported closure. |
| A30 | Read and respond to other information in the annual report | 12 / 0 | Open | Audit when annual report applies | R18 | Complete expected/received other information, inconsistencies, management response and action before/after report issue. |
| B01 | Opportunity to proposal | 9 / 0 | Open | Audit-facing support; broader D26 | R11 | Verify the audit enquiry/proposal handoff and explicitly disposition the wider opportunity/proposal process under D26. |
| B02 | License and regulatory standing | 9 / 0 | Open | Audit-facing support; broader D26 | R10 | Verify engagement-facing license/credential standing and explicitly disposition the wider regulatory-maintenance process. |
| B03 | Firm quality objectives and risk management | 9 / 0 | Open | Wider firm scope D26 | R24 | Decide the firm quality-objectives/risk-management mandate and deliver the approved complete process. |
| B04 | Firm-wide ethics, conflicts, and breach handling | 10 / 0 | Open | Audit-facing support; broader D26 | R11 | Verify audit-facing conflicts/declarations/breaches and disposition the broader firm-wide ethics process. |
| B05 | Standards and methodology change control | 9 / 0 | Open | Audit-facing support; broader D26 | R08 | Verify governed methodology publication, effective version adoption and change impact; disposition the wider firm process. |
| B06 | People and competence development | 9 / 0 | Open | Audit-facing support; broader D26 | R10 | Verify competence/credential suitability supplied to staffing and disposition the wider people-development process. |
| B07 | Portfolio capacity and scheduling | 9 / 0 | Open | Audit-facing support; broader D26 | R06 | Verify shared dates/capacity/work allocation across portfolio and engagement; disposition broader firm scheduling scope. |
| B08 | Technical consultation service | 9 / 0 | Open | Audit-facing support; broader D26 | R19 | Verify engagement consultation/advice/resolution handoffs and disposition any broader firm consultation-service process. |
| B09 | EQR policy and reviewer assignment | 9 / 0 | Open | Audit-facing support; broader D26 | R19 | Verify EQR policy applicability, eligibility and assignment inputs to the engagement and disposition wider administration. |
| B10 | Quality monitoring and remediation | 9 / 0 | Open | Wider firm scope D26 | R24 | Decide firm quality monitoring/remediation scope and implement the approved trigger-to-remediation process. |
| B11 | Complaint or allegation handling | 9 / 0 | Open | Wider firm scope D26 | R24 | Decide complaint/allegation process scope, authority, restrictions and required audit-facing handoffs. |
| B12 | External inspection response | 9 / 0 | Open | Audit-facing support; broader D26 | R21 | Verify the controlled inspection-package handoff and explicitly disposition broader inspection response/remediation. |
| B13 | Audit technology and provider governance | 9 / 0 | Open | Wider firm scope D26 | R24 | Decide technology/provider-governance scope and its supported approvals, monitoring and failure routes. |
| B14 | Information access and security response | 9 / 0 | Open | Audit-facing support; broader D26 | R10 | Verify scoped access/revocation and audit-facing incident effects; disposition broader firm security-response scope. |
| B15 | Engagement economics and collection | 9 / 0 | Open | Audit-facing support; broader D26 | R10 | Verify core planned/actual effort and budget views and disposition billing, collections and broader firm economics. |
| B16 | Archive custody and disposition | 9 / 0 | Open | Audit-facing support; broader D26 | R21 | Verify engagement-facing custody/retrieval/holds/disposition and explicitly define broader archival administration scope. |
| C01 | Financial-statement review | 10 / 0 | Open | Separate service D26 | R24 | Decide financial-statement review service mandate and define its separate procedures, conclusion and issue journey. |
| C02 | Other assurance engagement | 9 / 0 | Open | Separate service D26 | R24 | Decide other-assurance scope, agreed subject/criteria, evidence, conclusion and separate complete journey. |
| C03 | Agreed-upon procedures | 9 / 0 | Open | Separate service D26 | R24 | Decide agreed-upon-procedures service scope and complete agreed work, factual findings and issuance. |
| C04 | Outsourced or co-sourced internal audit | 10 / 0 | Open | Separate service D26 | R24 | Decide outsourced/co-sourced internal-audit mandate and complete planning, execution, reporting and agreed follow-up. |
| C05 | Permitted advisory or financial-related service | 10 / 0 | Open | Separate service D26 | R24 | Decide permitted advisory/service scope, conflicts, agreed deliverable and cross-role completion. |

## All feature rows

The 136 rows preserve 127 core requirements, eight conditional follow-up rows and the source exclusion M03-F07. For each applicable row, compare the exact requirement with code and normal UI, finish its missing behavior/branches, connect the next consumer and obtain source acceptance.

| Feature | Title | Exact requirement | Current scope | Current evidence | Package | Related cases |
| --- | --- | --- | --- | --- | --- | --- |
| M01-F01 | Maintain the firm profile | Authorized administrators maintain legal name, license/reference details, reporting identity and operational contacts. | core | unverified | R10 | P14-UC01 |
| M01-F02 | Maintain organizational units | Create and update offices, teams and practice groups used for business assignment and reporting. | core | unverified | R10 | P14-UC01 |
| M01-F03 | Maintain the practitioner roster | Record active, inactive and external practitioners while preserving historical attribution on completed work. | core | partial-evidence | R10 | P14-UC01 |
| M01-F04 | Record competence and credentials | Capture professional level, qualifications, sector knowledge, specialist skills and validity dates needed for staffing judgments. | core | partial-evidence | R10 | P14-UC02 |
| M01-F05 | Record capacity and availability | Show planned availability and workload at a level sufficient to support human staffing decisions. | core | unverified | R10 | P14-UC03 |
| M01-F06 | Assign business roles and status | Designate firm-level business roles and employment/contract status without prescribing the future technical access model. | core | partial-evidence | R10 | P14-UC01 |
| M01-F07 | View portfolio capacity | View active engagements, responsible leaders, staffing gaps and aggregate workload for management action. | core | unverified | R10 | P14-UC03 |
| M02-F01 | Maintain a methodology catalog | Organize approved and draft content by stage, engagement type, sector and reporting framework. | core | unverified | R08 | P04-UC01 |
| M02-F02 | Support reusable content types | Maintain questionnaires, checklists, work programs, letters, report templates, guidance and standard conclusions. | core | partial-evidence | R08 | P04-UC01 |
| M02-F03 | Create and revise template content | Authorized methodology users draft, edit and structure reusable content without changing live engagement work. | core | partial-evidence | R08 | P04-UC01 |
| M02-F04 | Version and date methodology | Record version, effective date, superseded version, owner and change rationale. | core | unverified | R08 | P04-UC01 |
| M02-F05 | Set applicability rules | Define when content is mandatory, optional or not applicable by engagement profile, with override rationale where permitted. | core | partial-evidence | R08 | P04-UC01 |
| M02-F06 | Review, approve, publish and retire templates | Use a controlled business workflow so only approved methodology is available for new engagements. | core | unverified | R08 | P04-UC02 |
| M02-F07 | Compare releases and communicate changes | Show material changes, affected content and release notes so firms can plan adoption. | core | unverified | R08 | P04-UC02 |
| M02-F08 | Instantiate an approved version | Create the engagement's working copy with the source template version identifiable. | core | unverified | R08 | P04-UC03 |
| M02-F09 | Control template updates in active work | Offer selected updates for review and acceptance without overwriting completed answers, evidence or sign-offs. | core | partial-evidence | R08 | P04-UC03 |
| M03-F01 | Register a prospective or existing client | Create a searchable client profile with relationship status and responsible business contact. | core | partial-evidence | R11 | P01-UC01 |
| M03-F02 | Maintain legal and reporting identity | Record legal name, registration identifiers, entity type, financial year, reporting framework and sector. | core | partial-evidence | R11 | P01-UC01, P01-UC03 |
| M03-F03 | Maintain contacts and governance parties | Record management, finance, governance and operational contacts relevant to the audit relationship. | core | unverified | R11 | P01-UC02 |
| M03-F04 | Record ownership and group context | Capture owners, controlling parties, related entities and group relationships needed for planning and conflict checks. | core | partial-evidence | R11 | P01-UC02 |
| M03-F05 | Maintain relationship status | Distinguish prospect, pending acceptance, active, suspended, former and rejected relationships with dates and reason. | core | partial-evidence | R11 | P01-UC01, P01-UC02 |
| M03-F06 | View client engagement history | View prior periods, engagement types, responsible partners, outcomes and unresolved continuity matters. | core | unverified | R11 | P01-UC02, P01-UC03 |
| M03-F07 | Detect and resolve likely duplicates | Warn on likely duplicate profiles and allow controlled confirmation or consolidation without losing history. | excluded | excluded | R11 |  |
| M03-F08 | Reuse client context with confirmation | Prepopulate stable client information into a new engagement and require the team to confirm or update it for the period. | core | partial-evidence | R11 | P01-UC03, P03-UC04 |
| M04-F01 | Initiate new or continuing acceptance | Open the appropriate assessment, identify the proposed engagement and distinguish a new relationship from continuance. | core | unverified | R11 | P02-UC01 |
| M04-F02 | Assess client integrity and engagement risk | Document relevant background, management integrity, reasons for auditor change, disputes and other acceptance concerns. | core | unverified | R11 | P02-UC01 |
| M04-F03 | Obtain independence and conflict assessments | Capture firm and engagement-level relationships, financial interests, services and circumstances relevant to independence. | core | unverified | R11 | P02-UC02, P02-UC03 |
| M04-F04 | Collect declarations from the team and experts | Issue, complete and track dated declarations for assigned team members, experts and other relevant persons. | core | unverified | R11 | P02-UC02 |
| M04-F05 | Record threats and safeguards | Document identified threats, significance, planned safeguards, responsible person and outcome. | core | unverified | R11 | P02-UC03 |
| M04-F06 | Evaluate competence, time and resources | Document whether sufficient competent people, specialists and time are available to perform the proposed work. | core | partial-evidence | R11 | P02-UC01 |
| M04-F07 | Resolve or escalate acceptance matters | Assign action, evidence and approval for unresolved integrity, independence or resource matters before a decision. | core | unverified | R11 | P02-UC01, P02-UC03 |
| M04-F08 | Record the acceptance decision | Record accept, continue, conditional acceptance, pending or reject, with rationale, approver, date and conditions. | core | unverified | R11 | P02-UC04, P02-UC05 |
| M04-F09 | Prevent unauthorized progression | Do not release engagement setup when the decision is rejected, expired, prohibited or materially incomplete. | core | unverified | R11 | P02-UC04 |
| M04-F10 | Refresh acceptance and independence | Reassess at required points and when new services, relationships, team changes or other circumstances arise, preserving prior conclusions. | core | unverified | R11 | P02-UC04 |
| M05-F01 | Create an authorized engagement | Create an engagement only from an accepted client/engagement decision and retain the authorization reference. | core | unverified | R11 | P03-UC01 |
| M05-F02 | Define engagement profile and scope | Record engagement type, reporting period, reporting framework, locations/components, scope and expected deliverables. | core | unverified | R11 | P03-UC01, P09-UC10 |
| M05-F03 | Prepare and control engagement terms | Draft, review, issue and retain the engagement letter or updated terms, including acceptance status and version. | core | unverified | R11 | P02-UC05 |
| M05-F04 | Plan dates and milestones | Set reporting period, fieldwork windows, review dates, reporting date and stage milestones. | core | unverified | R06 | P03-UC01, P03-UC03 |
| M05-F05 | Set and monitor the engagement budget | Record planned hours or effort by phase and role and compare actual progress at a business-control level. | core | unverified | R10 | P03-UC03 |
| M05-F06 | Appoint the engagement team and specialists | Assign partner, manager, preparers, reviewers, specialists and, where applicable, an engagement quality reviewer. | core | unverified | R10 | P03-UC02, P06-UC04 |
| M05-F07 | Assign work ownership | Assign engagement activities to named people with due dates, priority and review level. | core | unverified | R10 | P03-UC02 |
| M05-F08 | Manage lifecycle and stage hand-offs | Show current stage, readiness conditions, blocked items and authorized transition to the next stage. | core | unverified | R09 | P03-UC03 |
| M05-F09 | Control engagement changes and withdrawal | Record material scope, timing, team or terms changes and any suspension/withdrawal decision with rationale and approval. | core | unverified | R11 | P03-UC03 |
| M05-F10 | Roll forward an engagement | Create the next-period engagement from selected prior structure and context, requiring current-period confirmation rather than automatic acceptance. | core | unverified | R09 | P03-UC04 |
| M06-F01 | Initiate an iterative audit plan | Open the planning record early, show completeness and preserve approved revisions through the engagement. | core | unverified | R12 | P06-UC01, P06-UC06 |
| M06-F02 | Document entity and reporting understanding | Record business model, industry, objectives, governance, external factors and the applicable reporting framework. | core | unverified | R12 | P06-UC01 |
| M06-F03 | Document controls and information systems | Understand relevant processes, control design/implementation, IT environment and information flows. | core | unverified | R12 | P06-UC01 |
| M06-F04 | Assess fraud risk | Record inquiries, incentives/pressures, opportunities, attitudes, presumed risks and planned responses. | core | unverified | R12 | P06-UC02, P09-UC04 |
| M06-F05 | Evaluate other work and opening balances | Document whether and how internal audit, experts, specialists and opening-balance procedures affect the audit approach. | core | unverified | R12 | P05-UC03, P06-UC04, P09-UC10 |
| M06-F06 | Perform preliminary analytics and cycle scoping | Record expectations, comparisons, unusual relationships and significant cycles used to focus risk assessment. | core | partial-evidence | R12 | P06-UC03 |
| M06-F07 | Determine and revise materiality | Record overall, performance and specific materiality, clearly trivial threshold, benchmarks, rationale and revisions. | core | partial-evidence | R12 | P06-UC03, P06-UC05 |
| M06-F08 | Maintain the risk register | Create, update, combine or close identified risks with source, description, assessment and status. | core | unverified | R12 | P06-UC02 |
| M06-F09 | Link risks to financial-statement areas | Link each risk to affected accounts, disclosures, assertions, processes and relevant controls. | core | partial-evidence | R12 | P06-UC02 |
| M06-F10 | Assess risk significance and rationale | Record inherent/control-risk judgments, significant-risk conclusion and the rationale for professional review. | core | unverified | R12 | P06-UC02, P06-UC05 |
| M06-F11 | Define a planned response for every risk | Record the overall and assertion-level response, including whether controls or substantive procedures are planned. | core | unverified | R12 | P06-UC02, P06-UC06 |
| M06-F12 | Build strategy by account and cycle | Define planned nature, timing and extent of control tests, analytics and tests of details by significant area. | core | unverified | R12 | P06-UC02, P06-UC05 |
| M06-F13 | Document planning discussion and governance communication | Record team discussion, key judgments, planned scope/timing and communications with those charged with governance. | core | unverified | R12 | P06-UC01 |
| M06-F14 | Review, approve and hand off the plan | Resolve planning review points, approve the current version and confirm every assessed risk has an executable response before Stage 3. | core | unverified | R12 | P06-UC05, P06-UC06 |
| M07-F01 | Activate applicable audit programs | Create the current engagement's work programs from approved methodology and the Stage 2 strategy. | core | partial-evidence | R12 | P07-UC01 |
| M07-F02 | Tailor procedures to assessed risks | Add, remove or modify procedures with rationale and maintain links to risks, accounts and assertions. | core | unverified | R12 | P07-UC01 |
| M07-F03 | Assign and schedule fieldwork | Assign owner, due date, budget and review level for programs and procedures. | core | unverified | R06 | P07-UC01 |
| M07-F04 | Define and reconcile populations | Record the population, period, source, completeness and reconciliation before testing or sampling. | core | unverified | R13 | P05-UC01, P05-UC02, P07-UC02 |
| M07-F05 | Perform tests of controls | Document control tested, design/implementation, sample or instances, deviations, conclusion and reliance decision. | core | unverified | R12 | P09-UC01 |
| M07-F06 | Perform substantive analytical procedures | Record expectation, precision, threshold, data reliability, investigation and conclusion. | core | unverified | R15 | P09-UC03 |
| M07-F07 | Plan and perform sampling and tests of details | Document objective, assertion, population, high-risk items, selection method, sample, errors, projection and conclusion. | core | unverified | R15 | P07-UC02, P07-UC03, P09-UC02, P09-UC05 |
| M07-F08 | Control external confirmations | Maintain auditor control over requests, responses, non-responses, alternatives, reliability and exceptions. | core | partial-evidence | R14 | P08-UC03, P08-UC04 |
| M07-F09 | Test journal entries and management override | Document selection criteria, entries tested, supporting evidence, unusual items and conclusions. | core | partial-evidence | R15 | P09-UC04 |
| M07-F10 | Perform cross-cutting completion procedures | Execute subsequent-events, going-concern, contingencies, related-party, legal-letter and minutes procedures. | core | partial-evidence | R17 | P09-UC05, P09-UC06, P09-UC07, P09-UC08, P09-UC09 |
| M07-F11 | Record procedure result and conclusion | Record work performed, result, exceptions, conclusion, preparer and completion date at the appropriate level. | core | unverified | R15 | P07-UC03, P09-UC01, P09-UC02, P09-UC03, P09-UC05, P09-UC11 |
| M07-F12 | Classify and route exceptions | Distinguish evidence gaps, control deviations, misstatements, fraud indicators and new risks, then route action. | core | unverified | R15 | P09-UC01, P09-UC02, P09-UC09, P09-UC11 |
| M07-F13 | Expand, modify or reopen work | Add or change procedures when results are insufficient or contradictory and preserve the reason and prior status. | core | partial-evidence | R15 | P07-UC03, P08-UC04, P09-UC01, P09-UC11, P10-UC09, P11-UC07 |
| M07-F14 | Assess fieldwork readiness | Show incomplete procedures, unresolved exceptions, missing conclusions and review status before Stage 4 hand-off. | core | unverified | R15 | P09-UC11 |
| M08-F01 | Maintain the engagement-file index | Organize forms, workpapers and evidence by stage, account/cycle, program and status with stable references. | core | unverified | R07 | P15-UC01 |
| M08-F02 | Create, upload, import and link workpapers | Accept native platform workpapers and external files while retaining source and engagement context. | core | unverified | R14 | P05-UC01, P15-UC01 |
| M08-F03 | Record workpaper metadata | Record title, reference, period, source, preparer, reviewer, dates, status and confidentiality classification. | core | unverified | R07 | P15-UC01 |
| M08-F04 | Cross-reference work, evidence and conclusions | Create navigable links among procedures, risks, accounts, assertions, evidence, findings and report conclusions. | core | unverified | R09 | P08-UC02, P15-UC01 |
| M08-F05 | Request and track client-provided evidence | Issue requests with owner and due date, receive responses, identify superseded items and track acceptance or follow-up. | core | unverified | R14 | P08-UC01 |
| M08-F06 | Control versions and concurrent work | Preserve prior versions, identify the current version and prevent accidental loss or silent overwrite of completed work. | core | unverified | R09 | P15-UC02 |
| M08-F07 | Annotate and discuss evidence | Add tick marks, annotations and contextual comments without obscuring the underlying source. | core | unverified | R14 | P08-UC02 |
| M08-F08 | Document evidence relevance and reliability | Record source, authenticity concerns, completeness, contradictory evidence and how the matter was resolved. | core | unverified | R14 | P08-UC02, P08-UC04 |
| M08-F09 | Support linked schedules and trial-balance workpapers | Import or link account balances and schedules and show broken or stale links for auditor resolution. | core | partial-evidence | R13 | P05-UC01, P05-UC02, P05-UC03, P15-UC03 |
| M08-F10 | Search and test file completeness | Search by reference, title, account, person, date and status; identify missing files, broken links and unresolved check-outs. | core | unverified | R14 | P05-UC03, P15-UC03 |
| M08-F11 | Export a readable evidence package | Produce an indexed package that preserves identifiers, links or cross-reference listings and relevant history for authorized use. | core | unverified | R07 | P15-UC03 |
| M09-F01 | Assign preparation and review responsibility | Set the required preparer, reviewer, approver and review level for relevant work without prescribing technical permissions. | core | unverified | R19 | P11-UC01, P11-UC04 |
| M09-F02 | Maintain review queues and status | Show work awaiting review, overdue review, returned work, cleared work and items requiring higher-level attention. | core | unverified | R19 | P11-UC01, P11-UC02 |
| M09-F03 | Raise a traceable review note | Link a review note to the exact work, assign an owner and due date, and state the required response. | core | unverified | R19 | P11-UC01, P11-UC02 |
| M09-F04 | Resolve, clear and reopen review notes | Record the response, changed work, reviewer conclusion and complete note history, including reopening. | core | unverified | R19 | P11-UC01, P11-UC02 |
| M09-F05 | Record dated sign-offs | Record who prepared, reviewed or approved work and when, at the level required by methodology. | core | unverified | R19 | P11-UC01, P11-UC02, P11-UC04 |
| M09-F06 | Control changes after review | Identify material changes after sign-off, require renewed review where appropriate and preserve the prior state. | core | partial-evidence | R19 | P11-UC03, P11-UC07 |
| M09-F07 | Document engagement-partner review | Present significant risks, judgments, consultations, uncorrected misstatements, report matters and open issues for partner conclusion. | core | partial-evidence | R19 | P11-UC03 |
| M09-F08 | Determine EQR applicability and eligibility | Record whether an engagement quality review is required and confirm the reviewer's eligibility, competence, authority, time and independence. | core | partial-evidence | R19 | P11-UC05 |
| M09-F09 | Perform and conclude the EQR | Document review of selected significant judgments, financial statements, proposed report and unresolved matters before the report date. | core | unverified | R19 | P11-UC06 |
| M09-F10 | Apply completion and quality gates | Prevent stage completion or report issue when mandatory review, sign-off, consultation or EQR conditions remain unmet. | core | partial-evidence | R19 | P11-UC03, P11-UC04, P11-UC06 |
| M10-F01 | Capture and classify an audit finding | Record the condition, criterion, cause, effect, evidence and type of finding or exception. | core | unverified | R18 | P10-UC01 |
| M10-F02 | Link findings to their audit context | Link each finding to the originating risk, procedure, workpaper, account, assertion and affected report area. | core | unverified | R18 | P10-UC01 |
| M10-F03 | Assess significance and required action | Record quantitative and qualitative significance, escalation, communication and further-work decisions. | core | unverified | R18 | P10-UC01, P10-UC03 |
| M10-F04 | Aggregate misstatements | Maintain corrected and uncorrected misstatements by account, type and period against relevant materiality. | core | unverified | R18 | P10-UC02, P10-UC03 |
| M10-F05 | Propose and track adjustments | Record proposed entries or reclassifications, management response, accepted/rejected status and verified financial-statement effect. | core | unverified | R18 | P10-UC02 |
| M10-F06 | Perform and conclude final analytics | Compare final financial information with expectations and prior understanding; route unexplained results back to risk or fieldwork. | core | unverified | R18 | P10-UC03 |
| M10-F07 | Evaluate the final financial statements | Record evaluation of accounting policies, estimates, presentation, disclosures, consistency and final authorized version. | core | unverified | R18 | P05-UC03, P09-UC06, P09-UC08, P10-UC04 |
| M10-F08 | Conclude on sufficient appropriate evidence | Summarize unresolved scope limitations, contradictory evidence and material findings before selecting an opinion. | core | unverified | R18 | P10-UC06 |
| M10-F09 | Determine and document the audit opinion | Apply the material/pervasive and evidence/misstatement logic for unmodified, qualified, adverse or disclaimer outcomes, with rationale. | core | partial-evidence | R20 | P10-UC06 |
| M10-F10 | Generate the auditor's report from an approved template | Populate the selected report form, control its version and retain links to the supporting conclusions. | core | unverified | R20 | P10-UC07 |
| M10-F11 | Manage additional report sections | Add applicable key-audit-matter, emphasis-of-matter, other-matter, going-concern or other reporting sections with approval. | core | unverified | R20 | P09-UC08, P10-UC06, P10-UC07 |
| M10-F12 | Obtain and evaluate written representations | Prepare the representation request, track signature and date, assess completeness and record consequences of non-response or qualification. | core | partial-evidence | R18 | P10-UC05 |
| M10-F13 | Prepare management and governance communications | Prepare control-deficiency and other required communications, obtain management responses and retain delivery evidence. | core | partial-evidence | R18 | P10-UC07 |
| M10-F14 | Control report authorization and issue | Confirm final financial-statement authorization, subsequent-event coverage, required reviews and representations before dating, signing and delivering the report. | core | partial-evidence | R20 | P09-UC07, P10-UC08, P10-UC09 |
| M11-F01 | Create an agreed follow-up action | Convert an agreed recommendation or control-remediation commitment into a trackable action without altering the original finding. | conditional | conditional | R24 | P13-UC01 |
| M11-F02 | Assign accountability and timing | Record management owner, target date, priority, expected result and current status. | conditional | conditional | R24 | P13-UC01 |
| M11-F03 | Preserve traceability to the finding | Link the action to the original finding, workpaper, communication, management response and relevant engagement. | conditional | conditional | R24 | P13-UC01 |
| M11-F04 | Collect progress updates and evidence | Record management updates, revised dates and implementation evidence while distinguishing self-reported progress. | conditional | conditional | R24 | P13-UC01 |
| M11-F05 | Verify implementation | Assign auditor verification or retesting, record work performed and conclude whether the action is implemented and effective. | conditional | conditional | R24 | P13-UC02 |
| M11-F06 | Extend, reopen or escalate an action | Record approved extensions, inadequate evidence, failed retest, overdue escalation and revised commitments. | conditional | conditional | R24 | P13-UC02, P13-UC03 |
| M11-F07 | Close with a verified conclusion | Record closure conclusion, verifier, reviewer and date; preserve reopen history if later evidence contradicts closure. | conditional | conditional | R24 | P13-UC02, P13-UC03 |
| M11-F08 | Report follow-up status | View overdue, due-soon, awaiting evidence, under verification, closed and ineffective actions by client, owner and priority. | conditional | conditional | R24 | P13-UC01, P13-UC03 |
| M12-F01 | Complete the engagement-close checklist | Confirm report issue, required reviews, representations, unresolved items, file status and responsible approvals. | core | unverified | R21 | P12-UC01 |
| M12-F02 | Assemble the final audit file | Collect final workpapers, evidence, reports, communications and cross-references into the approved index after the report date. | core | unverified | R21 | P12-UC01 |
| M12-F03 | Run final-file diagnostics | Identify missing workpapers, incomplete sign-offs, open review notes, unresolved check-outs, broken links and non-final versions. | core | unverified | R21 | P12-UC01 |
| M12-F04 | Control post-report assembly changes | Permit documented administrative assembly changes only, recording what changed, why, by whom and when; substantive change follows a separate authorized path. | core | partial-evidence | R21 | P10-UC09, P12-UC02 |
| M12-F05 | Approve and lock the completed file | Record completion approval and make the final file read-only, with any later reopening separately authorized and logged. | core | unverified | R21 | P12-UC02 |
| M12-F06 | Create the archive package and metadata | Package the locked file with engagement identity, period, report date, completion date, classification, retention basis and index. | core | unverified | R21 | P12-UC01, P12-UC03 |
| M12-F07 | Control archive access and retrieval | Authorize retrieval, provide read-only access where appropriate and record who accessed, exported or returned the file. | core | partial-evidence | R21 | P12-UC04 |
| M12-F08 | Apply retention schedules and holds | Record the approved retention rule, due date and any legal, regulatory or inspection hold that prevents disposition. | core | partial-evidence | R21 | P12-UC05 |
| M12-F09 | Preserve readability and integrity | Verify that archived content remains identifiable, readable and complete and that approved recovery checks are performed. | core | partial-evidence | R21 | P12-UC03 |
| M12-F10 | Provide a controlled inspection package | Select and release an authorized, read-only file or extract with index and traceable access for quality or regulatory inspection. | core | partial-evidence | R21 | P12-UC04 |
| M12-F11 | Authorize and record disposition | After expiry and hold checks, obtain approval, securely dispose of eligible files and retain a disposition record. | core | partial-evidence | R21 | P12-UC05 |
| CC01 | Workflow, status and stage hand-off | Consistent state, readiness, return-for-rework and authorized transition across modules. | core | unverified | R09 | P16-UC01 |
| CC02 | Business roles and access restriction | Assign responsibility and limit business actions by role; technical identity and authorization design remains out of scope. | core | unverified | R10 | P16-UC03 |
| CC03 | Tasks, owners, dates and notifications | Track who must do what by when and surface overdue or blocked work. | core | unverified | R06 | P16-UC01 |
| CC04 | Review notes, sign-off and resolution | Raise, assign, answer, clear and reopen review matters with dated sign-off. | core | unverified | R19 | P16-UC01 |
| CC05 | Documents, evidence and cross-reference | Attach or link support and navigate from requirement to work, evidence, finding and conclusion. | core | unverified | R14 | P16-UC03 |
| CC06 | Version history and audit trail | Preserve material changes, prior states, actors, dates and reasons. | core | unverified | R09 | P16-UC03 |
| CC07 | Search, filter and index | Find clients, engagements, forms, procedures, workpapers, findings and actions through stable identifiers and metadata. | core | unverified | R02 | P16-UC02 |
| CC08 | Dashboards and operational reporting | Show workload, progress, open items, review status, deadlines and completion without redefining professional conclusions. | core | unverified | R06 | P16-UC02 |
| CC09 | Configurable methodology and terminology | Apply approved templates, labels and guidance consistently while retaining version identity. | core | unverified | R08 | P16-UC03 |
| CC10 | Import, export and readable output | Bring in ordinary files/data and produce authorized readable packages without specifying integration architecture. | core | unverified | R07 | P16-UC03 |

## All 58 automation minimum contracts

Each minimum below has its own implementation/verification obligation. Preserve existing calculations that meet the method. Compare the remaining method, outputs, failure handling, human responsibility and downstream use before closure. Future extensions have separate decisions.

### AUTO-001 — Evidence coverage monitoring

**Primary package** R14. **Current evidence** partial-evidence. **Cases** P08-UC01, P08-UC04.

**Source minimum** Show whether every approved evidence request has an accepted item for the intended entity and reporting period.

**Inputs** Required: request identifier, evidence type, entity, reporting period, linked evidence identifier and acceptance status. Optional: alternative-evidence rationale.

**Source method**

- For each approved request r, join only explicit in-scope evidence links. A link must match entity/period and approved intended use.
- Classify covered, missing, rejected-only or approved alternative. Current minimum does not union partial coverage intervals.
- Retain contributing request/evidence/alternative IDs and unresolved counts
-  coverage is not an evidence-sufficiency opinion.

**Required output**

A coverage register with received, missing, rejected-only and alternative-evidence items, plus unresolved counts.

**Human responsibility**

Define the required evidence, accept or reject submitted items, assess sufficiency and approve any alternative source.

**Method boundary**

The baseline does not inspect document contents, combine partial date intervals or conclude that accepted evidence is sufficient and appropriate.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.2, card 1; F00011 matching card 1; F00009/F00012 catalogue entry 1

### AUTO-002 — Dataset conformance and scope validation

**Primary package** R13. **Current evidence** unverified. **Cases** P05-UC01, P05-UC02, P05-UC03.

**Source minimum** Determine whether an uploaded structured dataset has the required structure and belongs to the selected engagement scope.

**Inputs** Required: source dataset, approved import profile, column mapping, engagement entity and reporting dates. Optional: currency, sign and evidence-role rules.

**Source method**

- Validate mapped required columns, declared datatypes/null rules/allowed values, including finite numeric values for monetary quantities without changing invalid values to zero.
- Compare declared entity/row dates with selected engagement and evidence role. Classify out-of-scope rows explicitly.
- Keep accepted/quarantined rows with original row IDs. Schema validity does not prove source completeness or economic validity.

**Required output**

A field-level defect register, accepted and quarantined row counts, and a visible scope exception list.

**Human responsibility**

Select or approve the import profile, map source columns, confirm entity and period, and resolve or accept data defects.

**Method boundary**

The baseline does not prove source completeness, reconcile control totals, infer ambiguous formats or validate whether transactions are economically valid.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.2, card 2; F00011 matching card 2; F00009/F00012 catalogue entry 2

### AUTO-003 — Population integrity and import reconciliation

**Primary package** R13. **Current evidence** unverified. **Cases** P05-UC01, P05-UC02, P05-UC03.

**Source minimum** Demonstrate that a structured population reached the audit workspace without unexplained loss, duplication or total-value change.

**Inputs** Required: imported rows, source record count, available independent control totals and declared unique key. Optional: documented exclusion reasons.

**Source method**

- count_residual = certified_source_count - accepted_count - quarantined_count - documented_excluded_count, under a disjoint bridge.
- amount_residual = certified_source_total - bridged_total, separately by entity/currency and debit/credit where relevant.
- Group missing/repeated declared keys and exact duplicate row payloads
-  preserve rows rather than deleting suspected duplicates.

**Required output**

A source-to-import bridge, unexplained residuals, missing-key cases and exact duplicate groups with affected values.

**Human responsibility**

Obtain or certify source controls, define the business key, explain exclusions and decide whether unresolved differences limit reliance.

**Method boundary**

The baseline covers one source-to-import stage. It does not reconstruct complex joins, prove controls generated by the same file are independent or perform fuzzy duplicate detection.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.3, card 3; F00011 matching card 3; F00009/F00012 catalogue entry 3

### AUTO-004 — Master-data and identifier consistency

**Primary package** R13. **Current evidence** unverified. **Cases** P05-UC01, P05-UC02, P05-UC03.

**Source minimum** Identify transactions whose account, customer, supplier, employee, item or currency identifier cannot be resolved unambiguously to the supplied master data.

**Inputs** Required: transaction identifier, master identifier and authoritative master table. Required for historical matching: transaction date and master validity dates.

**Source method**

- Left-match each transaction ID to the approved master and optional effective-date interval.
- Classify match_count = 0 as unmatched and match_count > 1 as ambiguous. Retain inactive historical master rows valid on transaction date.
- Aggregate affected counts and gross exposure by master family. Do not choose by similar names or current active status alone.

**Required output**

An unmatched and ambiguous transaction list with candidate master records and affected exposure.

**Human responsibility**

Select the authoritative master, approve aliases or crosswalks, investigate ambiguous records and determine the audit effect of weak master data.

**Method boundary**

The baseline does not infer identity from free-text names, consult external registries or automatically choose among conflicting master records.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.3, card 4; F00011 matching card 4; F00009/F00012 catalogue entry 4

### AUTO-005 — Ledger and trial-balance integrity

**Primary package** R13. **Current evidence** unverified. **Cases** P05-UC01, P05-UC02, P05-UC03.

**Source minimum** Confirm that the trial balance rolls forward correctly, balances under the declared sign convention and agrees with detailed ledger movements.

**Inputs** Required: trial-balance account, opening, debit, credit and closing fields; detailed ledger account, posting date and debit-credit amounts when ledger reconciliation is run.

**Source method**

- Under debit-positive convention, calculated_closing = opening + debits - credits
-  compare recorded closing using approved tolerance.
- Aggregate in-period ledger debit and credit separately and compare with trial-balance movements, retaining unmatched accounts.
- Check declared complete-ledger balance and account residuals
-  a selected-account extract cannot substantiate whole-ledger balance.

**Required output**

Entity and account-level debit, credit, opening, closing and roll-forward residuals with ledger-row links.

**Human responsibility**

Map fields, confirm the sign convention, period and population completeness, set rounding tolerance and investigate differences.

**Method boundary**

The baseline does not translate currencies, infer opening-only journals, handle consolidation adjustments or claim that a selected-account extract represents a complete ledger.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.4, card 5; F00011 matching card 5; F00009/F00012 catalogue entry 5

### AUTO-006 — Account mapping and financial-statement bridge

**Primary package** R13. **Current evidence** partial-evidence. **Cases** P05-UC01, P05-UC02, P05-UC03.

**Source minimum** Trace every in-scope closing balance through an approved account mapping to the corresponding financial-statement line.

**Inputs** Required: final trial balance, account-to-line mapping, presentation sign, financial-statement line values and displayed unit.

**Source method**

- Require exactly one approved primary statement destination for each in-scope account under the current minimum.
- expected_line = sum(account_closing * presentation_sign) after conversion into the same display unit/currency.
- line_residual = expected_line - recorded_statement_line. Keep unmapped/multi-mapped accounts
-  split allocations are an extension, not this minimum.

**Required output**

A mapping exception list and line-by-line trial-balance-to-financial-statements bridge.

**Human responsibility**

Own and approve the mapping, resolve unusual signs and determine whether non-ledger schedules or adjustments are appropriate.

**Method boundary**

The baseline does not support split allocations, effective-dated mapping changes, non-ledger schedules or automatically extract figures from unstructured statements.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.4, card 6; F00011 matching card 6; F00009/F00012 catalogue entry 6

### AUTO-007 — Financial-statement technical and comparative review

**Primary package** R13. **Current evidence** unverified. **Cases** P05-UC01, P05-UC02, P05-UC03.

**Source minimum** Identify mathematical, reference and repeated-value inconsistencies in a controlled financial-statement and notes package.

**Inputs** Required: one controlled statement version containing structured nodes, amounts, periods, units, formulas and exact references. Optional: approved rounding schedule.

**Source method**

- For each declared total node, calculate sum(signed_operand_amounts) using the selected statement version and rounding profile.
- Check declared note references resolve and repeated-value links agree after approved sign/unit conversion.
- Compare explicitly tagged comparative nodes under the selected comparative basis
-  semantic disclosure completeness remains auditor work.

**Required output**

A cross-footing, cross-reference, repeated-value and comparative exception report linked to statement nodes.

**Human responsibility**

Provide or approve the statement structure, formulas, repeated-value links and comparative basis, then resolve presentation and disclosure implications.

**Method boundary**

The baseline does not infer equivalent disclosures from similar wording, determine disclosure completeness or assess whether accounting classifications are substantively correct.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.5, card 7; F00011 matching card 7; F00009/F00012 catalogue entry 7

### AUTO-008 — Opening-balance reconciliation

**Primary package** R13. **Current evidence** unverified. **Cases** P05-UC01, P05-UC02, P05-UC03.

**Source minimum** Show whether each current-period opening balance agrees with the corresponding prior audited closing balance after approved opening adjustments.

**Inputs** Required: prior audited closing trial balance, current opening trial balance, common account identifier or approved crosswalk, entity and currency.

**Source method**

- Exact-match prior audited closing and current opening accounts through an approved crosswalk.
- opening_residual = current_opening - prior_closing - linked_approved_opening_adjustments, in common units/currency.
- Retain unmatched accounts and unexplained residuals. Complex foreign-currency/business-combination adjustments need a separate supported bridge.

**Required output**

An opening-balance bridge containing matched balances, approved adjustments, unmatched accounts and unexplained residuals.

**Human responsibility**

Select the authoritative prior audited balance, approve account crosswalks and opening adjustments, and determine follow-up for unresolved differences.

**Method boundary**

The baseline does not evaluate comparative disclosures, automatically carry forward prior findings or resolve foreign-currency and business-combination adjustments.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.5, card 8; F00011 matching card 8; F00009/F00012 catalogue entry 8

### AUTO-009 — Journal-entry analysis workspace

**Primary package** R15. **Current evidence** partial-evidence. **Cases** P09-UC04, P09-UC11.

**Source minimum** Run a small set of explainable risk filters over a complete journal population and investigate the resulting entries in one case list.

**Inputs** Required: journal and line identifiers, entity, effective date, account, debit-credit or signed functional amount, reporting dates and selected rule parameters.

**Source method**

- Build an exact whole-journal fingerprint from canonical line content preserving line multiplicities
-  flag duplicate fingerprints, not net-zero amounts.
- Evaluate effective-date scope/close-date, approved round-unit and threshold predicates
-  invalid dates/units are not evaluated.
- Create one investigation case per journal with all triggers and contributing rows. Retain gross debit/credit exposure without multiplying it by trigger count.

**Required output**

A deduplicated journal investigation queue with trigger reasons, affected lines, amounts and auditor disposition.

**Human responsibility**

Confirm population completeness, select applicable filters and thresholds, investigate supporting evidence and conclude whether each case is legitimate or misstated.

**Method boundary**

The baseline excludes near-duplicate text matching, journal-number sequences, user rarity, sensitive account combinations, segregation conflicts and rapid reversal analysis.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.6, card 9; F00011 matching card 9; F00009/F00012 catalogue entry 9

### AUTO-010 — Analytical review workspace

**Primary package** R13. **Current evidence** partial-evidence. **Cases** P06-UC03, P06-UC05.

**Source minimum** Compare current results with an auditor-approved expectation and preserve significant unexplained movements for investigation and final review.

**Inputs** Required: account or statement-line values for comparable periods, approved analytical relationships and investigation thresholds. Optional: budgets and non-financial drivers.

**Source method**

- absolute_change = current - comparable_prior
-  percentage_change = (current - comparable_prior) / abs(comparable_prior) only when the selected convention permits and prior is nonzero.
- Evaluate each approved ratio numerator/denominator and absolute/percentage investigation predicate in compatible periods/units.
- Retain explanation, supporting versions and disposition on refresh
-  flag staleness when operands change. No automatic expectation or seasonality model.

**Required output**

A movement and ratio table with flagged relationships, explanations, evidence links and unresolved cases.

**Human responsibility**

Choose relevant relationships, establish expectations and thresholds, evaluate management explanations and make the planning or final analytical conclusion.

**Method boundary**

The baseline does not generate expectations automatically, model seasonality, forecast balances or decide whether an explanation is audit evidence.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.6, card 10; F00011 matching card 10; F00009/F00012 catalogue entry 10

### AUTO-011 — Sales-population integrity and reconciliation

**Primary package** R16. **Current evidence** unverified. **Cases** P09-UC02, P09-UC11.

**Source minimum** Establish that the uploaded sales register agrees with ledger revenue and does not contain missing identifiers or exact duplicate invoices.

**Inputs** Required: invoice and line identifiers, posting date, revenue account, signed amount, customer and ledger or trial-balance revenue totals.

**Source method**

- Aggregate in-period sales by approved revenue-account mapping and compare with ledger/TB movements.
- Flag missing keys, repeated declared keys at the declared invoice/line grain, and exact duplicate records without deleting them.
- Retain register-to-ledger residuals and original sales rows. Repeated header ID across valid lines is not automatically a duplicate invoice.

**Required output**

A sales-to-ledger bridge and invoice-population exception list with affected revenue amounts.

**Human responsibility**

Confirm the sales population and account mapping, define the invoice business key, explain differences and determine whether exceptions require substantive testing.

**Method boundary**

The baseline does not test invoice sequence completeness, fuzzy economic duplicates, zero or negative commercial validity, cut-off or revenue recognition.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.7, card 11; F00011 matching card 11; F00009/F00012 catalogue entry 11

### AUTO-012 — Revenue cut-off and credit-note review

**Primary package** R16. **Current evidence** partial-evidence. **Cases** P09-UC02, P09-UC11.

**Source minimum** Identify sales whose invoice, delivery or posting dates indicate possible recording in the wrong period and credits linked to year-end sales.

**Inputs** Required: invoice identifier, invoice date, posting date, delivery or acceptance date when relevant, amount and reporting date. Credit review also requires original-invoice reference.

**Source method**

- Select approved period-end windows and compare supplied invoice, delivery/acceptance and posting dates with reporting boundary.
- Exact-link post-period credits to pre-period invoices through original references
-  unmatched credits remain unmatched.
- One case per supported economic-event identity retains all timing/credit reasons. A date difference does not itself determine transfer of control.

**Required output**

A cut-off and linked-credit case list showing dates, amounts, source links and unresolved status.

**Human responsibility**

Define the relevant performance evidence and window, investigate the transaction and determine the correct recognition period and any misstatement.

**Method boundary**

The baseline does not interpret contract terms, infer delivery from unstructured documents, fuzzy-match unreferenced credits or conclude when control transferred.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.7, card 12; F00011 matching card 12; F00009/F00012 catalogue entry 12

### AUTO-013 — Receivables aging and subsequent-cash matching

**Primary package** R16. **Current evidence** partial-evidence. **Cases** P09-UC02, P09-UC11.

**Source minimum** Recalculate invoice aging at the reporting date and show which balances are supported by explicitly referenced subsequent receipts.

**Inputs** Required: invoice identifier, customer, invoice and due dates, open amount, reporting date, receipt date, receipt amount and invoice reference.

**Source method**

- Calculate signed days relative to due date under the selected calendar; days overdue = max(signed days,0), with not-yet-due kept separately. Use invoice age only as a separately labelled basis; bucket boundaries are explicit and nonoverlapping.
-  use invoice age only in a separately labelled basis. Bucket boundaries must be explicit/nonoverlapping.
- Exact-reference subsequent receipts to invoices
-  allocation <= remaining_invoice_open_amount and <= remaining_receipt_amount, with recorded allocation order.
- Show unmatched/ambiguous receipts and over-allocation separately. Later cash does not conclusively prove the whole valuation assertion.

**Required output**

A recomputed aging schedule and invoice-to-cash allocation with unmatched and partially collected balances.

**Human responsibility**

Approve aging buckets and the cash cut-off date, investigate unmatched items and evaluate whether subsequent collection supports recoverability.

**Method boundary**

The baseline does not allocate unreferenced cash, estimate credit losses, evaluate disputes or treat receipt after year-end as conclusive evidence of valuation.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.8, card 13; F00011 matching card 13; F00009/F00012 catalogue entry 13

### AUTO-014 — Sales pricing and discount compliance

**Primary package** R16. **Current evidence** partial-evidence. **Cases** P09-UC02, P09-UC11.

**Source minimum** Identify invoice lines whose recorded amount, price or discount differs from approved commercial terms supplied for testing.

**Inputs** Required: invoice and line identifiers, quantity, unit price, discount, recorded line amount and approved price or discount reference.

**Source method**

- expected_line = quantity * unit_price - structured_discount + structured_tax under the declared net/gross convention
-  round at the selected stage.
- Compare price and discount with the applicable approved list/limit and validity scope.
- Keep arithmetic variance and authorisation variance separate. Unsupported compound rebates or contract interpretation is not computed.

**Required output**

A line-level price, discount and arithmetic variance report with affected sales amounts.

**Human responsibility**

Select the authoritative price and discount terms, approve any exceptions, inspect commercial evidence and decide whether a variance is a misstatement or valid arrangement.

**Method boundary**

The baseline does not extract terms from contracts, calculate complex rebates, optimize pricing or determine whether non-standard terms are commercially appropriate.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.8, card 14; F00011 matching card 14; F00009/F00012 catalogue entry 14

### AUTO-015 — Revenue-recognition schedule recalculation

**Primary package** R16. **Current evidence** unverified. **Cases** P09-UC02, P09-UC11.

**Source minimum** Recalculate a straight-line time-based revenue schedule from approved contract dates and compare it with recorded period revenue.

**Inputs** Required: contract identifier, approved transaction amount, service start and end dates, reporting period, recorded recognized amount and selected allocation convention.

**Source method**

- Validate service range and choose one explicit inclusive/exclusive day or month convention
-  duration must be positive.
- expected_period_revenue = approved_transaction_amount * overlap_service_units / total_service_units, subject to the selected simple allocation basis.
- Compare current recognised/deferred amounts and retain residuals
-  obligation identification, variable consideration and modifications stay outside the minimum.

**Required output**

An expected recognition schedule, recorded values and period or closing-balance variances by contract.

**Human responsibility**

Confirm that the supported method applies, approve contract dates, amount and allocation convention, and make all recognition and contract-accounting judgments.

**Method boundary**

The baseline excludes performance-obligation identification, standalone selling-price allocation, milestone evidence, variable consideration and contract modifications.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.9, card 15; F00011 matching card 15; F00009/F00012 catalogue entry 15

### AUTO-016 — Purchases and payments population review

**Primary package** R16. **Current evidence** partial-evidence. **Cases** P09-UC02, P09-UC11.

**Source minimum** Reconcile the purchase register to ledger expense or payable movements and identify exact duplicate supplier invoices or payments.

**Inputs** Required: supplier, invoice identifier and date, payment identifier and date, account, signed amount and ledger or trial-balance control totals.

**Source method**

- Aggregate purchases under approved account/period mapping and compare with ledger/TB controls.
- Group exact invoice duplicates at the approved invoice business key and payment duplicates at the approved payment key.
- Retain separate reconciliation/invoice/payment cases and source rows
-  a duplicate indicator is not proof of fraud.

**Required output**

A purchase-to-ledger bridge and exact duplicate invoice or payment groups with gross affected values.

**Human responsibility**

Confirm population completeness and mappings, define duplicate keys, investigate supporting documents and determine whether repeated items are legitimate or misstated.

**Method boundary**

The baseline does not perform fuzzy matching, detect split or redirected payments, reconcile the full document chain or infer fraud from duplicate indicators.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.9, card 16; F00011 matching card 16; F00009/F00012 catalogue entry 16

### AUTO-017 — Supplier and payee identity-risk analysis

**Primary package** R16. **Current evidence** unverified. **Cases** P09-UC02, P09-UC11.

**Source minimum** Surface counterparties that share exact or normalized identifiers and show the transactions exposed to those relationships.

**Inputs** Required: supplier identifier, legal name and at least one reliable registration number or bank account. Optional: address, contact data and payment history.

**Source method**

- Normalise only under an approved profile, preserving raw values
-  do not remove identity-significant characters without a stated rule.
- Group exact registration/account matches separately from normalised-name candidates, with rule and matching basis.
- Link clusters to count/exposure without multiplying the same transaction by each cluster edge. Shared identity attributes do not prove beneficial ownership or fraud.

**Required output**

An explainable supplier or payee cluster list with matched fields and transaction exposure.

**Human responsibility**

Confirm authoritative identifiers, investigate ownership and commercial relationships, approve legitimate shared accounts and determine the audit response.

**Method boundary**

The baseline does not establish beneficial ownership, search external registries, infer relationships from unrestricted text or make a fraud or related-party conclusion.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.10, card 17; F00011 matching card 17; F00009/F00012 catalogue entry 17

### AUTO-018 — Procure-to-pay document matching

**Primary package** R16. **Current evidence** partial-evidence. **Cases** P09-UC02, P09-UC11.

**Source minimum** Show whether each selected purchase can be traced through purchase order, receipt, invoice and payment records using stable source identifiers.

**Inputs** Required: structured order, receipt, invoice and payment records with stable document and line identifiers, quantities, amounts and currencies.

**Source method**

- Join order-receipt-invoice-payment using approved exact document/line keys and declared grain.
- Compare matched quantity/amount with tolerances after validating units/currency
-  expose missing links at each stage.
- Retain valid one-to-many lines and partial quantities. Do not flatten header joins that multiply amounts
-  unsupported many-to-many transformations remain unresolved.

**Required output**

A document-chain status table with missing links, quantity differences and amount variances.

**Human responsibility**

Confirm source-system relationships and tolerances, investigate missing or inconsistent documents and decide whether exceptions indicate error or control failure.

**Method boundary**

The baseline requires structured records and exact identifiers. It does not read scanned documents, infer links from descriptions or support undocumented many-to-many transformations.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.10, card 18; F00011 matching card 18; F00009/F00012 catalogue entry 18

### AUTO-019 — Payables cut-off and unrecorded-liability review

**Primary package** R16. **Current evidence** partial-evidence. **Cases** P09-UC02, P09-UC11.

**Source minimum** Identify pre-period receipts or services and post-period invoices or payments that may indicate an omitted or late-recorded year-end liability.

**Inputs** Required: supplier, receipt or service date, invoice date, posting date, payment date, document references, amounts and year-end payable or accrual records.

**Source method**

- Select approved receipt/service/invoice/posting/payment windows around period end.
- Exact-match later invoices/payments to pre-period receipts/services and recorded year-end payables/accruals.
- Unmatched chains become candidate cases with dates and gross exposure
-  they are not automatic omitted liabilities or accrual estimates.

**Required output**

A linked cut-off case list and candidate unrecorded-liability population with source records.

**Human responsibility**

Define the look-back and look-forward windows, evaluate when the obligation arose, inspect evidence and conclude whether a liability or cut-off misstatement exists.

**Method boundary**

The baseline does not infer obligations from unstructured contracts, fuzzy-match unsupported records, calculate accrual estimates or conclude that unmatched payments prove omission.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.11, card 19; F00011 matching card 19; F00009/F00012 catalogue entry 19

### AUTO-020 — Bank matching and reconciliation

**Primary package** R16. **Current evidence** partial-evidence. **Cases** P09-UC02, P09-UC11.

**Source minimum** Match structured bank-statement lines to cash-ledger entries and recalculate the arithmetic of a supplied period-end bank reconciliation.

**Inputs** Required: bank account, statement date, transaction date, amount, currency and reference; ledger cash entries; and the supplied reconciliation balance and items.

**Source method**

- First match exact references
-  then consider one-to-one amount/currency/date-window matches only when unique under the approved profile.
- Retain ambiguous and unmatched bank/ledger rows
-  no silent netting or inferred fee/interest entry.
- Apply signed documented reconciling items to the selected book/bank basis and compute residual. Many-to-many matching and foreign exchange require supported extensions.

**Required output**

Matched and unmatched transaction tables plus a recalculated bank-reconciliation residual.

**Human responsibility**

Confirm bank-account scope and matching window, approve matches, investigate stale or unsupported reconciling items and assess the reliability of the reconciliation.

**Method boundary**

The baseline does not connect directly to banks, perform complex many-to-many matching, recalculate foreign exchange or infer missing fees and interest automatically.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.11, card 20; F00011 matching card 20; F00009/F00012 catalogue entry 20

### AUTO-021 — Cash movement and payment-risk analytics

**Primary package** R16. **Current evidence** unverified. **Cases** P09-UC02, P09-UC11.

**Source minimum** Identify large, round or period-end cash transactions and exact inter-account transfer pairs for targeted audit investigation.

**Inputs** Required: cash transaction identifier, account, date, amount, currency, reference and reporting date. Transfer matching also requires known internal bank accounts.

**Source method**

- Apply approved absolute amount, round-unit and period-end window predicates to cash rows.
- Pair equal/opposite transfers only across known company bank accounts in compatible currency/date windows and with unambiguous eligibility.
- Consolidate triggers into one source transaction/event case. Unusual cash patterns are investigation candidates, not fraud conclusions.

**Required output**

A cash-risk case list with trigger reasons, paired transfers, unpaired legs and affected amounts.

**Human responsibility**

Set justified thresholds, confirm the population and company accounts, investigate authorization and business purpose, and conclude whether each case is valid.

**Method boundary**

The baseline does not model normal behavior, verify approval limits, perform fuzzy payment matching or determine whether unusual timing indicates fraud.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.12, card 21; F00011 matching card 21; F00009/F00012 catalogue entry 21

### AUTO-022 — Inventory register and movement integrity

**Primary package** R16. **Current evidence** partial-evidence. **Cases** P05-UC01, P05-UC02, P09-UC02, P09-UC11.

**Source minimum** Confirm that inventory quantities and values roll forward by item and that the closing register agrees with the corresponding ledger balance.

**Inputs** Required: item and movement identifiers, date, movement type, quantity, unit, recorded value, opening and closing quantities, location where used, and mapped ledger balance.

**Source method**

- expected_closing_quantity = opening + receipts - issues + signed_documented_adjustments under the approved movement taxonomy.
- Reconcile recorded closing value and movements to mapped ledger accounts without claiming cost recalculation.
- Flag negative stock, missing movement IDs and exact duplicates while retaining affected rows
-  incompatible units/unknown movement types are not silently normalised.

**Required output**

An item-level quantity roll-forward, register-to-ledger bridge and negative or duplicate movement case list.

**Human responsibility**

Confirm the inventory scope, movement types, units and account mapping, explain adjustments and determine whether identified cases require further testing.

**Method boundary**

The baseline does not recalculate unit cost, convert incompatible units, infer undocumented movement types or evaluate the business purpose of adjustments.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.12, card 22; F00011 matching card 22; F00009/F00012 catalogue entry 22

### AUTO-023 — Inventory-count reconciliation

**Primary package** R16. **Current evidence** partial-evidence. **Cases** P09-UC05, P09-UC02, P09-UC11.

**Source minimum** Compare signed count quantities with the inventory register and show every unresolved difference for the counted items and locations.

**Inputs** Required: controlled count sheet, count date, item, location, counted quantity, book quantity and unit. Optional: recount and approved adjustment references.

**Source method**

- Exact-match controlled count rows to approved item/location register grain, keeping unmatched and duplicate/ambiguous matches.
- quantity_difference = counted_quantity - book_quantity at the same count-date basis/unit.
- Show approved adjustment/recount support separately, plus uncounted selected units and unresolved differences. The calculation does not prove proper observation or physical coverage.

**Required output**

A count coverage table and item-location reconciliation showing initial difference, adjustment and unresolved quantity.

**Human responsibility**

Establish the count scope, assess observation evidence and count-sheet reliability, approve mappings or adjustments and conclude on existence and condition.

**Method boundary**

The baseline does not prove that the physical count was properly performed, assess inventory condition, extrapolate omitted locations or replace auditor observation.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.13, card 23; F00011 matching card 23; F00009/F00012 catalogue entry 23

### AUTO-024 — Inventory cut-off and transfer consistency

**Primary package** R16. **Current evidence** unverified. **Cases** P09-UC05, P09-UC02, P09-UC11.

**Source minimum** Identify receipts, dispatches and internal transfers around year-end whose logistics and accounting dates are inconsistent with the selected cut-off rules.

**Inputs** Required: movement or transfer identifier, item, location, quantity, logistics date, posting date, transaction type and reporting date.

**Source method**

- Compare supplied receipt/dispatch dates to inventory/purchase/sales/ledger posting dates in the approved cutoff window.
- Pair transfer legs by exact transfer ID/item and declared unit, preserving source/destination roles
-  quantity residual = incoming - outgoing on a common basis.
- Consolidate timing/unmatched-leg reasons for each event without judging shipping terms or recognition automatically.

**Required output**

A period-end cut-off case list and paired or unmatched internal-transfer report.

**Human responsibility**

Select the relevant logistics date and window, investigate terms and source evidence, and determine the correct inventory and related purchase or sales period.

**Method boundary**

The baseline does not interpret shipping terms, infer event dates from documents, convert incompatible units or conclude that a timing difference is a misstatement.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.13, card 24; F00011 matching card 24; F00009/F00012 catalogue entry 24

### AUTO-025 — Inventory costing and cost-of-sales recalculation

**Primary package** R16. **Current evidence** unverified. **Cases** P09-UC02, P09-UC11.

**Source minimum** Recalculate inventory issue cost and closing value under a supported periodic weighted-average method and compare them with recorded inventory and cost of sales.

**Inputs** Required: opening quantity and cost, purchase quantities and costs, issue and closing quantities, reporting period, recorded inventory value and recorded cost of sales.

**Source method**

- For the periodic weighted-average minimum, available_quantity = opening_quantity + sum(purchase_quantity)
-  available_cost = opening_cost + sum(purchase_cost). Reject invalid/negative inputs or nonpositive denominator under this profile.
- weighted_average_cost = available_cost / available_quantity
-  expected_issue_cost = issue_quantity * weighted_average_cost
-  expected_closing_value = closing_quantity * weighted_average_cost.
- Compare recorded inventory/COS and quantity bridge, with approved rounding. FIFO, moving average, overhead and write-down models remain separate extensions.

**Required output**

An expected unit-cost schedule, expected inventory and cost of sales, recorded amounts and variances.

**Human responsibility**

Confirm that the supported method matches the entity's approved policy, map movement types and investigate all cost and ledger variances.

**Method boundary**

The baseline does not support FIFO, moving average, standard cost, overhead absorption, joint products, write-downs or changes in costing method.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.14, card 25; F00011 matching card 25; F00009/F00012 catalogue entry 25

### AUTO-026 — Inventory obsolescence and NRV indicators

**Primary package** R16. **Current evidence** unverified. **Cases** P09-UC02, P09-UC06, P09-UC11.

**Source minimum** Identify slow or non-moving items and items whose recorded cost exceeds an auditor-supplied net realizable value input.

**Inputs** Required: item, quantity, cost, last qualifying movement date and reporting date. NRV comparison additionally requires approved selling-price and completion or disposal-cost inputs.

**Source method**

- Use approved item-level cost, quantities, supported estimated selling price, completion costs and costs necessary to make the sale.
- NRV per unit = estimated selling price - completion costs - costs necessary to make the sale. Proposed shortfall = quantity * max(cost per unit - NRV per unit,0), with approved grouping/cost basis.
- Keep age/turnover/condition indicators distinct from the supported write-down calculation. A generic disposal-cost label is insufficient.

**Required output**

A slow or no-movement list and potential cost-over-NRV cases with calculated exposure.

**Human responsibility**

Define qualifying movements and thresholds, validate selling and disposal-cost evidence, challenge assumptions and make the write-down and valuation conclusion.

**Method boundary**

The baseline does not forecast future sales, infer obsolete condition, derive market prices or calculate a final write-down without approved valuation inputs.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.14, card 26; F00011 matching card 26; F00009/F00012 catalogue entry 26

### AUTO-027 — Asset-register roll-forward and ledger reconciliation

**Primary package** R16. **Current evidence** partial-evidence. **Cases** P09-UC02, P09-UC11.

**Source minimum** Recalculate cost and accumulated depreciation or amortization roll-forwards and reconcile closing register balances with the ledger by asset class.

**Inputs** Required: asset identifier and class, opening cost and accumulated charge, additions, disposals, transfers, current charge, closing values and mapped ledger balances.

**Source method**

- expected_closing_cost = opening_cost + additions - disposals + signed_transfers + other_identified_movements.
- expected_closing_accumulated = opening_accumulated + current_charge - accumulated_on_disposals + signed_adjustments.
- Reconcile register/ledger closings and retain per-asset/class residuals. Existence, recognition and impairment are separate judgments/checks.

**Required output**

Asset-class cost and accumulated-charge bridges with ledger residuals and contributing asset records.

**Human responsibility**

Confirm movement classifications and account mappings, approve legitimate adjustments and determine whether register or ledger differences affect the audit.

**Method boundary**

The baseline does not test depreciation methods, physical existence, impairment, revaluation, component accounting or whether additions meet capitalization criteria.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.15, card 27; F00011 matching card 27; F00009/F00012 catalogue entry 27

### AUTO-028 — Depreciation and amortization recalculation

**Primary package** R16. **Current evidence** unverified. **Cases** P09-UC02, P09-UC11.

**Source minimum** Recalculate straight-line depreciation or finite-life amortization for each asset and compare the expected period charge and closing accumulation with recorded amounts.

**Inputs** Required: asset identifier, class, cost, residual value, useful life or rate, in-service and disposal dates, recorded period charge and reporting dates.

**Source method**

- Validate finite compatible inputs, positive useful life, nonnegative depreciable base/opening accumulated amount and actual eligible service overlap. Existing accumulated depreciation above the base is an explicit unsupported/anomaly result, not a negative current charge.
- For the selected straight-line profile: annual charge = (cost - residual value) / approved useful life; proposed charge = min(annual charge * declared eligible fraction, remaining nonnegative depreciable base). Day/month/fraction conventions and rounding are explicit.
- Compare asset/class/account results. Missing assumptions, zero life or unsupported variants remain not evaluable. Do not automatically reverse excess prior depreciation or infer useful life/impairment.

**Required output**

An asset-level expected charge, closing accumulated amount and recorded variance, summarized by class.

**Human responsibility**

Confirm the accounting method, useful life, residual value, in-service date and treatment of unusual assets, then evaluate whether variances are misstatements.

**Method boundary**

The baseline supports straight-line finite-life schedules only. It excludes declining-balance, units-of-production, components, revaluation, impairment and indefinite-life assessment.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.15, card 28; F00011 matching card 28; F00009/F00012 catalogue entry 28

### AUTO-029 — Asset lifecycle and useful-life analysis

**Primary package** R16. **Current evidence** unverified. **Cases** P09-UC02, P09-UC11.

**Source minimum** Flag asset-register conditions that conflict with recorded status or approved useful-life and rate ranges.

**Inputs** Required: asset identifier, class, status, acquisition and disposal dates, cost, accumulated charge, carrying amount and approved life or rate range.

**Source method**

- Flag active/fully-charged and disposed/nonzero-carrying cases under approved tolerances and statuses.
- Compare supplied life/rate to the class-specific approved range with explicit inclusivity at boundaries.
- Retain unmatched register/ledger asset candidates and source status/dates. Do not infer physical existence or remaining useful life.

**Required output**

A lifecycle and policy-range review list with trigger reason and carrying-value exposure.

**Human responsibility**

Maintain the asset-class policy ranges, investigate continued use and disposal evidence, inspect physical existence where required and decide whether estimates or records need revision.

**Method boundary**

The baseline does not verify physical existence, predict remaining life, classify assets from descriptions or automatically revise useful lives and depreciation.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.16, card 29; F00011 matching card 29; F00009/F00012 catalogue entry 29

### AUTO-030 — Capitalization and repairs screening

**Primary package** R16. **Current evidence** unverified. **Cases** P09-UC02, P09-UC11.

**Source minimum** Select tangible or intangible additions and expense transactions whose amount or supplied category conflicts with the approved capitalization policy.

**Inputs** Required: transaction identifier, date, amount, recorded account, asset or expense category, project code where used and approved policy threshold.

**Source method**

- Compare structured asset additions with the approved category threshold and valid policy version.
- Compare selected repair/project expense categories with the same scoped policy predicates
-  no narrative classification or cost aggregation is inferred.
- Return each threshold/category reason with original amount. Candidate screening does not establish asset-recognition criteria.

**Required output**

A capex-versus-expense screening list with current treatment, rule triggered and gross exposure.

**Human responsibility**

Approve the relevant policy and threshold, inspect the nature and future benefits of expenditure, and make the capitalization or expense conclusion.

**Method boundary**

The baseline does not interpret invoice descriptions, assess asset recognition criteria, combine related costs across transactions or conclude whether expenditure creates future economic benefits.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.16, card 30; F00011 matching card 30; F00009/F00012 catalogue entry 30

### AUTO-031 — Payroll population and disbursement integrity

**Primary package** R16. **Current evidence** partial-evidence. **Cases** P09-UC02, P09-UC11.

**Source minimum** Reconcile payroll totals with ledger and bank disbursements and identify invalid or exact duplicate employee-payment records.

**Inputs** Required: employee and payroll-period identifiers, employment status, gross pay, deductions, net pay, mapped accounts and bank payment reference and amount.

**Source method**

- expected_net = gross_pay - employee_deductions + approved_net_adjustments under the supplied payroll bridge
-  reconcile mapped expense/liability/net totals.
- Exact-match net payment by employee/payroll reference, compatible amount/currency and declared payment grain.
- Flag missing/repeated IDs, inactive-employee payments and exact duplicates without concluding employee existence or payroll fraud.

**Required output**

A payroll-to-ledger and payroll-to-bank bridge plus employee and payment-integrity cases.

**Human responsibility**

Confirm payroll scope and mappings, validate employee status, investigate unmatched or shared payment details and determine the audit response.

**Method boundary**

The baseline does not recalculate statutory deductions, establish employee existence, perform fuzzy payee matching or reconcile every regulatory return.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.17, card 31; F00011 matching card 31; F00009/F00012 catalogue entry 31

### AUTO-032 — Gross-to-net and payroll statutory recalculation

**Primary package** R16. **Current evidence** partial-evidence. **Cases** P09-UC02, P09-UC11.

**Source minimum** Recalculate standard employee gross-to-net pay using an auditor-approved effective tax and social-insurance parameter set.

**Inputs** Required: employee, pay period, structured earnings and deductions, taxable and contribution bases, recorded outputs, and approved effective-dated statutory parameters.

**Source method**

- Use only approved effective-dated rates, bands, caps, bases and employee categories
-  apply the supported declared parameter-pack formulas.
- expected_net = structured_gross - employee_contributions - withholding - other_deductions + permitted_net_adjustments
-  employer contribution is not an employee deduction.
- Compare component/aggregate outputs
-  unsupported category, exemption, retroactive treatment or incomplete pack is not evaluable. No live legal rate is invented.

**Required output**

Employee-level expected tax, social insurance and net pay with aggregate liability variances.

**Human responsibility**

Approve the legally applicable parameter set and employee classification, resolve special cases and make legal or compliance judgments.

**Method boundary**

The baseline does not source legal rates automatically or cover every benefit, exemption, foreign employee, retroactive payment or industry-specific payroll arrangement.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.17, card 32; F00011 matching card 32; F00009/F00012 catalogue entry 32

### AUTO-033 — Payroll variance and off-cycle analytics

**Primary package** R16. **Current evidence** partial-evidence. **Cases** P09-UC02, P09-UC11.

**Source minimum** Identify employee-level pay changes and off-cycle payments that exceed auditor-approved amount, percentage or timing criteria.

**Inputs** Required: employee, payroll period, payment date, gross and net pay, selected components, employment status and approved normal payroll calendar.

**Source method**

- Compare with immediately preceding comparable period after validating employment/component/period basis.
- delta = current - prior
-  percentage_delta = delta / abs(prior) only for supported nonzero prior. Apply explicit absolute/percentage predicates.
- Flag off-calendar payments and combine triggers per employee-period
-  retain missing/noncomparable history instead of a fabricated variance.

**Required output**

A payroll change and timing case list showing current, comparative, variance and trigger reason.

**Human responsibility**

Define comparable periods and justified thresholds, account for hires, terminations and promotions, inspect authorization and determine whether changes are valid.

**Method boundary**

The baseline does not learn expected behavior, evaluate peer groups, classify narrative explanations or conclude that unusual pay indicates fraud or error.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.18, card 33; F00011 matching card 33; F00009/F00012 catalogue entry 33

### AUTO-034 — VAT and withholding-tax reconciliation

**Primary package** R16. **Current evidence** partial-evidence. **Cases** P09-UC02, P09-UC11.

**Source minimum** Reconcile uploaded VAT or withholding registers to ledger liabilities and filed returns and recalculate structured tax amounts using approved rates.

**Inputs** Required: tax period, transaction or register identifier, taxable base, category, recorded tax, approved rate, mapped ledger balance and filed-return totals.

**Source method**

- Aggregate structured tax records by tax period/category/rate
-  reconcile ledger and filed-return totals in common units.
- expected_tax = approved_taxable_base * approved_rate under supported effective rules/rounding
-  compare recorded tax separately.
- Retain missing period, rate and unmatched-total cases. Classification, exemptions, special regimes and filing remain outside unsupported scope.

**Required output**

A register-to-ledger-to-return bridge with period, category, rate and amount variances.

**Human responsibility**

Determine the applicable tax treatment, approve categories and rates, assess exemptions and resolve filing or payment consequences with tax specialists where needed.

**Method boundary**

The baseline does not make legal tax classifications, obtain authority data automatically, prepare filings or cover unsupported exemptions and special regimes.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.18, card 34; F00011 matching card 34; F00009/F00012 catalogue entry 34

### AUTO-035 — Corporate-income-tax reconciliation

**Primary package** R16. **Current evidence** partial-evidence. **Cases** P09-UC02, P09-UC11.

**Source minimum** Reperform the arithmetic of approved current and deferred tax schedules and reconcile their recorded amounts to ledger, return and payment evidence.

**Inputs** Required: accounting profit, approved tax adjustments, temporary-difference schedule, approved rates, ledger balances, filed-return amount and relevant payments.

**Source method**

- taxable_profit = accounting_profit + signed_approved_tax_adjustments
-  current_tax = supported_tax_base * approved_rate, with approved loss/offset treatment.
- deferred_tax_candidate = sum(signed_temporary_difference * applicable_rate) under supplied categories and recognition decisions.
- Reconcile current/deferred balances, return and payment bridge. No deferred-asset recognition or uncertain-tax judgment is automated.

**Required output**

A current-tax bridge, deferred-tax schedule and ledger, return or payment variances with unresolved judgment items.

**Human responsibility**

Classify tax adjustments and temporary differences, approve rates and recognition decisions, interpret law and conclude on uncertain or recoverable tax positions.

**Method boundary**

The baseline does not interpret tax law, determine recognition of deferred-tax assets, model uncertain tax positions or prepare the corporate tax return.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.19, card 35; F00011 matching card 35; F00009/F00012 catalogue entry 35

### AUTO-036 — Borrowings, interest and covenant review

**Primary package** R16. **Current evidence** partial-evidence. **Cases** P09-UC02, P09-UC11.

**Source minimum** Reconcile each borrowing facility's principal movement, recalculate contractual interest and show headroom under an auditor-approved covenant formula.

**Inputs** Required: facility identifier, opening principal, drawdowns, repayments, closing balance, contractual rate and dates, ledger or lender balance, and approved covenant formula inputs.

**Source method**

- expected_principal = opening + drawdowns - repayments + other_identified_movements
-  compare ledger/lender balances.
- simple_interest = sum(eligible_principal_segment * approved_rate * declared_day_fraction), using actual principal-change segments.
- Evaluate approved covenant expression
-  headroom = limit - metric for maximum limits and metric - limit for minimum limits. Missing definition/waiver terms stay unresolved.

**Required output**

A facility roll-forward, interest variance and covenant-headroom schedule with unresolved classification matters.

**Human responsibility**

Confirm contractual terms, effective dates and covenant definitions, assess waivers and rights, and make current or non-current classification and breach conclusions.

**Method boundary**

The baseline does not calculate effective interest, account for fees or modifications, interpret covenant contracts or determine balance-sheet classification automatically.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.19, card 36; F00011 matching card 36; F00009/F00012 catalogue entry 36

### AUTO-037 — Lease-accounting recalculation

**Primary package** R16. **Current evidence** partial-evidence. **Cases** P09-UC02, P09-UC11.

**Source minimum** Recalculate a fixed-payment lease liability and straight-line right-of-use asset schedule and compare both with recorded ledger balances.

**Inputs** Required: lease identifier, commencement and end dates, fixed payment schedule, approved discount rate, initial right-of-use adjustments and recorded ledger balances.

**Source method**

- initial_liability = sum(fixed_payment_t / (1 + compatible_period_rate)^t), with declared payment timing/day fractions.
- liability_close = liability_open + period_interest - period_payments
-  initial_ROU = initial_liability + supplied_initial_adjustments.
- Apply approved straight-line ROU life/timing and reconcile balances/expense. Modifications, variable/index payments and other excluded variants are not silently approximated.
- The selected timing/period-rate convention must be compatible. Zero rate reduces PV to the sum of eligible payments; an invalid denominator is not evaluated. The one-period example excludes initial adjustments and all complex variants.

**Required output**

A lease liability and right-of-use schedule with interest, depreciation, closing balances and ledger variances.

**Human responsibility**

Confirm lease completeness, scope, term, discount rate and accounting elections, evaluate classification and modifications, and conclude on any misstatement.

**Method boundary**

The baseline excludes variable or index-linked payments, modifications, reassessments, exemptions, foreign currency, restoration obligations and complex tax effects.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.20, card 37; F00011 matching card 37; F00009/F00012 catalogue entry 37

### AUTO-038 — Foreign-currency recalculation and retranslation

**Primary package** R16. **Current evidence** partial-evidence. **Cases** P09-UC02, P09-UC11.

**Source minimum** Recalculate recorded functional-currency amounts using an approved exchange-rate table and retranslate closing monetary balances at the approved period-end rate.

**Inputs** Required: transaction or balance identifier, foreign amount and currency, functional amount, transaction date, reporting date, monetary-item status and approved rate table.

**Source method**

- expected_functional = foreign_amount * approved_functional_per_foreign_rate at the applicable transaction date
-  validate direction.
- For approved monetary items only, expected_close = foreign_balance * approved_closing_rate
-  residual uses the same currency/unit.
- Report missing/ambiguous rate and amount differences. Do not fetch/substitute rates or infer monetary status and presentation treatment.

**Required output**

Transaction-rate and closing-retranslation variances, missing-rate cases and calculated foreign-exchange difference.

**Human responsibility**

Approve the rate source, determine whether average or historical rates are appropriate, identify monetary items and evaluate the accounting treatment of differences.

**Method boundary**

The baseline does not retrieve rates automatically, select accounting rates, handle hedging, translate foreign operations or determine presentation of exchange differences.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.20, card 38; F00011 matching card 38; F00009/F00012 catalogue entry 38

### AUTO-039 — Equity roll-forward and authorization review

**Primary package** R16. **Current evidence** partial-evidence. **Cases** P09-UC02, P09-UC11.

**Source minimum** Reconcile the movement in each equity component and show whether contributions, share changes and dividends have linked authorization evidence.

**Inputs** Required: equity component, opening balance, movement type and amount, profit linkage, closing ledger balance and authorization reference for share or dividend actions.

**Source method**

- expected_close = opening + profit + contributions - distributions + signed_transfers + other_identified_movements.
- Reconcile component closings to ledger and selected financial-statement version, retaining source movement references.
- Check structured share/dividend actions link to supplied resolutions/register/payment support
-  legal ownership/distributability remains auditor/legal work.

**Required output**

An equity-component bridge and unsupported or unreconciled movement cases with linked evidence.

**Human responsibility**

Classify equity movements, assess the legal validity and timing of authorizations, approve evidence and determine presentation and disclosure consequences.

**Method boundary**

The baseline does not interpret company law, validate legal ownership, account for complex equity instruments or determine whether a dividend was legally distributable.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.21, card 39; F00011 matching card 39; F00009/F00012 catalogue entry 39

### AUTO-040 — Investment holdings, income and valuation-input review

**Primary package** R16. **Current evidence** partial-evidence. **Cases** P09-UC02, P09-UC11.

**Source minimum** Roll investment units and cost, reconcile positions and income with custodian and ledger records, and test simple yield inputs without concluding fair value.

**Inputs** Required: instrument identifier, opening holdings and cost, purchases, disposals, closing position, income, custodian statement and mapped ledger balances. Yield testing requires approved cash flows and rate.

**Source method**

- expected_units = opening_units + acquired_units - disposed_units + signed_other_unit_movements
-  keep cost movement basis separate.
- Exact-match structured custody position/income and ledger totals at approved instrument/date/currency grain.
- For the selected simple supported profile, present_value = sum(approved_cash_flow_t / (1 + compatible_rate)^t). Unsupported complex valuation or fair-value judgment is not computed.

**Required output**

A holdings and income bridge, position differences, simple yield variance and stale or missing input cases.

**Human responsibility**

Confirm instrument classification and authoritative evidence, assess valuation techniques and assumptions, investigate differences and make recognition and fair-value conclusions.

**Method boundary**

The baseline excludes market-data retrieval, complex valuation models, expected credit loss, hierarchy classification and any automatic fair-value conclusion.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.21, card 40; F00011 matching card 40; F00009/F00012 catalogue entry 40

### AUTO-041 — Connected-party and related-party review

**Primary package** R16. **Current evidence** partial-evidence. **Cases** P09-UC09, P09-UC11.

**Source minimum** Match the declared related-party register to transaction counterparties and reconcile known related-party balances and transactions with draft disclosures.

**Inputs** Required: approved related-party register, counterparty masters, registration or bank identifiers, transaction and balance populations, and structured disclosure totals.

**Source method**

- Exact-match approved related-party register to customer/supplier IDs, keeping unmatched declared parties and ambiguous matches.
- Flag shared supplied registration/account identifiers with declared parties/employees/owners as candidates
-  retain matching basis and source.
- Aggregate known transactions/balances once per source item and compare structured disclosure totals. Candidate links do not prove the relationship or completeness.

**Required output**

A relationship candidate list and party-level balance, transaction and disclosure reconciliation.

**Human responsibility**

Assess relationship completeness, substance and terms, investigate candidates, approve party mappings and conclude on accounting and disclosure adequacy.

**Method boundary**

The baseline does not establish beneficial ownership, search external networks, interpret unusual commercial terms or conclude that a common identifier proves a relationship.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.22, card 41; F00011 matching card 41; F00009/F00012 catalogue entry 41

### AUTO-042 — Estimate, allowance and impairment review

**Primary package** R16. **Current evidence** partial-evidence. **Cases** P09-UC06, P09-UC11.

**Source minimum** Recalculate a selected structured estimate schedule and identify differences or assumption changes that require auditor evaluation.

**Inputs** Required: estimate identifier, opening and movement schedule, closing ledger balance, method selection and approved assumptions. Aging profiles also require exposure buckets and rates.

**Source method**

- expected_close = opening + additions - use - releases + signed_other_approved_movements under the estimate's sign convention.
- For the supported aging-rate profile, expected_allowance = sum(eligible_exposure_bucket * approved_bucket_rate) after confirming disjoint population buckets.
- Retain changed assumptions, management overrides and incomplete inputs for review
-  no unsupported ECL/model/impairment judgment is generated.

**Required output**

A schedule or allowance recalculation, ledger variance and assumption or override case list.

**Human responsibility**

Select an appropriate method, assess data and assumptions, challenge bias and overlays, obtain specialist input where needed and make the recognition or impairment conclusion.

**Method boundary**

The baseline does not validate model design, generate assumptions, forecast economic variables, calculate unsupported complex ECL models or conclude impairment automatically.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.22, card 42; F00011 matching card 42; F00009/F00012 catalogue entry 42

### AUTO-043 — Consolidation and intercompany review

**Primary package** R16. **Current evidence** unverified. **Cases** P09-UC10, P09-UC11.

**Source minimum** Reconcile approved component trial balances to consolidation inputs, sum mapped balances and identify unmatched exact intercompany balances and elimination residuals.

**Inputs** Required: approved component trial balances, consolidation inputs, entity and counterparty identifiers, mapping, intercompany balances, supplied eliminations and recorded consolidated totals.

**Source method**

- Compare each component final TB with imported consolidation values and approved mapping
-  no foreign-operation translation is inferred.
- Pair reciprocal intercompany balances by approved entity-pair/account/currency/reference grain
-  reciprocal_residual = receivable_plus_corresponding_payable under normalised signed convention.
- expected_consolidated = sum(approved_component_amounts) + signed_supplied_eliminations. Show import/match/elimination residuals without creating automatic eliminations.

**Required output**

A component bridge, intercompany balance cases and consolidated summation or elimination residuals.

**Human responsibility**

Confirm group scope, mappings, ownership and currency treatment, investigate unmatched items and approve consolidation and elimination judgments.

**Method boundary**

The baseline excludes foreign-operation translation, complex ownership changes, intercompany transaction matching, tax effects and automatic creation of elimination journals.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.23, card 43; F00011 matching card 43; F00009/F00012 catalogue entry 43

### AUTO-044 — Going-concern financial indicators

**Primary package** R17. **Current evidence** unverified. **Cases** P09-UC08, P09-UC11.

**Source minimum** Calculate a controlled set of liquidity, maturity, covenant-headroom and cash-runway indicators for use in the auditor's going-concern assessment.

**Inputs** Required: reporting-date cash, current assets and liabilities, debt maturities, approved facilities, covenant results and management cash-flow forecast.

**Source method**

- Compute only approved ratios, e.g. current_ratio = current_assets / current_liabilities with a valid nonzero denominator and agreed sign basis.
- liquidity_headroom = available_cash + approved_available_facilities - scoped_due_obligations
-  assess restrictions on availability from supplied facts.
- Cash runway is the first period in the supplied cumulative forecast with cash below the approved floor, or beyond-forecast/not-evaluable. Indicators do not decide going concern.

**Required output**

An indicator pack showing liquidity, maturity concentrations, covenant headroom, cash runway and incomplete calculations.

**Human responsibility**

Select appropriate indicators and forecast period, test source assumptions and mitigating actions, assess feasibility and make the going-concern and reporting conclusions.

**Method boundary**

The baseline does not validate management's forecast, estimate financing availability, model unrestricted scenarios or determine material uncertainty or report wording.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.23, card 44; F00011 matching card 44; F00009/F00012 catalogue entry 44

### AUTO-045 — Subsequent-event transaction review

**Primary package** R17. **Current evidence** unverified. **Cases** P09-UC07, P09-UC11.

**Source minimum** Identify material post-period transactions and exact links to year-end balances so the auditor can investigate possible subsequent events once.

**Inputs** Required: reporting date, review end date, post-period transaction identifier, type, date, amount, counterparty and year-end source reference where available.

**Source method**

- Select post-period transactions satisfying reporting_date < transaction_date <= approved_review_end and the approved type/amount criteria.
- Exact-match year-end source references where supplied
-  retain unmatched and ambiguous cases without semantic inference.
- Deduplicate repeated appearances by verified economic-event identity, preserving source rows and all triggers. Auditor determines event treatment.

**Required output**

One post-period event case set with linked year-end records, trigger reason and unresolved status.

**Human responsibility**

Define the review window and thresholds, investigate the underlying event and conditions, and decide adjusting, non-adjusting, disclosure and reporting treatment.

**Method boundary**

The baseline does not search news or legal sources, infer event meaning from narrative documents or make the adjusting versus non-adjusting conclusion.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.24, card 45; F00011 matching card 45; F00009/F00012 catalogue entry 45

### AUTO-046 — Materiality management

**Primary package** R12. **Current evidence** partial-evidence. **Cases** P06-UC03, P06-UC05.

**Source minimum** Calculate and preserve approved overall, performance and clearly-trivial materiality amounts from auditor-selected benchmarks and percentages.

**Inputs** Required: benchmark type and amount, overall and performance percentages, clearly-trivial basis, reporting period, rationale and required approval.

**Source method**

- Calculate and retain the benchmark-derived candidate overall amount and any candidate dependent thresholds under explicitly declared bases.
- Record the human-selected overall/specific/performance/trivial determinations and rationale separately. If the selected method bases dependent thresholds on selected overall, recompute from that selected amount; do not leave stale candidate-dependent values as current selections.
- Compare old/new selected amounts and identify affected work for targeted assessment. No percentage/benchmark/base or sampling redesign is a universal default.

**Required output**

An approved materiality record containing calculated and overridden thresholds, rationale and revision comparison.

**Human responsibility**

Select and justify the benchmark and percentages, approve overrides, consider qualitative materiality and decide which audit work must change after revision.

**Method boundary**

The baseline does not select benchmarks, prescribe firm methodology, evaluate qualitative materiality or automatically redesign sampling and audit procedures.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.24, card 46; F00011 matching card 46; F00009/F00012 catalogue entry 46

### AUTO-047 — Audit sampling workspace

**Primary package** R15. **Current evidence** partial-evidence. **Cases** P07-UC02, P07-UC03.

**Source minimum** Draw a reproducible simple random sample from a reconciled population and evaluate recorded monetary errors under one approved projection method.

**Inputs** Required: reconciled population with stable item identifiers and amounts, eligibility rules, approved sample size, random seed and tested error for selected items.

**Source method**

- Validate reconciled population N and approved integer sample size 0 < n <= N
-  retain stable ordered IDs and exclusions.
- Use a named/versioned uniform no-replacement procedure (e.g. Fisher-Yates with unbiased integer draws), retained PRNG/seed and ordering
-  same bindings must reproduce the selection.
- For approved simple ratio projection, projected_population_error = sample_error / sample_book_amount * population_book_amount. Nonpositive/invalid denominator, mixed-sign unsupported units or untested selected units require explicit limitation, not clean projection.
- The eligible population amount in an inclusive ratio projection includes the tested sample units. Add known full-tested errors outside that eligible population once; do not add observed sampled error again. Stratified and monetary-unit methods are outside this minimum.

**Required output**

A population basis, reproducible selection list, recorded test results and simple projected misstatement.

**Human responsibility**

Define the population and sampling unit, determine whether the method and sample size are appropriate, perform audit testing and evaluate qualitative and sampling risk.

**Method boundary**

The baseline does not calculate statistical confidence, select an audit methodology, support monetary-unit or stratified sampling, or replace auditor evaluation of results.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.25, card 47; F00011 matching card 47; F00009/F00012 catalogue entry 47

### AUTO-048 — Misstatement management and evaluation

**Primary package** R18. **Current evidence** partial-evidence. **Cases** P10-UC02, P10-UC03.

**Source minimum** Maintain one controlled record for each confirmed misstatement, track correction status and aggregate recorded effects against approved materiality.

**Inputs** Required: source case, affected account and statement line, amount, period, classification, correction status and active materiality version.

**Source method**

- Create one canonical confirmed misstatement per verified source issue
-  separate distinct issues even if amounts match.
- Retain factual/projected/tax/prior-period inclusion basis and corrected/unadjusted status. An inclusive projected amount is not added again to its embedded factual errors.
- Aggregate on approved nonduplicating bases by period/currency/classification and compare approved materiality. Qualitative evaluation and opinion selection remain human.

**Required output**

A canonical misstatement register, correction summary and aggregate comparison with materiality.

**Human responsibility**

Confirm whether an exception is a misstatement, determine measurement and classification, verify management's correction and make quantitative and qualitative aggregate conclusions.

**Method boundary**

The baseline does not infer misstatements from exceptions, verify final-ledger posting automatically, determine qualitative materiality or select an audit opinion.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.25, card 48; F00011 matching card 48; F00009/F00012 catalogue entry 48

### AUTO-049 — Legal matters, commitments and contingencies

**Primary package** R17. **Current evidence** unverified. **Cases** P09-UC09, P09-UC11.

**Source minimum** Maintain a complete, reviewed register of identified legal matters, commitments and contingencies with supporting evidence and accounting or disclosure disposition.

**Inputs** Required: matter identifier, type, status, relevant dates, management assessment, linked evidence, proposed accounting or disclosure treatment and reviewer assignment.

**Source method**

- Maintain one identified matter with source/support and explicitly known/unknown exposure/status
-  completeness is assessed, not inferred from register presence.
- Require supported accounting/disclosure disposition and assigned auditor/reviewer for every applicable active matter.
- Flag missing support, overdue update and unresolved disposition. Do not predict legal outcomes, measure provisions or decide recognition autonomously.

**Required output**

A matter register and completion view showing current evidence, disposition, reviewer status and unresolved matters.

**Human responsibility**

Identify matters, assess completeness and legal evidence, obtain specialist or counsel input, evaluate recognition and disclosure, and make the audit conclusion.

**Method boundary**

The baseline does not discover undeclared matters, interpret legal outcomes, estimate provisions or determine recognition and disclosure automatically.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.26, card 49; F00011 matching card 49; F00009/F00012 catalogue entry 49

### AUTO-050 — Going-concern evidence and conclusion

**Primary package** R17. **Current evidence** unverified. **Cases** P09-UC08, P09-UC11.

**Source minimum** Provide a controlled workflow linking identified going-concern conditions, management's assessment, supporting evidence, mitigating actions and the auditor's reviewed conclusion.

**Inputs** Required: management assessment, identified conditions, forecast evidence, mitigating actions, auditor evaluation, disclosure decision, reporting decision and assigned approvals.

**Source method**

- Link each identified condition and mitigation to exact source versions, responsible owner, timing and status.
- Require auditor challenge/evaluation, uncertainty/conclusion and disclosure/reporting decisions with the required review.
- Flag missing support and structured contradictions. No automatic assertion that financing is feasible or that forecast arithmetic proves going concern.

**Required output**

An evidence-to-conclusion matrix with unresolved conditions, review status and the approved auditor-owned conclusion.

**Human responsibility**

Challenge forecasts and mitigating actions, assess evidence and material uncertainty, determine disclosure adequacy and select the appropriate audit-report treatment.

**Method boundary**

The baseline does not validate forecasts, prove financing feasibility, choose the going-concern conclusion or generate the audit opinion and wording.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.26, card 50; F00011 matching card 50; F00009/F00012 catalogue entry 50

### AUTO-051 — Subsequent-event inquiry and completion

**Primary package** R17. **Current evidence** partial-evidence. **Cases** P09-UC07, P10-UC08.

**Source minimum** Document that required subsequent-event inquiries and source reviews were completed through the intended auditor's-report date and every identified event was resolved.

**Inputs** Required: reporting and intended report dates, applicable inquiry or source-review list, completion evidence, identified event details, treatment decision and reviewer assignment.

**Source method**

- Track required inquiries/source reviews with performer, completed date and explicit coverage end through intended report date.
- Maintain each event with facts, adjusting/nonadjusting assessment, disclosure/report effect and review.
- Required missing/stale/unresolved work blocks the corresponding completion. Earlier procedure performance date alone is not proof of coverage to the final date.

**Required output**

A dated completion checklist and event register showing treatment, evidence, review and unresolved items.

**Human responsibility**

Perform inquiries and document review, identify relevant events, evaluate conditions at the reporting date and conclude on adjustment, disclosure and report implications.

**Method boundary**

The baseline does not search transactions or external news, decide event treatment automatically or prove that inquiry procedures identified every possible event.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.27, card 51; F00011 matching card 51; F00009/F00012 catalogue entry 51

### AUTO-052 — Disclosure applicability and completion

**Primary package** R18. **Current evidence** unverified. **Cases** P10-UC04.

**Source minimum** Show that each auditor-selected applicable disclosure requirement is linked to a completed note and supporting evidence or to an approved non-applicability rationale.

**Inputs** Required: controlled disclosure checklist version, entity and reporting-framework context, applicability decision, exact note reference, evidence link and required review.

**Source method**

- Instantiate a controlled disclosure checklist for selected framework/edition/period
-  auditor selects applicability with rationale.
- For applicable items require exact selected note/version anchor, support and required preparer/reviewer disposition.
- Flag missing note/support/review or unsupported N/A. Completed checklist does not establish full semantic compliance or fair presentation.

**Required output**

An applicable-disclosure checklist and missing-note, support or approval register.

**Human responsibility**

Determine applicability and adequacy, interpret the reporting framework, prepare or audit the disclosure and approve justified non-applicability conclusions.

**Method boundary**

The baseline does not infer applicability from transactions, read narrative notes for semantic compliance or conclude that a completed checklist proves fair presentation.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.27, card 52; F00011 matching card 52; F00009/F00012 catalogue entry 52

### AUTO-053 — Audit-area completion and conclusion

**Primary package** R18. **Current evidence** unverified. **Cases** P09-UC11.

**Source minimum** Prevent an audit area from being completed until applicable procedures, evidence, exceptions and required reviews are resolved or formally approved as not performed.

**Inputs** Required: area scope, applicable procedure list, procedure statuses, evidence and exception links, required roles, sign-offs and auditor conclusion.

**Source method**

- For each applicable procedure require actual result/support or an authorised justified non-performance disposition and alternatives as applicable.
- Expose unresolved exceptions, notes, stale work and missing required reviews as area-specific blockers.
- After supported resolution an authorised auditor records area conclusion. No machine status chooses evidence sufficiency or automatically waives work.

**Required output**

An area-completion dashboard, explicit blocker list and approved auditor-owned conclusion record.

**Human responsibility**

Determine procedure applicability and sufficiency, evaluate evidence and exceptions, resolve blockers and own the professional conclusion for the audit area.

**Method boundary**

The baseline does not determine whether evidence is sufficient, choose the conclusion, infer an audit opinion or automatically waive incomplete procedures.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.28, card 53; F00011 matching card 53; F00009/F00012 catalogue entry 53

### AUTO-054 — Risk-response linkage and change-impact control

**Primary package** R19. **Current evidence** unverified. **Cases** P06-UC02, P11-UC07.

**Source minimum** Maintain traceable links from assessed risks through audit responses, procedures, evidence and conclusions and identify work affected by approved changes.

**Inputs** Required: stable risk, response, procedure, evidence and conclusion identifiers; status and approval; and recorded change events.

**Source method**

- Validate risk-response links and applicable response-to-procedure links. Overall staffing/supervision responses can instead link resources/arrangements
-  source executable-procedure wording is narrowed by response kind.
- Flag orphan required links under the approved risk/response scope
-  keep many-to-many links and contextual optionality.
- On approved change mark directly dependent work for reassessment with actor/owner and rationale. Do not infer every indirect impact or automatically redesign procedures.

**Required output**

A risk-response coverage view and affected-work register showing broken links and reassessment status.

**Human responsibility**

Assess risks, design and approve responses, decide the actual impact of changes and reperform or reapprove work where necessary.

**Method boundary**

The baseline does not assess risks automatically, redesign audit procedures, infer every indirect dependency or decide that prior evidence remains sufficient after change.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.28, card 54; F00011 matching card 54; F00009/F00012 catalogue entry 54

### AUTO-055 — Exception, review-note and sign-off closure

**Primary package** R19. **Current evidence** partial-evidence. **Cases** P11-UC01, P11-UC02.

**Source minimum** Provide one controlled queue for unresolved exceptions, review notes and required sign-offs and prevent engagement completion while mandatory items remain open.

**Inputs** Required: source work item, exception or note, owner, required approver roles, status, resolution evidence and completion-gate configuration.

**Source method**

- Register each closure item once with source, owner, status and support. A reply or task close is not reviewer clearance.
- Evaluate configured preparer/reviewer/partner requirements against exact targets and eligible capacities
-  keep rejected/withdrawn/reopened states.
- Expose relevant engagement blockers and preserve resolution/reopening history. Optional consolidation of queues is not a substitute for judgments.

**Required output**

A consolidated closure queue and completion-blocker report with ownership, aging and resolution history.

**Human responsibility**

Investigate and resolve exceptions, clear review notes, provide required evidence and exercise the authority to approve, reject or reopen work.

**Method boundary**

The baseline does not resolve findings automatically, determine evidence sufficiency, infer role conflicts beyond configured rules or substitute closure status for audit judgment.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.29, card 55; F00011 matching card 55; F00009/F00012 catalogue entry 55

### AUTO-056 — Final statements, conclusions and report consistency

**Primary package** R18. **Current evidence** unverified. **Cases** P10-UC06, P10-UC07.

**Source minimum** Bind the proposed auditor's report to exact approved financial-statement and audit-conclusion versions and expose structured contradictions for partner resolution.

**Inputs** Required: exact financial-statement version, approved area and engagement conclusions, structured report decisions, report draft version and required technical or partner review.

**Source method**

- Bind exact statement/conclusion versions and approved structured reporting decisions to the draft report.
- Apply the approved decision-table combinations for opinion/basis/going-concern/section states
-  missing or incompatible states yield unresolved contradictions.
- Require authorised technical/partner resolution and retain rationale/version. Structural consistency is not semantic/legal approval of report wording.

**Required output**

A report-consistency checklist with linked source versions, contradictions, resolutions and final approval status.

**Human responsibility**

Evaluate the audit evidence, select the opinion and report sections, determine legally and methodologically appropriate wording and approve the final report.

**Method boundary**

The baseline does not select an opinion, draft unrestricted report wording, perform semantic legal review or conclude that structural consistency establishes reporting appropriateness.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.29, card 56; F00011 matching card 56; F00009/F00012 catalogue entry 56

### AUTO-057 — Report approval, issuance and distribution

**Primary package** R20. **Current evidence** partial-evidence. **Cases** P10-UC08.

**Source minimum** Issue only the exact auditor's-report version approved by an authorized partner and preserve an immutable record of what was issued, when and to whom.

**Inputs** Required: final report and statement versions, authorized partner identity and approval, intended issue date, approved recipient list and engagement issuance status.

**Source method**

- Validate exact approved report/full-statement package bindings, actual authorization and permitted issuer/recipient scope.
- Retain package authorization separately from the actual defined issue event/time. An identical operation identity with identical bound payload returns the same outcome; reuse with changed payload is rejected. Unknown external outcomes are reconciled before retry.
- Record actual per-recipient distribution/replacement/withdrawal attempts and outcomes separately from authorization/issue. No signing, receipt, filing or legal-validity service is established by this specification.

**Required output**

An immutable issued-report record, exact approval evidence and recipient-level distribution log.

**Human responsibility**

Confirm authorization to issue, approve the final report and recipients, comply with legal delivery requirements and authorize any withdrawal or replacement.

**Method boundary**

The baseline does not provide regulated electronic signatures, file directly with authorities, prove external receipt or determine whether legal issuance conditions have been satisfied.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.30, card 57; F00011 matching card 57; F00009/F00012 catalogue entry 57

### AUTO-058 — Engagement-file lock, retention and amendments

**Primary package** R21. **Current evidence** partial-evidence. **Cases** P12-UC02.

**Source minimum** Lock the completed engagement file against ordinary editing, calculate its retention date and preserve every authorized post-lock amendment and re-lock event.

**Inputs** Required: engagement file index and versions, completion-gate status, authorized locking role, retention-policy version and any amendment request and approval.

**Source method**

- Lock only the exact manifest/payload after configured completion conditions are evaluated
-  preserve assembly and lock events separately.
- Calculate retention only under an approved applicable policy/anchor. Do not implement ten-year law as a guessed clock anchor, and check holds before disposal.
- Restrict ordinary editing
-  authorised amendments retain old/new content, reason, affected review and re-lock. Write-once infrastructure and cross-repository disposal are not assumed.
- Hold management is excluded from this automation minimum. The separate M12-F08 requirement still requires hold eligibility before disposition; D19 records this boundary. Calendar-year arithmetic needs an explicit leap-day rule where applicable; an undefined anchor/calendar rule stays not evaluable.

**Required output**

A lock and archive status record, retention schedule and immutable amendment history.

**Human responsibility**

Confirm completion, approve lock or reopening, select the applicable retention rule, assess affected audit work and authorize lawful amendment or disposal.

**Method boundary**

The baseline does not provide write-once storage, manage legal holds, determine jurisdictional retention law or automate defensible disposal across external repositories.

**Closure work** Inspect the current run against this minimum, complete any uncovered required behavior, exercise missing/invalid/stale inputs and a meaningful exception with independent expectations, record the reviewer decision and demonstrate the result in the owning paper and downstream workflow. Retain exact inputs/method versions and relevant safe retry evidence.

**Source locator** F00010 p.30, card 58; F00011 matching card 58; F00009/F00012 catalogue entry 58

## Fieldwork variants

Each of the 22 variants requires a substantive area journey under R16. Every row currently has unverified full variant-level evidence. Related calculations may already work in broader tests.

| Variant | Area | Remaining procedure coverage | Source input requirements | Source limitation |
| --- | --- | --- | --- | --- |
| P09-UC02-V01 | Intangible assets | Inspect rights, recognition/capitalisation, source costs and the supported useful-life/amortisation basis, including unsupported expenditure. | Intangible register and movement list; license/development contracts; costs; approved useful-life/method basis | No automatic recognition decision from a cost label or a successful amortization calculation. |
| P09-UC02-V02 | Property, plant and equipment | Extend asset movements/addition evidence into the applicable useful-life, depreciation, disposal and impairment procedures and reviewed exceptions. | Asset register; addition/disposal records; physical inspection record; cost and depreciation assumptions | A disposal/fully-depreciated flag is a candidate; impairment and lease conclusions require their actual supported work. |
| P09-UC02-V03 | Investments | Tie holdings/rights, transactions, income and valuation inputs to accepted evidence and the supported measurement basis. | Investment register; contracts and ownership/decision rights; investee/custodian information; selected valuation inputs | Do not hard-code the source form's percentage shortcuts or its joint-arrangement wording as accounting conclusions. |
| P09-UC02-V04 | Inventory values and movements | Complete item/location/unit movements, count/cutoff, costing and NRV indicators with unresolved quantity/value differences. | Item/location movement records; count link; cost method; sales/condition evidence; period boundaries | Attendance itself is P09-UC05. Aging or a computed shortfall alone does not decide an inventory write-down. |
| P09-UC02-V05 | Trade receivables | Complete balance/aging, confirmations, credit notes, subsequent receipts and supported allowance/conclusion cases. | Receivable/sales detail; contracts, invoices and delivery records; subsequent cash; aging/allowance support | A nonresponse is not agreement. An aging calculation is not an automatic allowance conclusion. |
| P09-UC02-V06 | Other long-term receivables | Complete long-term rights, terms, maturity, recoverability and applicable discounting/classification with reviewed assumptions. | Receivable agreement; repayment/interest terms; balance/movement detail; support and security where relevant | Complex measurement remains manual/specialist work where the selected automation does not support it. |
| P09-UC02-V07 | Other receivables and prepayments | Complete nature/rights, advances/prepayments, period allocation, settlement and unsupported or overdue items. | Advance/prepayment detail; contracts/invoices; payment and settlement evidence; covered service period | A paid invoice does not alone establish that a prepayment was consumed in this period. |
| P09-UC02-V08 | Cash and cash equivalents | Complete bank/cash source integrity, confirmations, reconciliation, transfers and unresolved movement/reconciling items. | Bank/cash listing; statements; reconciliation; relevant agreements; count/confirmation work when selected | The system records actual count/confirmation work; importing a bank statement does not automatically confirm every bank relationship. |
| P09-UC02-V09 | Borrowings | Complete debt completeness/terms, principal and interest, covenant inputs, classification and breach/unsupported cases. | Loan agreements; drawdowns/repayments; lender records; rate/day-count terms; collateral/covenant information | A simple interest calculation does not implement every effective-interest, modification or guarantee treatment. |
| P09-UC02-V10 | Purchases and trade payables | Complete supplier/payee checks, purchase/receipt/invoice/payment links, cutoff and unrecorded liabilities. | Supplier balances; purchase orders/invoices/receipts; payments; contracts; post-period items | Repeated document headers and one-to-many lines need the actual grain; no automatic exposure multiplication. |
| P09-UC02-V11 | Other payables and accruals | Complete accrual support, estimates, settlement, completeness and period allocation with unsupported balances. | Accrual/other-payable detail; agreements; service evidence; calculation basis; subsequent invoices/payments | A later invoice amount is not automatically the correct earlier accrual without its service/period basis. |
| P09-UC02-V12 | Deferred income | Complete contract obligations, opening/movement schedules, release to income and period classification with exceptions. | Customer contracts; receipt/invoice detail; delivery/service evidence; deferred-income roll-forward | Invoice/payment date alone does not determine revenue recognition; no automatic all-contract accounting engine is implied. |
| P09-UC02-V13 | Intercompany transactions | Complete connected-party identity, reciprocal balances/transactions, supplied elimination evidence and unresolved differences. | Declared related parties; intercompany agreements; reciprocal balance/transaction records; settlement and relevant group data | A shared identifier is a lead, not proof of control. Intercompany reconciliation does not by itself perform a group audit. |
| P09-UC02-V14 | Tax balances and expense | Complete approved-edition returns/schedules, current/deferred tax inputs, payments and reconciliation with unsupported-rule handling. | Returns; tax-ledger detail; taxable bases/adjustments; applicable approved rate/rule version; payments | Illustrative tax rates are not Mongolian law. A tax tie-out does not establish compliance with every tax rule. |
| P09-UC02-V15 | Capital, reserves and dividends | Complete authorised capital/reserve/dividend movements, records, payments and presentation with missing-authorisation cases. | Equity register/ledger; shareholder and issue records; resolutions; dividend/tax support; applicable disclosure basis | A resolution is evidence to evaluate, not a software permission or universal EPS requirement. |
| P09-UC02-V16 | Revenue | Complete revenue population/cutoff/credits, pricing and source-required recognition schedules with supported conclusions. | Sales detail; contract/pricing terms; invoices; delivery/service acceptance; returns and subsequent cash | Cut-off flags identify candidates; software does not automatically select the applicable recognition conclusion. |
| P09-UC02-V17 | Cost of sales | Complete inventory/purchase/cost schedules and ledger links, costing/period allocation and abnormal/unexplained differences. | Inventory/cost-of-sales records; cost-method basis; selected receipts/issues; related sales and stock support | The source programme repeats inventory procedures; tailor them rather than assuming the same work proves every assertion. |
| P09-UC02-V18 | Payroll and employee benefits | Complete employee/population integrity, approved-rule gross-to-net, disbursement, statutory and off-cycle/variance cases. | Payroll register; employee/contract data; attendance; bank payment; applicable deduction/tax rule version; benefit support | A repeated bank account or unusual payment is a candidate, not proof of a ghost employee or fraud. |
| P09-UC02-V19 | Selling and operating expenses | Complete source-supported expense nature, occurrence, period allocation, analytical changes and exceptions. | Expense ledger; contracts/invoices; payment and service/delivery evidence; period/cost-center basis | A management explanation or payment alone does not establish the full audit conclusion. |
| P09-UC02-V20 | Other income-statement or comprehensive-income items | Determine applicable source items, classification/measurement and evidence, including OCI and unsupported mapping where relevant. | Relevant transactions/ledger; valuation or FX support; classification/presentation basis; related asset/liability evidence | Do not classify every exchange difference or revaluation automatically as OCI; framework-specific professional evaluation remains required. |
| P09-UC02-V21 | Finance costs | Complete borrowing/lease finance-cost inputs, effective methods where required, period allocation and ledger reconciliation. | Loan/bond/lease terms; rate/period/day-count inputs; fee schedules; payments; capitalized-cost support | No universal straight-line, simple-interest or capitalization rule is inferred from a successful calculation. |
| P09-UC02-V22 | Other income and expenses | Complete source-supported other income/expense nature, evidence, classification, period and unusual-item investigation. | Underlying agreement/notice; transaction detail; receipts/payments; relevant conditions and period | A transaction description or recurring ledger account is not a sufficient recognition/classification conclusion. |

## All 70 form fidelity records

R07 owns per-form fidelity, R08 authoring and adoption, and R09 linked facts/dependencies. Stage counts are 11, 16, 31, 11 and one. For each form, inspect meaningful fields, repeatable rows, operative calculations, validation, applicability, save/reload, exact-version review, change impact and readable output against the named companion sheet. Numerical order does not establish the workflow sequence.

| Form | Stage | Source sheet | Title | Declared field groups | Current evidence |
| --- | --- | --- | --- | --- | --- |
| 1.1.1 | 1 | Audit_Stage_1_Repaired.xlsx / 1.1.1А | Санхүүгийн тайлангийн аудитын хамрах хүрээг тодорхойлох асуулга | 13 | unverified |
| 1.1.2 | 1 | Audit_Stage_1_Repaired.xlsx / 1.1.2А | Гэрээт ажлын хамрах хүрээг төлөвлөх | 9 | unverified |
| 1.3 | 1 | Audit_Stage_1_Repaired.xlsx / 1.3А | Материаллаг байдлын түвшинг тодорхойлох | 14 | unverified |
| 1.4.1 | 1 | Audit_Stage_1_Repaired.xlsx / 1.4.1А | Шинэ үйлчлүүлэгч хүлээн зөвшөөрөх | 26 | unverified |
| 1.4.2 | 1 | Audit_Stage_1_Repaired.xlsx / 1.4.2А | Хуучин үйлчлүүлэгч үргэлжлүүлэн хүлээн зөвшөөрөх | 47 | unverified |
| 1.4.3 | 1 | Audit_Stage_1_Repaired.xlsx / 1.4.3 А | Аудитын гэрээт ажлын захидал | 16 | unverified |
| 1.4.4 | 1 | Audit_Stage_1_Repaired.xlsx / 1.4.4A | Гэрээт ажлын багийн томилгоо | 12 | unverified |
| 1.4.5 | 1 | Audit_Stage_1_Repaired.xlsx / 1.4.5А | Хараат бус байдлыг тодорхойлох асуулга | 13 | unverified |
| 1.4.6 | 1 | Audit_Stage_1_Repaired.xlsx / 1.4.6А | Хараат бус байдлын мэдэгдэл - Аудитын баг | 1 | unverified |
| 1.4.7 | 1 | Audit_Stage_1_Repaired.xlsx / 1.4.7А | Хараат бус байдлын мэдэгдэл - Эксперт болон бусад этгээд | 19 | unverified |
| 1.5 | 1 | Audit_Stage_1_Repaired.xlsx / 1.5.А | Төлөвлөлтийн уулзалтын тэмдэглэл | 11 | unverified |
| 2.1.1 | 2 | Audit_Stage_2_Repaired.xlsx / 2.1.1А | Байгууллага, түүний орчны талаар ойлголт олж авах | 44 | unverified |
| 2.1.2 | 2 | Audit_Stage_2_Repaired.xlsx / 2.1.2А | Санхүүгийн тайлагналын тогтолцооны талаар ойлголт олж авах | 16 | unverified |
| 2.1.3 | 2 | Audit_Stage_2_Repaired.xlsx / 2.1.3А | Дотоод хяналтын системийн талаар ойлголт олж авах | 32 | unverified |
| 2.1.4 | 2 | Audit_Stage_2_Repaired.xlsx / 2.1.4А | Мэдээллийн системийн орчны талаар ойлголт олж авах | 8 | unverified |
| 2.1.5 | 2 | Audit_Stage_2_Repaired.xlsx / 2.1.5А | Залилангийн эрсдэлийн талаар ойлголт авах, үнэлэх асуулга | 52 | unverified |
| 2.2.1 | 2 | Audit_Stage_2_Repaired.xlsx / 2.2.1А | Дотоод аудитын ажлыг үнэлэх асуулга | 17 | unverified |
| 2.2.2 | 2 | Audit_Stage_2_Repaired.xlsx / 2.2.2А | Эксперт болон бусад шинжээчийн ажлыг ашиглах | 19 | unverified |
| 2.3 | 2 | Audit_Stage_2_Repaired.xlsx / 2.3А | Урьдчилсан шинжилгээний горим | 33 | unverified |
| 2.4 | 2 | Audit_Stage_2_Repaired.xlsx / 2.4А | Эхний үлдэгдлийг баталгаажуулах | 7 | unverified |
| 2.5 | 2 | Audit_Stage_2_Repaired.xlsx / 2.5А | Гол циклүүдийн талаар ойлголт олж авах | 10 | unverified |
| 2.6 | 2 | Audit_Stage_2_Repaired.xlsx / 2.6А | Нөлөө бүхий эрсдэлийн үнэлгээ | 15 | unverified |
| 2.7.1 | 2 | Audit_Stage_2_Repaired.xlsx / 2.7.1А | Аудитын стратеги - ҮЛДЭГДЭЛ БАЛАНС | 17 | unverified |
| 2.7.2 | 2 | Audit_Stage_2_Repaired.xlsx / 2.7.2А | Аудитын стратеги - ОРЛОГО, ҮР ДҮНГИЙН ТАЙЛАН | 17 | unverified |
| 2.8 | 2 | Audit_Stage_2_Repaired.xlsx / 2.8.А | Аудитын төлөвлөгөө | 77 | unverified |
| 2.9 | 2 | Audit_Stage_2_Repaired.xlsx / 2.9А | Засаглах эрх бүхий этгээдтэй харилцах | 29 | unverified |
| 2.10 | 2 | Audit_Stage_2_Repaired.xlsx / 2.10А | Нягтлан бодох бүртгэлийн тооцооллын эрсдэлийн үнэлгээ | 18 | unverified |
| 3.1.1 | 3 | Audit_Stage_3_Repaired.xlsx / 3.1.1А | Биет бус хөрөнгийн аудитын хөтөлбөр | 15 | unverified |
| 3.1.2 | 3 | Audit_Stage_3_Repaired.xlsx / 3.1.2А | Үндсэн хөрөнгийн аудитын хөтөлбөр | 20 | unverified |
| 3.1.3 | 3 | Audit_Stage_3_Repaired.xlsx / 3.1.3А | Хөрөнгө оруулалтын аудитын хөтөлбөр | 14 | unverified |
| 3.1.4 | 3 | Audit_Stage_3_Repaired.xlsx / 3.1.4А | Бараа материалын аудитын хөтөлбөр | 18 | unverified |
| 3.1.5 | 3 | Audit_Stage_3_Repaired.xlsx / 3.1.5А | Авлагын аудитын хөтөлбөр | 16 | unverified |
| 3.1.6 | 3 | Audit_Stage_3_Repaired.xlsx / 3.1.6А | Бусад урт хугацаат авлагын аудитын хөтөлбөр | 13 | unverified |
| 3.1.7 | 3 | Audit_Stage_3_Repaired.xlsx / 3.1.7А | Бусад авлага, урьдчилгаа төлбөрүүдийн аудитын хөтөлбөр | 10 | unverified |
| 3.1.8 | 3 | Audit_Stage_3_Repaired.xlsx / 3.1.8А | Мөнгө, түүнтэй адилтгах хөрөнгийн аудитын хөтөлбөр | 16 | unverified |
| 3.1.9 | 3 | Audit_Stage_3_Repaired.xlsx / 3.1.9А | Зээлийн аудитын хөтөлбөр | 17 | unverified |
| 3.1.10 | 3 | Audit_Stage_3_Repaired.xlsx / 3.1.10А | Худалдан авалт, өглөгийн аудитын хөтөлбөр | 13 | unverified |
| 3.1.11 | 3 | Audit_Stage_3_Repaired.xlsx / 3.1.11А | Бусад өглөг, хуримтлалын аудитын хөтөлбөр | 10 | unverified |
| 3.1.12 | 3 | Audit_Stage_3_Repaired.xlsx / 3.1.12А | Хойшлогдсон орлогын аудитын хөтөлбөр | 10 | unverified |
| 3.1.13 | 3 | Audit_Stage_3_Repaired.xlsx / 3.1.13А | Компани хоорондын ажил гүйлгээний аудитын хөтөлбөр | 9 | unverified |
| 3.1.14 | 3 | Audit_Stage_3_Repaired.xlsx / 3.1.14А | Татварын аудитын хөтөлбөр | 10 | unverified |
| 3.1.15 | 3 | Audit_Stage_3_Repaired.xlsx / 3.1.15А | Хувьцаат капитал ба нөөцүүд, ноогдол ашгийн аудитын хөтөлбөр | 9 | unverified |
| 3.1.16 | 3 | Audit_Stage_3_Repaired.xlsx / 3.1.16А | Борлуулалтын аудитын хөтөлбөр | 16 | unverified |
| 3.1.17 | 3 | Audit_Stage_3_Repaired.xlsx / 3.1.17А | Борлуулалтын өртгийн аудитын хөтөлбөр | 18 | unverified |
| 3.1.18 | 3 | Audit_Stage_3_Repaired.xlsx / 3.1.18А | Цалин хөлс / Ажиллагсдын тэтгэмжийн аудитын хөтөлбөр | 13 | unverified |
| 3.1.19 | 3 | Audit_Stage_3_Repaired.xlsx / 3.1.19А | Борлуулалт, үйл ажиллагааны зардлын аудитын горим | 9 | unverified |
| 3.1.20 | 3 | Audit_Stage_3_Repaired.xlsx / 3.1.20А | Орлогын тайлангийн бусад зүйлсийн аудитын горим | 8 | unverified |
| 3.1.21 | 3 | Audit_Stage_3_Repaired.xlsx / 3.1.21А | Санхүүгийн зардлын аудитын хөтөлбөр | 10 | unverified |
| 3.1.22 | 3 | Audit_Stage_3_Repaired.xlsx / 3.1.22А | Бусад орлого, зарлагын аудитын хөтөлбөр | 8 | unverified |
| 3.1.23 | 3 | Audit_Stage_3_Repaired.xlsx / 3.1.23А | Журналын бичилт ба удирдлагын хяналтыг үл тоомсорлох эрсдэлийн аудитын хөтөлбөр | 23 | unverified |
| 3.2.1 | 3 | Audit_Stage_3_Repaired.xlsx / 3.2.1А | Балансын дараах үйл явдлыг тодорхойлох аудитын хөтөлбөр | 16 | unverified |
| 3.2.2 | 3 | Audit_Stage_3_Repaired.xlsx / 3.2.2А | Тасралтгүй үйл ажиллагааны аудитын хөтөлбөр | 27 | unverified |
| 3.2.3 | 3 | Audit_Stage_3_Repaired.xlsx / 3.2.3А | Болзошгүй өр төлбөрийн аудитын хөтөлбөр | 15 | unverified |
| 3.2.4 | 3 | Audit_Stage_3_Repaired.xlsx / 3.2.4А | Холбоотой талын ажил гүйлгээий аудитын хөтөлбөр | 25 | unverified |
| 3.2.5 | 3 | Audit_Stage_3_Repaired.xlsx / 3.2.5А | Хуульчийн баталгаажуулалтын захидлын загвар | 19 | unverified |
| 3.2.6 | 3 | Audit_Stage_3_Repaired.xlsx / 3.2.6А | Протокол ба шийдвэрүүдийн тэмдэглэл | 1 | unverified |
| 3.3.1 | 3 | Audit_Stage_3_Repaired.xlsx / 3.3.1А | Аудитын түүврийн баримтжуулалт | 32 | unverified |
| 3.3.2 | 3 | Audit_Stage_3_Repaired.xlsx / 3.3.2А | Гадаад тулгалтын хяналтын бүртгэл | 23 | unverified |
| 4.1.A1 | 4 | Audit_Stage_4_Repaired.xlsx / 4.1A1 | Эерэг дүгнэлт бүхий аудитын тайлангийн загвар | 6 | unverified |
| 4.1.A2 | 4 | Audit_Stage_4_Repaired.xlsx / 4.1.A2 | Хязгаарлалттай дүгнэлт бүхий аудитын тайлангийн загвар | 9 | unverified |
| 4.1.A3 | 4 | Audit_Stage_4_Repaired.xlsx / 4.1A3 | Сөрөг дүгнэлт бүхий аудитын тайлангийн загвар | 9 | unverified |
| 4.1.A4 | 4 | Audit_Stage_4_Repaired.xlsx / 4.1A4 | Дүгнэлт өгөхөөс татгалзсан аудитын тайлангийн загвар | 7 | unverified |
| 4.1.1 | 4 | Audit_Stage_4_Repaired.xlsx / 4.1.1А | Буруу илэрхийллийн нэгтгэл | 1 | unverified |
| 4.1.2 | 4 | Audit_Stage_4_Repaired.xlsx / 4.1.2А | Тооцооллын болон ангиллын залруулгын жагсаалт бэлтгэх | 8 | unverified |
| 4.1.3 | 4 | Audit_Stage_4_Repaired.xlsx / 4.1.3А | Эцсийн шинжилгээний горим | 31 | unverified |
| 4.3.1 | 4 | Audit_Stage_4_Repaired.xlsx / 4.3.1А | Дотоод хяналтын дутагдлыг мэдээлэх (Удирдлагын захидал) | 24 | unverified |
| 4.4 | 4 | Audit_Stage_4_Repaired.xlsx / 4.4А | Дуусгавар болголт | 11 | unverified |
| 4.5 | 4 | Audit_Stage_4_Repaired.xlsx / 4.5А | УДИРДЛАГЫН БИЧГЭН ТӨЛӨӨЛЛИЙН ЗАХИДЛЫН ЗАГВАР (АОУС 580) | 28 | unverified |
| 4.6 | 4 | Audit_Stage_4_Repaired.xlsx / 4.6А | Гэрээт ажлын чанарын шалгалтын хуудас (ЧХШ) | 31 | unverified |
| 5.1 | 5 | Audit_Stage_5_Repaired.xlsx / 5.1А | Ажлын баримтыг хадгалах, архивлах | 16 | unverified |

## All 20 confirmed form references

R09 owns the dependency behavior with the relevant domain package. Confirm applicability and the named action before enforcing a gate. The two partial direct evidence links retain that status until complete acceptance.

| Reference | Source form | Target form / field | Relationship | Current evidence | Original work package | Original locator |
| --- | --- | --- | --- | --- | --- | --- |
| DEP-C01 | 1.4.1 | 1.1.1 / r16 | New-client acceptance outcome informs the scope questionnaire. Drafting independent fields remains possible; gate applies to the relevant decision-dependent action. | unverified | WP-08 | Audit_Stage_1_Repaired.xlsx / 1.1.1А!L2,L16 |
| DEP-C02 | 1.4.2 | 1.1.1 / r16 | Continuance branch uses actual current-period decision rather than reusing last year approval. | unverified | WP-08 | Audit_Stage_1_Repaired.xlsx / 1.1.1А!L2,L16 |
| DEP-C03 | 1.4.3 | 1.1.1 / r17 | The scope/additional-service answer references the exact engagement-letter version. | unverified | WP-08 | Audit_Stage_1_Repaired.xlsx / 1.1.1А!J17,L2 |
| DEP-C04 | 1.4.5 | 1.1.1 / r18 | Unresolved independence is not a satisfactory Yes; store actual outcome and unresolved matters. | unverified | WP-08 | Audit_Stage_1_Repaired.xlsx / 1.1.1А!J18 |
| DEP-C05 | 1.1.1 | 2.8 / undefined | Current accepted scope and agreed terms inform the plan; no claim that every earlier form blocks all planning. | unverified | WP-09 | Audit_Stage_1_Repaired.xlsx / 1.1.1А!L2 |
| DEP-C06 | 1.3 | 3.3.1 / r24 | Sampling receives the approved performance-materiality amount and version from form1.3, not a freshly calculated or historical default. | partial-evidence | WP-12 | Audit_Stage_3_Repaired.xlsx / 3.3.1А!A24,K24 |
| DEP-C07 | 2.6 | 3.3.1 / r28 | Sample design references planned controls reliance and evidence from2.6; actual applicability and method determine the consequence. | unverified | WP-12 | Audit_Stage_3_Repaired.xlsx / 3.3.1А!A28,K28 |
| DEP-C08 | 2.6 | 2.7.1 / undefined | Assessed risks and assertion context inform separate control-test, substantive-analysis and detail-test response choices. A changed risk requires targeted assessment, not blanket reset. | unverified | WP-09 | SRC02 / P06_Planning_risk_assessment_and_materiality.md / P06-UC02,P06-UC06; Audit_Stage_2_Repaired.xlsx / 2.7.1А!S12:S15 |
| DEP-C09 | 2.7.1 | 3.1.2 / undefined | An applicable PPE response tailors and allocates the PPE programme. Other balance-sheet areas use their own corresponding programmes. | unverified | WP-16 | SRC02 / P07_Audit_programmes_populations_and_sampling.md / P07-UC01; Audit_Stage_2_Repaired.xlsx / 2.7.1А!S12:S15 |
| DEP-C10 | 3.3.1 | 3.1.2 / undefined | Where PPE testing uses sampling, actual selected units/version support performed tests. A proposed design is not proof of selection or test performance. | unverified | WP-12 | SRC02 / P07_Audit_programmes_populations_and_sampling.md / P07-UC02,P07-UC03; Audit_Stage_3_Repaired.xlsx / 3.1.2А!C14:C16 |
| DEP-C11 | 3.3.2 | 3.1.8 / undefined | A bank confirmation case, when used, supplies actual evaluated response or alternative work to the cash area. A registered attachment does not establish independent verification. | unverified | WP-11 | SRC02 / P08_Information_requests_evidence_and_confirmations.md / P08-UC03,P08-UC04; P09_Fieldwork_audit_areas_and_significant_matters.md / P09-UC02 |
| DEP-C12 | 3.1.2 | 4.1.1 / undefined | An observed PPE exception is evaluated and classified; only an actual misstatement enters the misstatement register. Not every exception is an error. | unverified | WP-20 | SRC02 / P09_Fieldwork_audit_areas_and_significant_matters.md / P09-UC02,P09-UC11; P10_Findings_final_evaluation_and_reporting.md / P10-UC01 |
| DEP-C13 | 4.1.1 | 4.1.3 / undefined | Aggregate current corrected/uncorrected effects and final balances feed final evaluation. Agreed but unposted corrections remain uncorrected until verified. | unverified | WP-21 | SRC02 / P10_Findings_final_evaluation_and_reporting.md / P10-UC03 |
| DEP-C14 | 1.3 | 4.1.1 / undefined | Misstatement evaluation uses selected current thresholds and qualitative judgment; changed thresholds trigger the relevant renewed assessment. | partial-evidence | WP-20 | SRC02 / P06_Planning_risk_assessment_and_materiality.md / P06-UC03; P10_Findings_final_evaluation_and_reporting.md / P10-UC03; Automation_Coverage.csv / AUTO-046,AUTO-048 |
| DEP-C15 | 4.1.1 | 4.1.A1 / undefined | The authorized opinion decision considers evaluated findings.4.1.A1 applies only if an unmodified report is actually appropriate; unresolved matters cannot be hidden by template choice. | unverified | WP-23 | SRC02 / P10_Findings_final_evaluation_and_reporting.md / P10-UC03,P10-UC06,P10-UC07 |
| DEP-C16 | 4.5 | 4.4 / undefined | Actual obtained/evaluated representations support completion. A prepared unsigned template is not management representation. | unverified | WP-21 | SRC02 / P10_Findings_final_evaluation_and_reporting.md / P10-UC05,P10-UC08 |
| DEP-C17 | 4.6 | 4.4 / undefined | Assigned quality confirmation and any required formal EQR remain separate. Applicable unresolved concerns affect readiness;4.6 is not a universal four-person gate or report-issue authority. | unverified | WP-22 | SRC02 / P11_Preparation_review_confirmation_and_consultation.md / P11-UC04,P11-UC05,P11-UC06; P10_Findings_final_evaluation_and_reporting.md / P10-UC08 |
| DEP-C18 | 4.4 | 5.1 / undefined | Actual issue and completed audit work support administrative assembly, diagnostics and controlled lock. Assembly must not create or backdate missing audit work. | unverified | WP-24 | SRC02 / P12_Final_file_archive_retention_and_inspection.md / P12-UC01,P12-UC02 |
| DEP-C19 | 4.1.A1 | 5.1 / undefined | The selected exact issued report and full statements/notes package enter the manifest; custody acceptance and readability are separate events. | unverified | WP-24 | SRC02 / P10_Findings_final_evaluation_and_reporting.md / P10-UC08; P12_Final_file_archive_retention_and_inspection.md / P12-UC01,P12-UC03 |
| DEP-C20 | 5.1 | 5.1 / r28 | Actual authorized custody/access records determine retrieval context. An offered transfer is not accepted custody; former access does not survive revocation. | unverified | WP-24 | Audit_Stage_5_Repaired.xlsx / 5.1А!K28,M28; SRC02 / P12_Final_file_archive_retention_and_inspection.md / P12-UC03,P12-UC04 |

## All 29 source decisions

The original proposals are retained here. Later code may resolve part of a proposal. Reconcile that behavior and record the actual accountable decision, scope, source edition and acceptance evidence. Original open labels are not a new assertion that no implementation exists.

| Decision | Title | Source owner role | Original package | Original proposed decision | Required source resolution |
| --- | --- | --- | --- | --- | --- |
| D01 | Pre-engagement storage and activation circularity | Product owner and data architect | WP-06 | Approve a provisional enquiry record and its transition to the actual engagement ID. | Choose an explicitly separate provisional subject/lifecycle or a confirmed external intake/acceptance owner with an auditable activation link. Do not fake an accepted engagement or unknown professional facts. |
| D02 | Client/person/firm maintenance is not a verified source-system API | Product owner and source-system owner | WP-06 | Choose internal master-data ownership and name any authoritative external system and import/update contracts. | Define actual ownership, permitted manual/native input, publication/correction contract, failure behavior and dated adoption. Audit must not silently rewrite the source masters. |
| D03 | Canonical client consolidation | Product owner | WP-06 | Confirm consolidation stays excluded from Audit-owned scope. Trace to the actual owning system or role. | Exclude Audit-owned consolidation. Preserve duplicate suspicion as an ordinary source-owner issue; identifier crosswalks for supplied data remain separately supported. |
| D04 | Contact channels and capacity history | Data architect and CRM owner | WP-06 | Approve stable contact identity, dated channels and historical capacity/role facts. | Confirm the authoritative contact representation and dated history. Add a justified field/contract only where actual requirements need it. No registry-monitoring product is implied. |
| D05 | Four capacities and firm authority | Firm methodology/access owners | WP-03 | Sign off professional authorities, incompatible roles and documented delegation. | Configure a simple work-capacity hierarchy within granted scope, with actual work assignment and applicable independent eligibility. Decide which work needs R2/R3/R4; do not require all four everywhere. |
| D06 | Final quality confirmation versus formal EQR | Firm quality owner | WP-22 | Define applicability and eligible independent EQR, distinct from ordinary final quality confirmation. | Record assigned R4 confirmation separately from formal EQR applicability/eligibility/performance/completion. Specify actual formal trigger and edition. |
| D07 | Tenant and engagement consistency across joins | Platform and data architects | WP-02 | Approve authoritative firm/engagement record partitioning, grants and version-key validation. | Validate same scope at every write/read path and add appropriate composite constraints/RLS tests where selected. No cross-tenant identity/link/search/export leakage. |
| D08 | Unique business keys and versioned typed rows | Data architect | WP-02 | Approve stable business IDs, row identity, typed values and versioned schema. | Review each unique key by identity/version/tenant scope before migration. Preserve exact historic target IDs; do not fix conflicts by overwriting a relied-upon row. |
| D09 | Required immutable action input for first creation | Platform architect | WP-02 | Name immutable initial command inputs, identity and idempotency scope. | Define a valid creation-request/input representation and atomic bootstrap, or a justified nullable creation path. Do not invent a placeholder professional object. |
| D10 | Single-current and effective-date overlap | Data/platform architects | WP-05 | Approve effective-date, current-version and non-overlap rules for templates and policies. | Select constraints and guarded commands for one current logical version and unambiguous effective context; test concurrent revisions and overlapping intervals. |
| D11 | Account split allocation | Methodology and data owners | WP-10 | Decide supported mapping and split-allocation methods before accepting bridge results. | Keep the minimum single destination. A later split method requires explicit weighted grain, sum/inclusion controls and verified reconciliation. |
| D12 | Calculated and human-selected materiality | Product/methodology/data owners | WP-09 | Separate system calculations from human-selected materiality and approval of exact inputs. | Retain the calculation run and exact parameters plus a linked human selection/rationale, or propose justified fields. Do not silently replace the calculated result. |
| D13 | Selected source-item uniqueness | Data and calculation owners | WP-12 | Define stable population and selected-unit identity, including retries and duplicate resolution. | Enforce unique selected unit within the exact sample/population, reject missing/duplicate unit IDs and preserve changed selections separately. |
| D14 | Native child answers and review history | Product/data architects | WP-05 | Approve immutable signed revisions and permitted migration of typed child rows. | Define the native content snapshot/hash boundary and child revision/supersession operation. Old reviewed content must remain reproducible. |
| D15 | Full final financial-statement package binding | Reporting/product/data owners | WP-23 | Specify all approved FS, notes, report, opinion, EQR and external artifact versions in the manifest. | Define an exact complete package/manifest binding using existing version/file facilities or a justified extension. Wrong/stale report-statement pairing must fail. |
| D16 | Other information expected but not received | Data architect and reporting owner | WP-21 | Define whether other information applies, expected/received timing and how unresolved cases gate issue. | Separate expected-document obligation from actual received-version content, or adjust conditional requiredness. Never fabricate a file reference for missing information. |
| D17 | Omitted applicable disclosure | Reporting/data owners | WP-21 | Define disclosure applicability and authority for omissions or N/A. | Bind a controlled requirement independently from an existing note, keeping missing-note assessment explicit. No invented zero-value note should satisfy it. |
| D18 | Targeted reliance and renewed review | Methodology and platform owners | WP-09 | Sign off which changes invalidate which exact approvals and when targeted re-review is sufficient. | Preserve signed content and history; identify affected current reliance and required renewed review through AUD_CHANGE_IMPACT. Reconcile the precise invariant/command behavior with Part A before implementation. |
| D19 | Holds versus AUTO-058 minimum | Product/archive owner | WP-24 | Treat holds as separate persistent authority that can suspend disposition. | Keep M12 hold requirements in P12; show the additional selected implementation separately from AUTO-058. No claim that the automation minimum already supplies legal-hold management. |
| D20 | Retention anchor and distinct completion clocks | Firm legal/archive/methodology owners | WP-24 | Approve applicable retention anchor, assembly clock, retention duration and disposition roles before any live use. | Use the verified legal minimum with the actual applicable anchor and longer restrictions. Obtain firm assembly/correction/custody policies separately; unknown eligibility prevents destruction. |
| D21 | Local adoption and future-effective editions | Firm methodology/legal owners | WP-05 | Record authoritative standards editions, applicability and future-effective rule behavior. | Bind actual jurisdiction, period, entity category and adopted edition. Later 240/570/PIE/expert amendments remain future/conditional until applicable. |
| D22 | Firm tenure and conflicting services | Firm ethics/legal owner | WP-08 | Approve verified tenure and conflicting service policy before encoding acceptance blocks. | Verify actual legal provider, service history and entity classification, including applicable exemptions. Do not implement a universal five-year individual-auditor rule. |
| D23 | Source form scores and accounting shortcuts | Methodology owner | WP-09 | Distinguish form prompts, professional judgment and governed calculation policy. | Preserve source wording in the form ledger, correct an adopted method with approval and tested boundaries. Do not infer professional outcomes from flawed scores or accounting shortcuts. |
| D24 | Follow-up is indirect wishlist scope | Product and firm service owners | WP-26 | Confirm whether recommendation follow-up is separately authorized and who owns it. | Document conditional manual action/progress/verification/closure behavior. Confirm offering, mandate, independence and authority before activating dependent work. |
| D25 | External services and execution not demonstrated | Implementation owner | WP-23 | Approve actual provider and sandbox for signatures, delivery, portals and any other external services. | Treat Part B commands and enforcement as proposed contracts. Select actual native/manual/external routes and demonstrate required outcomes before release. |
| D26 | Firm-quality, finance and separate-service research | Product owner | WP-27 | Decide wider B-cycle scope and authorize each separate C service explicitly. | Retain professional context/future/conditional dispositions in registers; do not manufacture current software use cases from research objects or old OP codes. |
| D27 | Secondary generated corpus review remains partial | Requirements author | WP-00 | Resolve supporting corpus interpretations only where they change an owning requirement or gate. | Keep the file ledger exact about direct reading, comparison and pending review. This review edition is not a claim that the master prompt full-corpus reading gate is completed. Finish pending semantic families before a final completeness certification. |
| D28 | Proposed sample design precedes actual selection | Methodology, product and data owners | WP-12 | Approve the design-before-selection lifecycle and exact inputs requiring renewed review. | Retain the proposed typed design, exact population and method/size/seed/error/rationale in a real persisted workpaper/manifest, review that exact design, then create AUD_SAMPLE and membership with actual SELECTED_AT when selection occurs; alternatively approve a justified model change. Preserve design-to-selection lineage and do not label design approval as completed selection. |
| D29 | Native workpaper requires an actual persisted storage reference | Product, platform and data owners | WP-05 | Define persisted native workpaper artifact reference, answer and evidence relationships. | Define the actual native snapshot/storage object representation, exact CONTENT_HASH boundary, retained child membership/version and stable reference used by STORAGE_OBJECT_REF, or approve a justified conditional-requiredness/model change. Never fabricate a file path or imply that external uploads automatically populate native responses. |

## Future automation decisions

All 58 future rows are scope-pending in the saved report. R24 must record the actual mandate/disposition for each row. Approved multi-capability descriptions require separate build/test tasks. Any minimum behavior is still handled through its AUTO-001–AUTO-058 contract.

| Future row | Exact extension description | Owning cases | Current evidence |
| --- | --- | --- | --- |
| AUTO-001-FUTURE | • Calculate exact period gaps across several accepted files. • Classify uploaded documents and propose likely request links for auditor confirmation. • Synchronize requests with the client portal and mark dependent work stale after replacement. | P08-UC01, P08-UC04 | scope-pending |
| AUTO-002-FUTURE | • Support reusable profiles for common ERP exports and additional field domains. • Detect overlapping extracts and comparative or post-period evidence roles. • Propose mappings and formats for auditor approval without silently changing source values. | P05-UC01, P05-UC02, P05-UC03 | scope-pending |
| AUTO-003-FUTURE | • Bridge every transformation, filter and join through full dataset lineage. • Add normalized and near-duplicate population profiles. • Obtain independent counts and totals directly from connected source systems. | P05-UC01, P05-UC02, P05-UC03 | scope-pending |
| AUTO-004-FUTURE | • Maintain controlled effective-dated alias crosswalks and historical master versions. • Detect conflicting attributes across files, entities and periods. • Add explainable fuzzy entity resolution and external registry checks. | P05-UC01, P05-UC02, P05-UC03 | scope-pending |
| AUTO-005-FUTURE | • Support entity, branch and functional-currency reconciliation profiles. • Reconcile opening-only and authorized consolidation journals separately. • Refresh the bridge automatically after connected ledger or trial-balance changes. | P05-UC01, P05-UC02, P05-UC03 | scope-pending |
| AUTO-006-FUTURE | • Add approved split allocations and effective-dated mappings. • Incorporate audit adjustments once and controlled non-ledger schedules. • Connect the bridge to structured statement production and note mappings. | P05-UC01, P05-UC02, P05-UC03 | scope-pending |
| AUTO-007-FUTURE | • Validate classification rules and prior-period restatement bridges. • Consume controlled disclosure schedules and account-mapping results. • Import XBRL or extract candidate structures from document files for confirmation. | P05-UC01, P05-UC02, P05-UC03 | scope-pending |
| AUTO-008-FUTURE | • Support effective account crosswalks after chart-of-account changes. • Carry forward unresolved misstatements, findings and evidence requests to their owning workflows. • Add group, acquisition and foreign-currency opening profiles. | P05-UC01, P05-UC02, P05-UC03 | scope-pending |
| AUTO-009-FUTURE | • Add journal-series gap and void-register testing. • Add user, weekend, holiday, account-combination and approval-conflict profiles. • Add explainable near-duplicate and reversal-pattern matching with connected posting history. | P09-UC04, P09-UC11 | scope-pending |
| AUTO-010-FUTURE | • Add monthly trends, seasonality, period-end spikes and reversals. • Use approved operational drivers and peer or budget benchmarks. • Refresh final analytics automatically and reopen conclusions when underlying balances change. | P06-UC03, P06-UC05 | scope-pending |
| AUTO-011-FUTURE | • Add invoice-series gap, void and reset testing. • Add explainable near-duplicate, zero, negative and non-standard-value profiles. • Import sales and ledger populations directly from supported ERP systems. | P09-UC02, P09-UC11 | scope-pending |
| AUTO-012-FUTURE | • Support several revenue streams with different performance-date rules. • Add partial and fuzzy credit-note matching within approved windows. • Reuse post-period cases in subsequent-events work and ingest logistics data from connected systems. | P09-UC02, P09-UC11 | scope-pending |
| AUTO-013-FUTURE | • Add approved FIFO, proportional and many-to-many allocation methods. • Connect bank receipts and remittance data for automated matching. • Feed aged and collection results into allowance or expected-credit-loss calculations. | P09-UC02, P09-UC11 | scope-pending |
| AUTO-014-FUTURE | • Apply effective-dated customer, product and volume price schedules. • Validate approval evidence for overrides and retrospective rebates. • Extract candidate terms from controlled contracts for auditor confirmation. | P09-UC02, P09-UC11 | scope-pending |
| AUTO-015-FUTURE | • Add milestone and usage-based schedules with controlled evidence inputs. • Support multi-obligation allocations and contract modifications under approved accounting decisions. • Connect billing, contract and ledger systems and extract candidate terms for confirmation. | P09-UC02, P09-UC11 | scope-pending |
| AUTO-016-FUTURE | • Add explainable near-duplicate invoice and payment profiles. • Link invoices, credits and partial payments into one economic-event case. • Reuse confirmed payment cases in cash analytics and import populations from connected ERP systems. | P09-UC02, P09-UC11 | scope-pending |
| AUTO-017-FUTURE | • Cross-match supplier identifiers with employees, customers and known related parties. • Add controlled fuzzy name, address and account-owner matching. • Connect authoritative company, tax and bank-account verification sources where legally available. | P09-UC02, P09-UC11 | scope-pending |
| AUTO-018-FUTURE | • Support partial deliveries, partial invoices, credits and configurable matching tolerances. • Add three-way or four-way profiles for different procurement processes. • Connect procurement, warehouse, accounts-payable and bank systems and extract document fields where controlled. | P09-UC02, P09-UC11 | scope-pending |
| AUTO-019-FUTURE | • Add partial and fuzzy supplier, amount and reference matching. • Reconcile goods-received-not-invoiced and accrual schedules. • Reuse the same economic events in subsequent-events work and connect procurement and bank data. | P09-UC02, P09-UC11 | scope-pending |
| AUTO-020-FUTURE | • Add partial, many-to-one and many-to-many matching with explainable allocation. • Age reconciling items and detect duplicates, stale items, fees and interest candidates. • Import authenticated statements through supported bank connections. | P09-UC02, P09-UC11 | scope-pending |
| AUTO-021-FUTURE | • Add below-approval-threshold, weekend, holiday and unusual-user profiles. • Reuse duplicate-payment and supplier-identity cases in the same investigation queue. • Run recurring analytics over connected bank and cash-ledger feeds. | P09-UC02, P09-UC11 | scope-pending |
| AUTO-022-FUTURE | • Support location and approved unit-of-measure conversion profiles. • Add near-duplicate, unusual-user, timing and manual-adjustment analytics. • Refresh movements and balances from connected warehouse and ledger systems. | P05-UC01, P05-UC02, P09-UC02, P09-UC11 | scope-pending |
| AUTO-023-FUTURE | • Track recounts, count teams, sheet sequence and signed evidence coverage. • Link approved adjustments through the register and ledger after posting. • Capture controlled mobile counts and barcode evidence with offline synchronization. | P09-UC05, P09-UC02, P09-UC11 | scope-pending |
| AUTO-024-FUTURE | • Apply different cut-off relationships by movement and shipping-term profile. • Add fuzzy transfer pairing, partial quantities and multi-leg transfers. • Connect warehouse, procurement, sales and ledger event histories. | P09-UC05, P09-UC02, P09-UC11 | scope-pending |
| AUTO-025-FUTURE | • Add FIFO, moving-average and standard-cost profiles. • Support overhead allocation, production yields and cost-layer drill-back. • Run recalculation directly over connected inventory and manufacturing movements. | P09-UC02, P09-UC11 | scope-pending |
| AUTO-026-FUTURE | • Use sales history, expiry dates and inventory-specific movement rules. • Add scenarios for selling-price and disposal-cost assumptions. • Connect product sales, market-price and warehouse condition evidence where reliable. | P09-UC02, P09-UC06, P09-UC11 | scope-pending |
| AUTO-027-FUTURE | • Add asset-level disposal, transfer and construction-in-progress profiles. • Support revaluation, impairment and foreign-currency movement categories. • Synchronize asset-register and ledger movements from supported ERP systems. | P09-UC02, P09-UC11 | scope-pending |
| AUTO-028-FUTURE | • Add declining-balance, units-of-production and approved partial-period conventions. • Model changes in estimates, component replacements and impairment-adjusted bases. • Import asset terms and recorded charges from connected fixed-asset systems. | P09-UC02, P09-UC11 | scope-pending |
| AUTO-029-FUTURE | • Add custodian, location and physical-inspection evidence matching. • Analyze repair history, utilization and class-level life distributions. • Use barcode or asset-management integrations for controlled existence follow-up. | P09-UC02, P09-UC11 | scope-pending |
| AUTO-030-FUTURE | • Accumulate related project costs and apply class-specific policy profiles. • Add controlled keyword or document classification with auditor confirmation. • Match approvals, purchase documents and placed-in-service evidence from connected systems. | P09-UC02, P09-UC11 | scope-pending |
| AUTO-031-FUTURE | • Reconcile payroll outputs with tax and social-insurance returns. • Detect shared bank accounts, duplicate identities and unmatched payments across periods. • Connect HR, payroll, ledger and bank systems through controlled interfaces. | P09-UC02, P09-UC11 | scope-pending |
| AUTO-032-FUTURE | • Maintain controlled effective-dated rule libraries with caps, exemptions and special categories. • Support retroactive pay, benefits in kind and cumulative calculations. • Connect authoritative statutory parameter sources and payroll systems with approval controls. | P09-UC02, P09-UC11 | scope-pending |
| AUTO-033-FUTURE | • Analyze bonus, overtime, allowance and manual-adjustment components separately. • Use longer employee histories, seasonality and role-based comparison groups. • Consume approved HR changes and authorization evidence from connected systems. | P09-UC02, P09-UC11 | scope-pending |
| AUTO-034-FUTURE | • Match payments to filed liabilities and identify overdue or duplicate periods. • Add effective-dated jurisdiction and transaction-category rule profiles. • Connect e-invoice, ledger, bank and tax-authority data where access and law permit. | P09-UC02, P09-UC11 | scope-pending |
| AUTO-035-FUTURE | • Support loss carryforwards, tax credits and enacted future rate changes. • Analyze movement in temporary differences and forecast utilization scenarios. • Connect controlled tax-return, ledger and payment sources. | P09-UC02, P09-UC11 | scope-pending |
| AUTO-036-FUTURE | • Add effective-interest, fee and modification schedules. • Reuse covenant results in going-concern indicators and reporting workflows. • Connect lender statements, payment schedules and ledger data. | P09-UC02, P09-UC11 | scope-pending |
| AUTO-037-FUTURE | • Add index changes, modifications, remeasurements and partial terminations. • Support exemptions, incentives, initial direct costs and current or non-current presentation. • Import approved lease terms and ledger postings from connected systems. | P09-UC02, P09-UC11 | scope-pending |
| AUTO-038-FUTURE | • Connect approved Bank of Mongolia or other authoritative rate sources with retained snapshots. • Support approved average, historical and multiple-rate selection rules. • Reconcile realized and unrealized gains or losses and reuse one rate result across bank and group reporting. | P09-UC02, P09-UC11 | scope-pending |
| AUTO-039-FUTURE | • Reconcile detailed share registers, owners and transaction dates. • Support reserves, other comprehensive income and complex instrument profiles. • Connect corporate secretarial records, payment evidence and official registries where available. | P09-UC02, P09-UC11 | scope-pending |
| AUTO-040-FUTURE | • Add corporate actions, amortized-cost and effective-yield schedules. • Connect controlled market, custodian and broker reference data. • Support valuation-model input comparison, independent price ranges and hierarchy evidence. | P09-UC02, P09-UC11 | scope-pending |
| AUTO-041-FUTURE | • Add explainable fuzzy name, address, director and ownership matching. • Compare pricing, terms and reciprocal confirmations with approved benchmarks. • Connect corporate registries and group ownership sources where legally and technically available. | P09-UC09, P09-UC11 | scope-pending |
| AUTO-042-FUTURE | • Add forward-looking scenarios, overlays and probability weighting. • Support additional provision, discounted-cash-flow and impairment indicator profiles. • Compare assumption versions, back-test prior estimates and connect approved source models. | P09-UC06, P09-UC11 | scope-pending |
| AUTO-043-FUTURE | • Add reciprocal transaction and profit-in-inventory matching. • Apply approved translation and effective ownership calculations. • Support multi-level groups, sub-consolidations and connected consolidation systems. | P09-UC10, P09-UC11 | scope-pending |
| AUTO-044-FUTURE | • Add auditor-approved downside scenarios and sensitivity analysis. • Compare forecast with actual results and monitor assumption changes. • Link indicators, mitigating-action evidence, disclosures and report consistency in the conclusion workflow. | P09-UC08, P09-UC11 | scope-pending |
| AUTO-045-FUTURE | • Add partial and fuzzy links to receipts, payments, credits and financing events. • Consume canonical cases from revenue, payables, cash and legal workflows. • Connect post-period ledgers and approved external-event sources with continuous refresh. | P09-UC07, P09-UC11 | scope-pending |
| AUTO-046-FUTURE | • Compare several candidate benchmarks and visualize sensitivity. • Support group and component materiality allocations. • Identify affected samples, misstatements and procedures and mark dependent conclusions stale after revisions. | P06-UC03, P06-UC05 | scope-pending |
| AUTO-047-FUTURE | • Add systematic, stratified and monetary-unit selection methods. • Calculate method-specific sample size, interval and upper error bounds. • Reuse population integrity, materiality and misstatement results with controlled reruns. | P07-UC02, P07-UC03 | scope-pending |
| AUTO-048-FUTURE | • Trace approved correcting entries through the final trial balance and statements. • Include tax, prior-period and projected effects without double counting. • Link qualitative evaluation, management representations and reporting consequences to partner review. | P10-UC02, P10-UC03 | scope-pending |
| AUTO-049-FUTURE | • Reconcile management, counsel, board-minutes and regulatory source lists for coverage. • Track evidence freshness and contradictory status across sources. • Support controlled external-counsel confirmations and link final matters to disclosures and reporting. | P09-UC09, P09-UC11 | scope-pending |
| AUTO-050-FUTURE | • Consume liquidity, covenant, runway and downside-scenario results from financial indicators. • Add controlled consistency checks across assumptions, disclosures and report wording. • Refresh evidence and reopen review when forecasts, financing or applicable standard versions change. | P09-UC08, P09-UC11 | scope-pending |
| AUTO-051-FUTURE | • Consume canonical post-period transaction cases from the transaction-review capability. • Add evidence freshness, report-date reminders and automated reopening after new events. • Link resolved events to adjusted statements, disclosures and final report-consistency review. | P09-UC07, P10-UC08 | scope-pending |
| AUTO-052-FUTURE | • Activate candidate requirements from structured entity, transaction and accounting facts. • Link checklist requirements to structured statement and note nodes and technical-review results. • Add explainable document analysis and controlled updates when reporting requirements change. | P10-UC04 | scope-pending |
| AUTO-053-FUTURE | • Add risk-response and assertion coverage views within each area. • Reopen completion automatically when relied-upon work or evidence becomes stale. • Provide cross-area dependency and partner completion dashboards. | P09-UC11 | scope-pending |
| AUTO-054-FUTURE | • Maintain a fuller dependency graph with configurable change-impact rules. • Propagate staleness through materiality, data, evidence and conclusion dependencies. • Suggest likely affected work for auditor confirmation after methodology or engagement changes. | P06-UC02, P11-UC07 | scope-pending |
| AUTO-055-FUTURE | • Add escalation, service-level and aging rules with notifications. • Prevent prohibited self-approval and enforce consultation or quality-review gates. • Reopen closed items automatically when relied-upon inputs, evidence or conclusions become stale. | P11-UC01, P11-UC02 | scope-pending |
| AUTO-056-FUTURE | • Use controlled clause libraries and report templates tied to applicable standards. • Add explainable semantic comparison between the approved decisions and report draft. • Reopen approval automatically when statements, conclusions or standard applicability change. | P10-UC06, P10-UC07 | scope-pending |
| AUTO-057-FUTURE | • Add qualified digital signatures, timestamping and independently verifiable integrity records. • Distribute through a secure recipient portal with controlled acknowledgment. • Support governed withdrawal, correction and replacement chains and authorized regulator filing. | P10-UC08 | scope-pending |
| AUTO-058-FUTURE | • Create sealed archival packages with independent integrity verification. • Support legal holds, suspended disposal and jurisdiction-specific retention profiles. • Integrate with records repositories, e-discovery processes and governed destruction workflows. | P12-UC02 | scope-pending |

## Source and evidence provenance

| Source ID | Source material | SHA-256 |
| --- | --- | --- |
| OUTER | Audit_All_Materials_2026-10-26.zip | 329c0d68826f6f515715fac119a6256021a0c8423f500003cd9552ba2c7ece39 |
| SRC-01 | Veritech_Audit_User_Flows_and_Screen_Requirements(2).pdf | b5d43f6763b25dcd95139911a56cb99ce27f5c9550698bc175104e5406b7ca73 |
| SRC-02 | Audit_Grounded_Process_Specification_Working_Review(1).zip | 98827951f8ebda31bf24f3a519c7cdc22cae9206970ede9c610f988784dcf508 |
| SRC-03 | Wishlist (2)(2).docx | a0091342397355f384d6d0922b28a328a1123c24c71e56d2dee26105da07cfcb |
| SRC-04 | Wishlist(2).docx | 7a3d7a5729f65abbf427fe0ab52d28f9fa92876755ca3918366622743821fce3 |
| SRC-05 | Automation-wishlist (2)(2).pdf | 868eebbc684538b3454c00c49a34c773e3b0ee507e48e55b4d7c095350ec48c5 |
| SRC-06 | Automation-wishlist(2).pdf | 27849285e19bf5fa6d47f8640c3c17f80cae252376b8cd132210723119f04909 |
| SRC-07 | Veritech_Audit_Automation_Baseline_Capability_Scope_MN(5).pdf | b8f7d3767566238929dcc216645a55cc63f1045e06d24ffa7aeae3aba7733e57 |
| SRC-08 | Veritech_Audit_Automation_Feature_Catalogue_MN(5).pdf | fd2557c4464ce68a4dfbc2fd9c682646393e83c671a4a89666efc18ae3f3bf3a |
| SRC-09 | Audit_E2E_Lifecycles_EN(6)(5).xlsx | f616d137f0296aaad3706dbecf6f4aa887c5c4750c3ff3d85d38eab89be5e5cd |
| SRC-10 | Audit_E2E_Lifecycles_MN(6)(5).xlsx | 4757fcf6b365ac042e283e4d659bdac5668aa8b56b8644e8c01bd267ed131b75 |
| SRC-11 | Audit_Process_Maps_MN(5).pdf | 5ce1f64f90dba7c8cd901e9457203ab827555ae5a61d3d1477b8f5cc4b54d907 |
| SRC-12 | Audit_Stages_1-5_Full_Package(20261026-032625).zip | ec97fa8c159690af835a662982c66d13f610fef0ea8c177fa258df9173c18c72 |
| SRC-13 | Audit_Architect_ERD_Grouped_Diagram.pdf | e20a99074fcb2e4a836b73ea17501462d0e25d1e24662407517cf7e86464babb |
| SRC-14 | audit_core_physical_erd_v3_3246.dbml | b141a1b592afb493fd2e5d428839547ce9c72c466855410429317b34013a17de |
| SRC-15 | Audit_Core_v3_Catalogue_MN.pdf | 4e9750d9578f58b80923aea69b1f95217ebb6464cc074429538f212045a58e0b |
| SRC-16 | Audit_Ontology_Atlas_MN_EN_Compact_0640.pdf | 5c2e7ec8d14603e66389c4a176e188756980ea123008159de4c46bdd920fe7ce |
| SRC-17 | Audit_Ontology_Business_Specification_MN_EN_Compact_7540.pdf | 585b295d1568dcfaa14b8a77b39c5c18d978fc48293108b9f487ac147b4abcf6 |
| STG01 | Audit_Stage_1_Repaired.xlsx | b2fd7ce85a9a9e63f600167a88e18e5f51c783272e8a29e12a8ab8e7179c0cf0 |
| STG02 | Audit_Stage_2_Repaired.xlsx | f3f7bb633a952f084b4b66c98d8dd1a243d655409058263f7306f38a24dea12b |
| STG03 | Audit_Stage_3_Repaired.xlsx | 9cfe6c74f2659031f46243697308d809765f72175c49531363a73794ee64a2da |
| STG04 | Audit_Stage_4_Repaired.xlsx | 74676a901fc671e4e188d04dc7950937f2f9cd8d7cd2e4073e3b902148b7a2a7 |
| STG05 | Audit_Stage_5_Repaired.xlsx | f812eb3d7e3f38e068389c3b5cfef1721611d6b04df85c3b92b66622e2513293 |

The verification baseline SHA-256 is `3ccfbf6b4ae437176e426f17603f937779167855c27b3f6566189f6da3d77eea`. Its source manifest SHA-256 is `c307f51ad3528f970956d12c7e7f8937a9fd1059bb3b2db6f13906ac0f25595b`. Its normalized source SHA-256 is `27a7da39fda7488f62a43175df8fc97a53be42af43aec83393f80359efe7773e`.

The planning transition inventory contains 185 gateways and 827 flows across the five stages, with exact source identifiers preserved in Source_Closure_Register.json. Verify the original diagram context, actual gateway interpretation and source/target behavior during implementation and acceptance.

All 315 criteria, 476 E2E steps and 1,012 transition entries are retained individually in Source_Closure_Register.json with their current evidence status and exact source-row hash. The JSON also retains the source contract where present in the checked-in register. Source documents and synced reference files remain read-only.
