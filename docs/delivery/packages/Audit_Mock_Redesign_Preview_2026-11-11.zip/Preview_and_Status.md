# Audit_Mock redesign preview

11 November 2026. The first connected redesign is implemented and committed locally.

## Open the running preview

[Open the redesigned workspace](http://127.0.0.1:3055/?engagement=E-5a0e31c1-5986-45d3-a4e0-424d3343c370&view=home).

This preview uses an isolated synthetic database. Select a role on the sign-in screen:

| Role | Synthetic preview password |
|---|---|
| Бэлтгэгч / preparer | `LocalPreparer2026!` |
| Ахлах хянагч / reviewer | `LocalReviewer2026!` |
| Партнер / partner | `LocalPartner2026!` |
| Quality (independent desk) | `LocalQuality2026!` |
| Custodian (independent desk) | `LocalCustodian2026!` |

Use the reviewer role to explore planning, form authoring and review. Open **Ажлын баримтууд**, select **3.1.2**, then open **Нотлох баримт** to see source context beside the paper. Open **1.3** to inspect a typed form and its section index. The sidebar footer controls theme and density. The header switches engagements. The same fixture also contains a second synthetic engagement to inspect scoping.

The browser test left 3.1.2 reviewed after completing the full return/revision/response/clearance cycle. The other fixture records remain available for exploration. Synthetic methods and data do not establish professional or production acceptance.

## Implementation and checks

- Local branch: `redesign/enterprise-workspace`.
- Local commit: `9909b218930de4796c6e1a6f31cac5bbdbc6c77e`.
- Commit attribution: task-local `Codex <codex@localhost>`; global Git identity was not configured or changed.
- Build: `jF1BWQobqUWMNXkhnu2jq`; clean working tree at build time.
- Production build and TypeScript validation: passed.
- Automated regression suite: 60 tests passed.
- Browser integration: eight checks passed; 13 screenshots; no recorded runtime exceptions.
- `/`, `/pilot`, `/legacy/`, build identity and API returned HTTP 200 in the running preview.
- Changes are committed locally and have not been pushed to GitHub.

Read **Implementation_Status.md** for the UX-00–29 progress table, preserved contracts, remaining acceptance work and integration sequence. **verification.json** records the executed browser run. Screenshots in this folder are from that isolated run.

The existing functional plan R00–R24 and source dispositions remain in force. The new interface does not mark unfinished forms, automation, E2E coverage, integrations or operational readiness complete.

## Restart this preview

From the `audit_mock` repository, use PowerShell:

```powershell
$env:AUDIT_PILOT_DB = 'C:\Users\Zoloo\.codex\.chatgpt-projects\g-p-6a66a9aa57e88191a4efe80e2002a0a4\outputs\audit-redesign-2026-11-11\fixture-iTtaE7\workspace.sqlite'
node scripts/serve.mjs --pilot 3055
```

The downloadable review ZIP contains the report, status, verification record and screenshots. The isolated database/browser profile remain local outside that ZIP.
