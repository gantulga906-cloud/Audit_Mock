# Enterprise workspace implementation — 11 November 2026

The first connected redesign is implemented on `redesign/enterprise-workspace`. It changes the shared application's navigation and presentation while retaining its existing service commands and audit controls. It is a reviewable implementation, with synthetic browser verification. Practitioner acceptance and full source acceptance remain open.

This implementation follows the supplied UX research package and the user's subsequent instruction to commence. It supplements the remaining-work plan R00–R24. It does not close that plan or change its functional scope. The original research work list remains a dated planning baseline; this document records implementation progress after that baseline.

## What is available

- `/` and `/pilot` open the shared workspace. `npm start` runs its API and SQLite service on port 3000; `npm run pilot` runs the same product on port 3004.
- A persistent sidebar separates personal work, engagement work and firm work. The header retains the selected engagement and period. Firm library, clients, people and administration navigation explicitly enters firm scope.
- Workpaper lists show status, responsibility, deadline, current version and blockers. Stage/status filters survive opening and returning from a paper. Engagement, view and workpaper identity are encoded in the URL.
- A selected workpaper opens as a full page. Work, review, analysis and version history are distinct tabs. Assignment and schedule metadata are compact, expandable settings. Typed forms retain their substantive fields and gain a section index.
- Save, submit, return, respond, clear and review remain separate commands. Submit uses the saved version. Unsaved changes prompt before navigation and page exit. A failed action leaves entered values available. “Дараагийн баримт” navigates to the next paper; it does not submit or approve work.
- Optional evidence context displays a selected original alongside the workpaper. The evidence library shows versions and linked work. Images/PDFs use browser preview; Office/CSV files have bounded content previews and an original download. Exact page/cell anchoring and full Office rendering are not certified.
- Data preparation has its own destination. Sampling, journal and area analysis remain attached to the applicable workpaper. Existing data acceptance, reconciliation and independent-review controls remain in the service.
- Planning exposes tasks, calendar and senior Gantt views as tabs. Existing staffing, review, completion, report, archive, quality and custody controls remain available in their owning workspaces.
- Firm form authoring stays in firm scope. Engagement adoption stays in engagement scope. Controlled drafts, grants, submission, publication and explicit version adoption retain their existing service paths.
- Shared tokens define neutral surfaces, an indigo action accent and semantic status colours. Light/dark themes, compact density, responsive navigation, focus styles and a skip link are included. Formal accessibility acceptance is still required.

## Baseline and cutover

The implementation branch started at local commit `25486b7448e6e5fc4d830868de943962209db3f3`, whose tracked files matched the previously inspected GitHub PR #6 head `937e692…`. The original local branch was `wave-0-audit-controls` and its working tree was clean before implementation.

The earlier browser-local application is retained at `/legacy`, including its original storage keys. The shared service does not automatically read, import or overwrite those browser records. `node scripts/serve.mjs --legacy` serves that historical surface without starting the shared API. This provides an inspection route while migration/parity work continues; it is not proof of complete legacy parity or data migration.

The source documents, source manifest, coverage ledger and supplied research matrices were not edited. The 128 remaining-work tasks, 2,247 research source rows, 51 E2E cycles, 70 form obligations, 58 minimum automation rows and 58 future automation rows retain their previous dispositions. No completion credit for those populations is inferred from this UI change.

## Compatibility with unfinished development

| Area | Preserved contract | Adaptation and remaining obligation |
|---|---|---|
| Identity and scope | Existing authenticated role, engagement membership, assignment and server-side authorization | UI context is explicit. Additional roles and managed staffing must extend authoritative permissions; sidebar visibility cannot grant access. |
| Workpaper lifecycle | IDs, saved revision, submitted revision, independent review, note response and separate clearance | New field families use the existing command adapter. E2E tests must continue asserting exact versions rather than button presence. |
| Templates and source forms | Typed contracts, form IDs, controlled author/publisher roles, explicit adoption | Complete R07/R08 field fidelity and import behavior using the existing editor/renderer boundary. No published revision silently replaces engagement work. |
| Evidence and requests | Original bytes, version IDs, acceptance, multipart requests, separate receipt and auditor acceptance | Extend preview/anchors and case workspace detail under R14. A preview is not evidence acceptance. Required accepted request evidence still blocks submission. |
| Data and automation | Population versions, reconciliation, approval, accepted evidence, parameter/result history, staleness | Add R13/R15/R16/R17 methods behind the current population and workpaper analysis desks. Each result needs its own authoritative applicability and version state. |
| Planning and linked facts | Current schedules, staffing, programme bases, impact records and service-owned decisions | Extend R09/R10/R12 linkage and workload semantics. Calendar/Gantt are views of authoritative records; they cannot perform audit sign-off. |
| Reporting and custody | Exact statement/report authorization, issue, signature, recipient acknowledgement, archive locks and custody | Extend R18–R21 variants in their existing owning desks. Presentation cannot bypass readiness, independence or archive guards. |
| Integrations and operations | Existing API paths, payloads, revision concurrency and idempotency keys | R22 operational work can continue independently. New integrations should update service records and surface errors/readiness through these desks. |
| Coverage and acceptance | Existing requirement and E2E identifiers and source dispositions | R23/R24 remain open according to the original plan. The browser checks below cover a representative connected slice, not every source lifecycle. |

`scripts/serve.mjs` changes entry-point/default serving behavior and preserves the legacy route. Domain, database, pilot command handlers, form contracts and audit policy modules are unchanged by this redesign.

## UX work-list progress

“Implemented” below describes the current representative interface. It does not mean every acceptance condition in the research plan has passed.

| ID | Current position | Still required |
|---|---|---|
| UX-00 | Baseline and regression boundary recorded | Independent full-source acceptance and reproducible operational fixtures |
| UX-01 | Existing research used | Walkthroughs with actual preparer, senior, partner, quality and custodian users |
| UX-02 | Existing authority and relationship contracts retained | Validate terminology and the complete relationship/authority inventory |
| UX-03 | New navigation implemented | Tree/task testing across representative roles and exceptions |
| UX-04 | Explicit lifecycle actions and draft guard implemented | Validate all draft/error/conflict paths and interruptions |
| UX-05 | Persistent shell and scoped URLs implemented | Wider deep-link and browser history acceptance |
| UX-06 | Neutral/indigo direction and tokens implemented | User assessment of visual direction and full contrast audit |
| UX-07 | Compact tables, metadata and section navigation implemented | All form families, text lengths, keyboard and density acceptance |
| UX-08 | Existing source contracts preserved | Complete the 70-form fidelity/family specification and reconciliation |
| UX-09 | Full-page workpaper implemented and exercised | Practitioner assessment of comparisons, long forms and navigation |
| UX-10 | Existing typed answers and linked-fact controls retained | Remaining roll-forward, relationships and source variants |
| UX-11 | Evidence library and optional preview implemented | All file formats, fidelity, anchors, replacement/staleness acceptance |
| UX-12 | Existing request/confirmation controls located in evidence workspace | Full case detail, exception and recipient UX validation |
| UX-13 | Existing data preparation isolated in its own workspace | Remaining import/reconciliation capabilities and exception workflows |
| UX-14 | Existing versioned analysis desks retained with workpapers | Complete automation methods, applicability and run investigations |
| UX-15 | Existing planning, sampling and technical desks retained | Complete source variants, tested units and planning linkage |
| UX-16 | Review queue and versioned response/clear/review exercised | Targeted impact and wider review/consultation variants |
| UX-17 | Personal priorities and decision queues implemented | Broader queue authority, workload and real-user task testing |
| UX-18 | Task/calendar/Gantt tabs implemented | Work economics and all planning interactions/constraints |
| UX-19 | Existing clients, intake and acceptance controls relocated | Remaining continuance/terms source cases and UX acceptance |
| UX-20 | Existing completion and report decisions relocated | Findings, report variants and issuance source acceptance |
| UX-21 | Independent quality/custody routes retained and themed | Full independent-desk redesign and later-fact/custody journeys |
| UX-22 | Controlled builder retained; firm-scope draft save exercised | Full builder/import/adoption journeys and source coverage |
| UX-23 | Responsive, theme, focus and draft states implemented | Formal WCAG/keyboard/screen-reader acceptance and all states |
| UX-24 | Shared entry points plus preserved legacy route implemented | Explicit data migration/parity criteria and retirement decision |
| UX-25 | User authorized implementation; browser slice defined | Practitioner test protocol and observed usability findings |
| UX-26 | Connected implementation and synthetic UI loop pass | Product/domain acceptance of the connected prototype |
| UX-27 | Owning destinations implemented around existing capabilities | Family-by-family expansion and source reconciliation |
| UX-28 | Existing service boundaries retained for parallel development | Continue original functional packages without reducing scope |
| UX-29 | Build/regression/browser checks pass | Full regression matrix, independent acceptance and legacy retirement |

## Verification

Executed on 11 November 2026 using Node 26.13.0 and the installed Chrome:

- `node scripts/build.mjs`: production build and TypeScript validation passed; `/`, `/pilot` and `/legacy` exported.
- `node --test --test-reporter=dot tests/*.test.mjs`: all 60 tests passed. The two new tests cover scoped URL identity and attention-state classification. Existing domain/service regressions remain in the suite.
- `node scripts/verify-workspace-ui.mjs ../outputs/audit-redesign-2026-11-11`: eight browser integration checks passed, 13 screenshots captured and no runtime exceptions recorded.

The browser checks use a fresh synthetic SQLite database and isolated headless Chrome profile. They exercise list-filter restoration, cancellation of unsaved navigation, preparer save/submit, reviewer return, preparer revision/response/resubmission, separate reviewer clearance/current-revision review, cross-engagement deep linking, firm library scope and controlled questionnaire draft saving. They also assert mobile document width and dark-mode paper-link colour. Screenshots cover desktop/laptop/mobile, evidence, planning, data and typed forms. The test records actual IDs and its fixture path in `verification.json`.

These checks do not establish production readiness, complete source acceptance, complete accessibility or measured usability. Office preview was not independently certified; the connected evidence test uses CSV. Full independent quality/custody/report and all 51 lifecycle journeys have not been rerun through this new interface.

## Incremental continuation

1. Review the running connected workspace with domain users and resolve observed navigation/action/compactness issues. Keep current service guards and exact-version regressions in place.
2. Expand native form families and the controlled builder (R07/R08), with source-coordinate acceptance. Use the existing typed renderer, section index and scoped author/adoption boundary.
3. Continue linked facts, staffing, intake and planning (R09–R12) alongside data/request/sampling/fieldwork packages (R13–R17). Add each capability to its owning desk, with explicit version, applicability, failure and readiness states.
4. Complete findings, review, reporting and custody variants (R18–R21), retaining independent role routes and exact-artifact controls.
5. Continue integrations/operations and source acceptance (R22–R24) throughout. Retire the legacy route only after explicit parity, migration and acceptance criteria pass.

Unfinished backend capabilities do not need another navigation architecture before they can be added. Their domain questions, source acceptance and operational dependencies still need to be resolved under the original plan.
